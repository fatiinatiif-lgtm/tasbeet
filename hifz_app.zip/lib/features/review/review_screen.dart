// lib/features/review/review_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/models.dart';
import '../../data/quran/surah_data.dart';
import 'review_provider.dart';

const _green = Color(0xFF0F5C4D);
const _ink = Color(0xFF14211E);

class ReviewScreen extends ConsumerWidget {
  const ReviewScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(reviewProvider);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F7F6),
        appBar: AppBar(
          title: const Text('مراجعة اليوم'),
          backgroundColor: Colors.transparent,
          foregroundColor: _ink,
          elevation: 0,
        ),
        body: async.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('حصل خطأ: $e')),
          data: (s) {
            if (s.total == 0) return const _EmptyState();
            if (s.isFinished) return _SummaryView(state: s);
            return _ReviewView(state: s);
          },
        ),
      ),
    );
  }
}

class _ReviewView extends ConsumerStatefulWidget {
  final ReviewState state;
  const _ReviewView({required this.state});

  @override
  ConsumerState<_ReviewView> createState() => _ReviewViewState();
}

class _ReviewViewState extends ConsumerState<_ReviewView> {
  bool _revealed = false;

  Future<void> _rate(ReviewRating r) async {
    setState(() => _revealed = false);
    await ref.read(reviewProvider.notifier).rate(r);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    final item = s.current!;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      child: Column(
        children: [
          Row(children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: s.progress,
                  minHeight: 8,
                  color: _green,
                  backgroundColor: const Color(0xFFD9E4E1),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text('${s.doneCount + 1} / ${s.total}'),
          ]),
          const SizedBox(height: 24),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFD9E4E1)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('سورة ${surahName(item.surah)}',
                      style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w700,
                          color: _green)),
                  const SizedBox(height: 8),
                  Text('الآيات ${item.fromAyah} – ${item.toAyah}',
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 28),
                  const Text('اقرئيها من حفظك، وبعدين قيّمي نفسك',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black54)),
                  const SizedBox(height: 20),
                  if (_revealed)
                    // TODO: اعرضي نص الآيات الحقيقي من ملف المصحف
                    const Text('﴿ نص الآيات هنا ﴾',
                        style: TextStyle(fontSize: 26, height: 2))
                  else
                    OutlinedButton(
                      onPressed: () => setState(() => _revealed = true),
                      child: const Text('أظهري الآيات'),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(children: [
            _RateButton('نسيت', const Color(0xFFB3382C),
                () => _rate(ReviewRating.forgot)),
            const SizedBox(width: 10),
            _RateButton('متردد', const Color(0xFFC98A12),
                () => _rate(ReviewRating.hesitant)),
            const SizedBox(width: 10),
            _RateButton('ممتاز', _green, () => _rate(ReviewRating.excellent)),
          ]),
        ],
      ),
    );
  }
}

class _RateButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _RateButton(this.label, this.color, this.onTap);

  @override
  Widget build(BuildContext context) => Expanded(
        child: FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: color,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: onTap,
          child: Text(label, style: const TextStyle(fontSize: 17)),
        ),
      );
}

class _SummaryView extends StatelessWidget {
  final ReviewState state;
  const _SummaryView({required this.state});

  @override
  Widget build(BuildContext context) {
    final r = state.results;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.check_circle, size: 72, color: _green),
          const SizedBox(height: 16),
          const Text('تقبّل الله منك، خلّصتي مراجعة اليوم',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 20),
          Text('ممتاز: ${r[ReviewRating.excellent] ?? 0}   '
              'متردد: ${r[ReviewRating.hesitant] ?? 0}   '
              'نسيت: ${r[ReviewRating.forgot] ?? 0}'),
          const SizedBox(height: 12),
          if (state.unlocked.isNotEmpty) ...[
            Text('إنجاز جديد: ${state.unlocked.join('، ')}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFFC98A12), fontSize: 16)),
            const SizedBox(height: 12),
          ],
          Text('+${state.xpEarned} نقطة',
              style: const TextStyle(
                  fontSize: 20, color: _green, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();
  @override
  Widget build(BuildContext context) => const Center(
        child: Padding(
          padding: EdgeInsets.all(28),
          child: Text('مفيش مراجعات مستحقة النهاردة.\nجرّبي تضيفي حفظ جديد.',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
        ),
      );
}
