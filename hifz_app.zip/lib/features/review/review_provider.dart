// lib/features/review/review_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/storage.dart';
import '../../data/models/models.dart';
import '../achievements/achievements_provider.dart';
import '../profile/profile_provider.dart';

class ReviewState {
  final List<MemorizationItem> queue; // اللي لسه ما اتراجعش
  final int total;
  final int xpEarned;
  final Map<ReviewRating, int> results;
  final List<String> unlocked; // إنجازات اتفتحت أثناء الجلسة

  const ReviewState({
    required this.queue,
    required this.total,
    this.xpEarned = 0,
    this.results = const {},
    this.unlocked = const [],
  });

  MemorizationItem? get current => queue.isEmpty ? null : queue.first;
  int get doneCount => total - queue.length;
  bool get isFinished => queue.isEmpty;
  double get progress => total == 0 ? 1 : doneCount / total;
}

class ReviewNotifier extends AutoDisposeAsyncNotifier<ReviewState> {
  @override
  Future<ReviewState> build() async {
    final all = await ref.read(memorizationRepoProvider).getAll();
    // الأضعف أولاً (الأقل قوة حفظ)
    final due = all.where((e) => e.isDue()).toList()
      ..sort((a, b) => a.strength.compareTo(b.strength));
    return ReviewState(queue: due, total: due.length);
  }

  Future<void> rate(ReviewRating rating) async {
    final s = state.value;
    if (s == null || s.current == null) return;

    final item = s.current!..applyReview(rating);
    await ref.read(memorizationRepoProvider).save(item);
    ref.read(profileProvider.notifier).addReview();
    final fresh = await ref.read(achievementsProvider.notifier).evaluate();
    ref.invalidate(dueCountProvider);

    final newResults = Map<ReviewRating, int>.from(s.results)
      ..update(rating, (v) => v + 1, ifAbsent: () => 1);

    state = AsyncData(ReviewState(
      queue: s.queue.sublist(1),
      total: s.total,
      xpEarned: s.xpEarned + XpRules.review,
      results: newResults,
      unlocked: [...s.unlocked, ...fresh.map((e) => e.title)],
    ));
  }
}

final reviewProvider =
    AsyncNotifierProvider.autoDispose<ReviewNotifier, ReviewState>(
        ReviewNotifier.new);
