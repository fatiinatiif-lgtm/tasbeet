// lib/features/shell/app_shell.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/home_widget_sync.dart';
import '../home/home_screen.dart';
import '../quran/quran_screen.dart';
import '../settings/settings_screen.dart';
import '../wird/wird_provider.dart';

/// الإطار الرئيسي: شريط سفلي (الرئيسية / القرآن الكريم / الإعدادات)
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) syncHomeWidget(ref.read(wirdProvider));
    });
  }

  @override
  Widget build(BuildContext context) {
    // تحديث ويدجت الشاشة الرئيسية كلما تغيّر الورد أو الإنجاز
    ref.listen<WirdState>(wirdProvider, (_, s) => syncHomeWidget(s));
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [HomeScreen(), QuranTab(), SettingsScreen()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book_rounded),
            label: 'القرآن الكريم',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }
}
