// lib/features/shell/app_shell.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/home_widget_sync.dart';
import '../../core/reminders.dart';
import '../../core/theme.dart';
import '../home/home_screen.dart';
import '../quran/quran_screen.dart';
import '../settings/settings_screen.dart';
import '../wird/wird_provider.dart';

/// الإطار الرئيسي: شريط سفلي عائم (الرئيسية / القرآن الكريم / الإعدادات)
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;
  Timer? _syncTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      syncHomeWidget(ref.read(wirdProvider));
      try {
        await ReminderService.init();
        await ReminderService.askPermissionOnce(ref.read(sharedPrefsProvider));
      } catch (_) {}
      _scheduleReminderSync();
    });
  }

  @override
  void dispose() {
    _syncTimer?.cancel();
    super.dispose();
  }

  /// إعادة جدولة التذكيرات بعد توقّف التغييرات لحظة
  void _scheduleReminderSync() {
    _syncTimer?.cancel();
    _syncTimer = Timer(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      ReminderService.sync(ref.read(wirdProvider), ref.read(remindersProvider))
          .catchError((_) {});
    });
  }

  @override
  Widget build(BuildContext context) {
    // تحديث ويدجت الشاشة الرئيسية والتذكيرات كلما تغيّر الورد أو الإنجاز
    ref.listen<WirdState>(wirdProvider, (_, s) {
      syncHomeWidget(s);
      _scheduleReminderSync();
    });
    ref.listen<ReminderConfig>(
        remindersProvider, (_, __) => _scheduleReminderSync());
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [HomeScreen(), QuranTab(), SettingsScreen()],
      ),
      bottomNavigationBar: _FancyNavBar(
        index: _index,
        onTap: (i) {
          if (i != _index) HapticFeedback.selectionClick();
          setState(() => _index = i);
        },
      ),
    );
  }
}

class _NavDef {
  final IconData icon, activeIcon;
  final String label;
  const _NavDef(this.icon, this.activeIcon, this.label);
}

const _navItems = [
  _NavDef(Icons.home_outlined, Icons.home_rounded, 'الرئيسية'),
  _NavDef(Icons.menu_book_outlined, Icons.menu_book_rounded, 'القرآن الكريم'),
  _NavDef(Icons.settings_outlined, Icons.settings_rounded, 'الإعدادات'),
];

/// شريط سفلي عائم بحواف مستديرة، والعنصر المحدد كحبّة متدرّجة تتمدّد بسلاسة
class _FancyNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const _FancyNavBar({required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
        child: Container(
          height: 68,
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: kGold.withAlpha(90), width: 1.2),
            boxShadow: [
              BoxShadow(
                  color: kGreenDark.withAlpha(60),
                  blurRadius: 24,
                  offset: const Offset(0, 8)),
            ],
          ),
          child: LayoutBuilder(builder: (context, box) {
            final total = box.maxWidth;
            final selW = total * 0.46;
            final otherW = (total - selW) / (_navItems.length - 1);
            return Row(children: [
              for (var i = 0; i < _navItems.length; i++)
                _NavButton(
                  def: _navItems[i],
                  selected: i == index,
                  width: i == index ? selW : otherW,
                  onTap: () => onTap(i),
                ),
            ]);
          }),
        ),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final _NavDef def;
  final bool selected;
  final double width;
  final VoidCallback onTap;
  const _NavButton(
      {required this.def,
      required this.selected,
      required this.width,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic,
        width: width,
        height: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [kGreen, kGreenDark])
              : null,
          boxShadow: selected
              ? [
                  BoxShadow(
                      color: kGreen.withAlpha(90),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ]
              : null,
        ),
        child: Center(
          child: ClipRect(
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(selected ? def.activeIcon : def.icon,
                  size: 25, color: selected ? kGoldLight : kMuted),
              if (selected) ...[
                const SizedBox(width: 7),
                Flexible(
                  child: Text(def.label,
                      maxLines: 1,
                      overflow: TextOverflow.fade,
                      softWrap: false,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800)),
                ),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}

