// lib/features/shell/app_shell.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../achievements/achievements_screen.dart';
import '../home/home_screen.dart';
import '../memorize/memorize_screen.dart';
import '../review/review_screen.dart';

final tabIndexProvider = StateProvider<int>((ref) => 0);

class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = ref.watch(tabIndexProvider);
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F6),
      body: IndexedStack(
        index: index,
        children: const [
          HomeScreen(),
          MemorizeScreen(),
          ReviewScreen(),
          AchievementsScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) =>
            ref.read(tabIndexProvider.notifier).state = i,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'حفظ'),
          NavigationDestination(icon: Icon(Icons.replay), label: 'مراجعة'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'إنجازات'),
        ],
      ),
    );
  }
}
