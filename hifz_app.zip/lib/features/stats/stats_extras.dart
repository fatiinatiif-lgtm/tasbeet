// lib/features/stats/stats_extras.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

const _dayShort = {6: 'س', 7: 'ح', 1: 'ن', 2: 'ث', 3: 'ر', 4: 'خ', 5: 'ج'};
const _dayFull = {
  6: 'السبت',
  7: 'الأحد',
  1: 'الإثنين',
  2: 'الثلاثاء',
  3: 'الأربعاء',
  4: 'الخميس',
  5: 'الجمعة',
};

/// الهدف الأسبوعي مع إمكانية تغييره
class WeeklyGoalCard extends ConsumerWidget {
  const WeeklyGoalCard({super.key});

  Future<void> _pick(BuildContext context, WidgetRef ref, int current) async {
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('هدفك الأسبوعي',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final g in const [7, 14, 20, 35, 50, 70, 100])
              ChoiceChip(
                label: Text('$g مهمة'),
                selected: g == current,
                selectedColor: kGreen.withAlpha(50),
                onSelected: (_) => Navigator.pop(ctx, g),
              ),
          ]),
        ),
      ),
    );
    if (v != null) ref.read(weeklyGoalProvider.notifier).set(v);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final goal = ref.watch(weeklyGoalProvider);
    final done = s.weekDone;
    final reached = done >= goal;
    final p = (done / goal).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDeco(radius: 22, border: kGold.withAlpha(140)),
      child: Row(children: [
        SizedBox(
          width: 66,
          height: 66,
          child: Stack(alignment: Alignment.center, children: [
            SizedBox(
              width: 66,
              height: 66,
              child: CircularProgressIndicator(
                value: p,
                strokeWidth: 7,
                color: reached ? kGold : kGreen,
                backgroundColor: kBorder,
              ),
            ),
            Icon(reached ? Icons.emoji_events_rounded : Icons.flag_rounded,
                color: reached ? kGold : kGreen),
          ]),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('هدف هذا الأسبوع',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 3),
            Text(
                reached
                    ? 'حققتَ هدفك ($done من $goal)، بارك الله فيك'
                    : 'أنجزتَ $done من $goal، بقي ${goal - done}',
                style: TextStyle(color: kMuted, height: 1.5)),
          ]),
        ),
        IconButton(
          tooltip: 'تغيير الهدف',
          onPressed: () => _pick(context, ref, goal),
          icon: Icon(Icons.tune_rounded, color: kGold),
        ),
      ]),
    );
  }
}

Widget _bars(List<(String, int)> data, Color color) {
  var max = 1;
  for (final d in data) {
    if (d.$2 > max) max = d.$2;
  }
  return Container(
    padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
    decoration: cardDeco(radius: 20),
    child: SizedBox(
      height: 130,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (final d in data)
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
              Text('${d.$2}',
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700, color: kMuted)),
              const SizedBox(height: 3),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 22,
                height: d.$2 == 0 ? 4 : 8 + 70.0 * d.$2 / max,
                decoration: BoxDecoration(
                  color: d.$2 == 0 ? kBorder : color,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              const SizedBox(height: 6),
              Text(d.$1, style: TextStyle(fontSize: 12.5, color: kInk)),
            ]),
          ),
      ]),
    ),
  );
}

class DaysChart extends ConsumerWidget {
  const DaysChart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final n = DateTime.now();
    final data = <(String, int)>[
      for (var i = 6; i >= 0; i--)
        () {
          final d = DateTime(n.year, n.month, n.day - i);
          return (_dayShort[d.weekday]!, s.countOnDate(dayString(d)));
        }(),
    ];
    return _bars(data, kGreen);
  }
}

class WeeksChart extends ConsumerWidget {
  const WeeksChart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final ws = WirdState.weekStartOf(DateTime.now());
    final data = <(String, int)>[
      for (var i = 5; i >= 0; i--)
        () {
          final a = DateTime(ws.year, ws.month, ws.day - 7 * i);
          final b = DateTime(a.year, a.month, a.day + 7);
          return ('${a.day}/${a.month}', s.countBetween(a, b));
        }(),
    ];
    return _bars(data, kGold);
  }
}

class InsightsGrid extends ConsumerWidget {
  const InsightsGrid({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final bw = s.bestWeekday;
    Widget row(List<Widget> c) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            c[0],
            const SizedBox(width: 10),
            c[1],
          ]),
        );
    return Column(children: [
      row([
        _Mini('هذا الأسبوع', '${s.weekDone}', Icons.date_range_rounded),
        _Mini('هذا الشهر', '${s.monthDone}', Icons.calendar_month_rounded),
      ]),
      row([
        _Mini('أيام نشطة', '${s.activeDays}', Icons.event_available_rounded),
        _Mini('أطول سلسلة', '${s.bestStreak}',
            Icons.local_fire_department_rounded),
      ]),
      row([
        _Mini('أفضل أسبوع', '${s.bestWeek}', Icons.military_tech_rounded),
        _Mini('أنشط يوم', bw == null ? '-' : _dayFull[bw]!,
            Icons.wb_sunny_rounded),
      ]),
    ]);
  }
}

class _Mini extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _Mini(this.label, this.value, this.icon);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: cardDeco(radius: 16),
          child: Row(children: [
            Icon(icon, color: kGold, size: 24),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(value,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: kInk)),
                    Text(label,
                        style: TextStyle(fontSize: 12.5, color: kMuted)),
                  ]),
            ),
          ]),
        ),
      );
}
