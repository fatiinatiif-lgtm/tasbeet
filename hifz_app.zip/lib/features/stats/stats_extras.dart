// lib/features/stats/stats_extras.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/widgets.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

const _dayShort = {6: 'س', 7: 'ح', 1: 'ن', 2: 'ث', 3: 'ر', 4: 'خ', 5: 'ج'};
const _dayFull = {
  6: 'السبت',
  7: 'الأحد',
  1: 'الإثنين',
  2: 'الثلاثاء',
  3: 'الأربعاء',
  4: 'الخميس',
  5: 'الجمعة',
};

/// الهدف الأسبوعي مع إمكانية تغييره
class WeeklyGoalCard extends ConsumerWidget {
  const WeeklyGoalCard({super.key});

  Future<void> _pick(BuildContext context, WidgetRef ref, int current) async {
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('هدفك الأسبوعي',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final g in const [7, 14, 20, 35, 50, 70, 100])
              ChoiceChip(
                label: Text('$g مهمة'),
                selected: g == current,
                selectedColor: kGreen.withAlpha(50),
                onSelected: (_) => Navigator.pop(ctx, g),
              ),
          ]),
        ),
      ),
    );
    if (v != null) ref.read(weeklyGoalProvider.notifier).set(v);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final goal = ref.watch(weeklyGoalProvider);
    final done = s.weekDone;
    final reached = done >= goal;
    final p = (done / goal).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDeco(radius: 22, border: kGold.withAlpha(140)),
      child: Row(children: [
        SizedBox(
          width: 66,
          height: 66,
          child: Stack(alignment: Alignment.center, children: [
            SizedBox(
              width: 66,
              height: 66,
              child: CircularProgressIndicator(
                value: p,
                strokeWidth: 7,
                color: reached ? kGold : kGreen,
                backgroundColor: kBorder,
              ),
            ),
            Icon(reached ? Icons.emoji_events_rounded : Icons.flag_rounded,
                color: reached ? kGold : kGreen),
          ]),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('هدف هذا الأسبوع',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 3),
            Text(
                reached
                    ? 'حققتَ هدفك ($done من $goal)، بارك الله فيك'
                    : 'أنجزتَ $done من $goal، بقي ${goal - done}',
                style: TextStyle(color: kMuted, height: 1.5)),
          ]),
        ),
        IconButton(
          tooltip: 'تغيير الهدف',
          onPressed: () => _pick(context, ref, goal),
          icon: Icon(Icons.tune_rounded, color: kGold),
        ),
      ]),
    );
  }
}

Widget _bars(List<(String, int)> data, Color color) {
  var max = 1;
  for (final d in data) {
    if (d.$2 > max) max = d.$2;
  }
  return Container(
    padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
    decoration: cardDeco(radius: 20),
    child: SizedBox(
      height: 130,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (final d in data)
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
              Text('${d.$2}',
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700, color: kMuted)),
              const SizedBox(height: 3),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 22,
                height: d.$2 == 0 ? 4 : 8 + 70.0 * d.$2 / max,
                decoration: BoxDecoration(
                  color: d.$2 == 0 ? kBorder : color,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              const SizedBox(height: 6),
              Text(d.$1, style: TextStyle(fontSize: 12.5, color: kInk)),
            ]),
          ),
      ]),
    ),
  );
}

class DaysChart extends ConsumerWidget {
  const DaysChart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final n = DateTime.now();
    final data = <(String, int)>[
      for (var i = 6; i >= 0; i--)
        () {
          final d = DateTime(n.year, n.month, n.day - i);
          return (_dayShort[d.weekday]!, s.countOnDate(dayString(d)));
        }(),
    ];
    return _bars(data, kGreen);
  }
}

class WeeksChart extends ConsumerWidget {
  const WeeksChart({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final ws = WirdState.weekStartOf(DateTime.now());
    final data = <(String, int)>[
      for (var i = 5; i >= 0; i--)
        () {
          final a = DateTime(ws.year, ws.month, ws.day - 7 * i);
          final b = DateTime(a.year, a.month, a.day + 7);
          return ('${a.day}/${a.month}', s.countBetween(a, b));
        }(),
    ];
    return _bars(data, kGold);
  }
}

class InsightsGrid extends ConsumerWidget {
  const InsightsGrid({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final bw = s.bestWeekday;
    Widget row(List<Widget> c) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            c[0],
            const SizedBox(width: 10),
            c[1],
          ]),
        );
    return Column(children: [
      row([
        _Mini('هذا الأسبوع', '${s.weekDone}', Icons.date_range_rounded),
        _Mini('هذا الشهر', '${s.monthDone}', Icons.calendar_month_rounded),
      ]),
      row([
        _Mini('أيام نشطة', '${s.activeDays}', Icons.event_available_rounded),
        _Mini('أطول سلسلة', '${s.bestStreak}',
            Icons.local_fire_department_rounded),
      ]),
      row([
        _Mini('أفضل أسبوع', '${s.bestWeek}', Icons.military_tech_rounded),
        _Mini('أنشط يوم', bw == null ? '-' : _dayFull[bw]!,
            Icons.wb_sunny_rounded),
      ]),
    ]);
  }
}

class _Mini extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _Mini(this.label, this.value, this.icon);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: cardDeco(radius: 16),
          child: Row(children: [
            Icon(icon, color: kGold, size: 24),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(value,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: kInk)),
                    Text(label,
                        style: TextStyle(fontSize: 12.5, color: kMuted)),
                  ]),
            ),
          ]),
        ),
      );
}


/// تقرير الأسبوع: ملخص أسبوع (السبت إلى الجمعة) مع مقارنة بما قبله
class WeeklyReportScreen extends ConsumerStatefulWidget {
  const WeeklyReportScreen({super.key});

  @override
  ConsumerState<WeeklyReportScreen> createState() => _WeeklyReportState();
}

class _WeeklyReportState extends ConsumerState<WeeklyReportScreen> {
  int _off = 0; // 0 هذا الأسبوع، 1 الماضي، ...

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(wirdProvider);
    final goal = ref.watch(weeklyGoalProvider);
    final now = WirdState.weekStartOf(DateTime.now());
    final ws = DateTime(now.year, now.month, now.day - 7 * _off);
    final we = DateTime(ws.year, ws.month, ws.day + 7);
    final prevStart = DateTime(ws.year, ws.month, ws.day - 7);

    final a = dayString(ws), b = dayString(we);
    final logs =
        s.logs.where((l) => l.date.compareTo(a) >= 0 && l.date.compareTo(b) < 0);
    final total = logs.length;
    final prev = s.countBetween(prevStart, ws);
    final xp = logs.fold<int>(0, (x, l) => x + l.entry.section.xp);

    final days = <(String, int, DateTime)>[
      for (var i = 0; i < 7; i++)
        () {
          final d = DateTime(ws.year, ws.month, ws.day + i);
          return (_dayShort[d.weekday]!, s.countOnDate(dayString(d)), d);
        }(),
    ];
    final activeDays = days.where((d) => d.$2 > 0).length;
    var best = days.first;
    for (final d in days) {
      if (d.$2 > best.$2) best = d;
    }
    final diff = total - prev;
    final bySec = <Section, int>{
      for (final sec in Section.values)
        sec: logs.where((l) => l.entry.section == sec).length,
    };
    final isNow = _off == 0;
    final end = DateTime(we.year, we.month, we.day - 1);
    final range = '${ws.day}/${ws.month} - ${end.day}/${end.month}';

    String verdict() {
      if (total == 0) {
        return isNow
            ? 'لم تسجّل إنجازًا هذا الأسبوع بعدُ، ابدأ بمهمة صغيرة اليوم.'
            : 'لا إنجازات مسجّلة في هذا الأسبوع.';
      }
      if (total >= goal) return 'أتممتَ هدفك الأسبوعي، بارك الله فيك وتقبّل منك.';
      if (diff > 0) return 'تقدّمتَ على الأسبوع الماضي بـ $diff مهمة، واصل.';
      if (diff == 0) return 'ثبتَّ على مستواك كالأسبوع الماضي، والثبات فضل.';
      return 'أقل من الأسبوع الماضي بـ ${-diff} مهمة، وبإمكانك تعويضها.';
    }

    String shareText() => 'تقريري الأسبوعي في «حياة بالقرآن» ($range)\n'
        '• المهام المنجزة: $total (هدفي $goal)\n'
        '• أيام المواظبة: $activeDays من 7\n'
        '• النقاط: $xp\n'
        '• السلسلة الحالية: ${s.streak} يوم\n'
        'اللهم بارك لنا في القرآن.';

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'تقرير الأسبوع',
          subtitle: range,
          colors: kSectionGradients[8],
          trailing: IconButton(
            tooltip: 'مشاركة',
            onPressed: () => Share.share(shareText()),
            icon: const Icon(Icons.ios_share_rounded, color: Colors.white),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(
                  onPressed: _off >= 12 ? null : () => setState(() => _off++),
                  icon: const Icon(Icons.chevron_right_rounded),
                ),
                Text(
                    isNow
                        ? 'هذا الأسبوع'
                        : (_off == 1 ? 'الأسبوع الماضي' : 'قبل $_off أسابيع'),
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800, color: kInk)),
                IconButton(
                  onPressed: isNow ? null : () => setState(() => _off--),
                  icon: const Icon(Icons.chevron_left_rounded),
                ),
              ]),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: cardDeco(radius: 20, border: kGold.withAlpha(140)),
                child: Row(children: [
                  Icon(Icons.auto_awesome_rounded, color: kGold, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(verdict(),
                        style: TextStyle(
                            color: kInk,
                            fontWeight: FontWeight.w700,
                            height: 1.6)),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Row(children: [
                _Mini('المهام المنجزة', '$total', Icons.task_alt_rounded),
                const SizedBox(width: 10),
                _Mini('أيام المواظبة', '$activeDays / 7',
                    Icons.event_available_rounded),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                _Mini('النقاط', '$xp', Icons.stars_rounded),
                const SizedBox(width: 10),
                _Mini(
                    'أنشط يوم',
                    best.$2 == 0 ? '-' : _dayFull[best.$3.weekday]!,
                    Icons.wb_sunny_rounded),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                _Mini(
                    'مقارنة بما قبله',
                    diff == 0 ? 'متساوٍ' : (diff > 0 ? '+$diff' : '$diff'),
                    diff >= 0
                        ? Icons.trending_up_rounded
                        : Icons.trending_down_rounded),
                const SizedBox(width: 10),
                _Mini('الهدف', '$total / $goal', Icons.flag_rounded),
              ]),
              const SizedBox(height: 20),
              const SectionTitle('أيام الأسبوع'),
              const SizedBox(height: 12),
              _bars([for (final d in days) (d.$1, d.$2)], kGreen),
              const SizedBox(height: 20),
              const SectionTitle('حسب القسم'),
              const SizedBox(height: 12),
              for (final sec in Section.values)
                if (bySec[sec]! > 0)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: cardDeco(radius: 16),
                    child: Row(children: [
                      Icon(sec.icon, color: kSectionGradients[sec.index][0]),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Text(sec.label,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700))),
                      Text('${bySec[sec]}',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: kSectionGradients[sec.index][0])),
                    ]),
                  ),
            ],
          ),
        ),
      ]),
    );
  }
}
