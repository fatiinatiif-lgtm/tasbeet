// lib/features/stats/stats_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';
import 'stats_extras.dart';

class StatsScreen extends ConsumerWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final recent = s.logs.reversed.take(60).toList();
    var maxSec = 1;
    for (final sec in Section.values) {
      if (s.completedIn(sec) > maxSec) maxSec = s.completedIn(sec);
    }

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
            title: 'الإحصائيات',
            subtitle: 'تابع تقدّمك يومًا بيوم',
            colors: kSectionGradients[8]),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              Row(children: [
                _Box('اليوم', '${s.doneToday}', Icons.today_rounded,
                    kGreen),
                const SizedBox(width: 12),
                _Box('الإجمالي', '${s.totalCompleted}', Icons.task_alt_rounded,
                    kSectionGradients[1][0]),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                _Box('أيام متواصلة', '${s.streak}',
                    Icons.local_fire_department_rounded,
                    kSectionGradients[6][0]),
                const SizedBox(width: 12),
                _Box('النقاط', '${s.xp}', Icons.stars_rounded, kGold),
              ]),
              const SizedBox(height: 14),
              InkWell(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const WeeklyReportScreen())),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: cardDeco(radius: 20, border: kGold.withAlpha(140)),
                  child: Row(children: [
                    Icon(Icons.summarize_rounded, color: kGold, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('تقرير الأسبوع',
                                style: TextStyle(
                                    fontSize: 16.5,
                                    fontWeight: FontWeight.w800,
                                    color: kInk)),
                            Text('ملخص أسبوعك ومقارنته بالأسبوع الماضي',
                                style: TextStyle(color: kMuted, fontSize: 13)),
                          ]),
                    ),
                    Icon(Icons.arrow_forward_ios_rounded,
                        size: 16, color: kGold),
                  ]),
                ),
              ),
              const SizedBox(height: 22),
              const WeeklyGoalCard(),
              const SizedBox(height: 22),
              const SectionTitle('آخر 7 أيام'),
              const SizedBox(height: 12),
              const DaysChart(),
              const SizedBox(height: 22),
              const SectionTitle('آخر 6 أسابيع'),
              const SizedBox(height: 12),
              const WeeksChart(),
              const SizedBox(height: 22),
              const SectionTitle('نظرة أعمق'),
              const SizedBox(height: 12),
              const InsightsGrid(),
              const SizedBox(height: 26),
              const SectionTitle('حسب القسم'),
              const SizedBox(height: 12),
              for (final sec in Section.values)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: cardDeco(radius: 18),
                  child: Column(children: [
                    Row(children: [
                      Icon(sec.icon, color: kSectionGradients[sec.index][0]),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Text(sec.label,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15.5))),
                      Text('${s.completedIn(sec)}',
                          style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                              color: kSectionGradients[sec.index][0])),
                    ]),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: s.completedIn(sec) / maxSec,
                        minHeight: 7,
                        color: kSectionGradients[sec.index][0],
                        backgroundColor: kBorder.withAlpha(150),
                      ),
                    ),
                  ]),
                ),
              const SizedBox(height: 18),
              const SectionTitle('آخر ما أنجزتَه'),
              const SizedBox(height: 12),
              if (recent.isEmpty)
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Text(
                    'لا توجد إنجازات بعدُ. افتح الورد اليومي، واضغط على الدائرة بعد أن تُتمّ مهمتك.',
                    style: TextStyle(color: kMuted, height: 1.7),
                  ),
                ),
              for (final l in recent)
                Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: cardDeco(radius: 16),
                  child: Row(children: [
                    CheckDot(
                        on: true,
                        size: 24,
                        color: kSectionGradients[l.entry.section.index][0]),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(l.entry.fullName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700, fontSize: 15)),
                            const SizedBox(height: 2),
                            Text('${l.entry.section.label} • ${l.date}',
                                style: TextStyle(
                                    fontSize: 12, color: kMuted)),
                          ]),
                    ),
                  ]),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Box extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _Box(this.label, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: cardDeco(radius: 20),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: color.withAlpha(28), shape: BoxShape.circle),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(value,
                        style: TextStyle(
                            fontSize: 26,
                            height: 1.1,
                            fontWeight: FontWeight.w800,
                            color: color)),
                    const SizedBox(height: 2),
                    Text(label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: kMuted, fontSize: 13)),
                  ]),
            ),
          ]),
        ),
      );
}
