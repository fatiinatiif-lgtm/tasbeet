// lib/features/stats/stats_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

class StatsScreen extends ConsumerWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final recent = s.logs.reversed.take(60).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('الإحصائيات'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            _Box('اليوم', '${s.doneToday}'),
            const SizedBox(width: 10),
            _Box('الإجمالي', '${s.totalCompleted}'),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            _Box('أيام متواصلة', '${s.streak}'),
            const SizedBox(width: 10),
            _Box('النقاط', '${s.xp}'),
          ]),
          const SizedBox(height: 20),
          const Text('حسب القسم',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final sec in Section.values)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: kBorder),
              ),
              child: Row(children: [
                Icon(sec.icon, color: kGreen),
                const SizedBox(width: 10),
                Expanded(child: Text(sec.label)),
                Text('${s.completedIn(sec)}',
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: kGreen)),
              ]),
            ),
          const SizedBox(height: 16),
          const Text('آخر ما أنجزتيه',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (recent.isEmpty)
            const Text('لسه مفيش إنجازات. افتحي الورد اليومي واضغطي على الدايرة بعد ما تخلّصي.',
                style: TextStyle(color: Colors.black54, height: 1.6)),
          for (final l in recent)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder),
              ),
              child: Row(children: [
                const Icon(Icons.check_circle, color: kGreen, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.entry.fullName,
                            style:
                                const TextStyle(fontWeight: FontWeight.w600)),
                        Text('${l.entry.section.label} • ${l.date}',
                            style: const TextStyle(
                                fontSize: 12, color: Colors.black54)),
                      ]),
                ),
              ]),
            ),
        ],
      ),
    );
  }
}

class _Box extends StatelessWidget {
  final String label, value;
  const _Box(this.label, this.value);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kBorder),
          ),
          child: Column(children: [
            Text(value,
                style: const TextStyle(
                    fontSize: 28, fontWeight: FontWeight.w700, color: kGreen)),
            Text(label, style: const TextStyle(color: Colors.black54)),
          ]),
        ),
      );
}
