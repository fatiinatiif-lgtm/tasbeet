// lib/features/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../khatma/khatma_screen.dart';
import 'motivation_box.dart';
import 'section_tile.dart';
import '../qiyam/qiyam_screen.dart';
import '../select/select_screen.dart';
import '../stats/stats_screen.dart';
import '../titles/titles_screen.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    void open(Widget page) =>
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

    final tiles = <Widget>[
      for (final sec in Section.values)
        SectionTile(
          colors: kSectionGradients[sec.index],
          icon: sec.icon,
          title: sec.label,
          sub: sec == Section.reading
              ? _khatmaSub(s.khatma)
              : sec == Section.qiyam
                  ? (s.countIn(sec) == 0 ? 'اختر أجزاءك' : '${s.countIn(sec)} من 30 جزءًا')
                  : (s.countIn(sec) == 0 ? 'لم تختر بعدُ' : '${s.countIn(sec)} مختار'),
          onTap: () => open(sec == Section.reading
              ? const KhatmaScreen()
              : sec == Section.qiyam
                  ? const QiyamScreen()
                  : SelectScreen(section: sec)),
        ),
      SectionTile(
        colors: const [Color(0xFF8E4A7C), Color(0xFF5B2750)],
        icon: Icons.emoji_events_rounded,
        title: 'ألقابي',
        sub: titleForXp(s.xp),
        onTap: () => open(const TitlesScreen()),
      ),
      SectionTile(
        colors: const [Color(0xFF4A6572), Color(0xFF2A3A43)],
        icon: Icons.bar_chart_rounded,
        title: 'الإحصائيات',
        sub: 'اليوم: ${s.doneToday}',
        onTap: () => open(const StatsScreen()),
      ),
    ];

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _HomeHeader(xp: s.xp),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const MotivationBox(),
              const SizedBox(height: 18),
              _WirdCard(
                done: s.doneToday,
                total: s.entries.length,
                onTap: () => open(const WirdScreen()),
              ),
              const SizedBox(height: 26),
              const SectionTitle('الأقسام'),
              const SizedBox(height: 14),
              GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 0.96,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: tiles,
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

String _khatmaSub(KhatmaPlan? k) {
  if (k == null) return 'ابدأ ختمتك';
  if (!k.hasActive) return 'أتممتَ الختمة';
  return 'اليوم ${k.activeIndex} من ${k.days}';
}

class _HomeHeader extends StatelessWidget {
  final int xp;
  const _HomeHeader({required this.xp});

  @override
  Widget build(BuildContext context) {
    return ScreenHeader(
      showBack: false,
      title: 'مرحبًا بك يا حامل القرآن',
      subtitle: 'السلام عليكم ورحمة الله وبركاته',
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(30),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kGold.withAlpha(160)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.military_tech_rounded, color: kGoldLight, size: 20),
          const SizedBox(width: 5),
          Text(titleForXp(xp),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}

class _WirdCard extends StatelessWidget {
  final int done, total;
  final VoidCallback onTap;
  const _WirdCard(
      {required this.done, required this.total, required this.onTap});

  String get _msg {
    if (total == 0) return 'لم تختر وردك بعدُ، فاختر من الأقسام أدناه';
    if (done >= total) return 'أتممتَ وردك اليوم، تقبّل الله منك';
    return 'أنجزتَ $done من $total، واصل بارك الله فيك';
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(120)),
        child: Row(children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 70,
                height: 70,
                child: CircularProgressIndicator(
                  value: total == 0 ? 0 : done / total,
                  strokeWidth: 7,
                  color: kGreen,
                  backgroundColor: kBorder,
                ),
              ),
              Text('$done/$total',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: kGreen)),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('وردك اليوم من القرآن الكريم',
                  style: TextStyle(
                      fontSize: 17.5,
                      fontWeight: FontWeight.w800,
                      color: kInk)),
              const SizedBox(height: 5),
              Text(_msg,
                  style: TextStyle(color: kMuted, height: 1.5)),
            ]),
          ),
          Icon(Icons.arrow_forward_ios_rounded, size: 17, color: kGold),
        ]),
      ),
    );
  }
}
