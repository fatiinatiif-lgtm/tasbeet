// lib/features/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import '../select/select_screen.dart';
import '../stats/stats_screen.dart';
import '../titles/titles_screen.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    void open(Widget page) =>
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

    final tileColors = const [
      Color(0xFF0F5C4D),
      Color(0xFF1F6F8B),
      Color(0xFF8A6A1F),
      Color(0xFF3F5E9E),
      Color(0xFF7A3E6B),
      Color(0xFF37474F),
    ];

    final tiles = <Widget>[
      for (final sec in Section.values)
        _Tile(
          color: tileColors[sec.index],
          icon: sec.icon,
          title: sec.label,
          sub: '${s.countIn(sec)} مختار',
          onTap: () => open(SelectScreen(section: sec)),
        ),
      _Tile(
        color: tileColors[4],
        icon: Icons.emoji_events,
        title: 'ألقابي',
        sub: titleForXp(s.xp),
        onTap: () => open(const TitlesScreen()),
      ),
      _Tile(
        color: tileColors[5],
        icon: Icons.bar_chart,
        title: 'الإحصائيات',
        sub: 'اليوم: ${s.doneToday}',
        onTap: () => open(const StatsScreen()),
      ),
    ];

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('السلام عليكم',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            _WirdButton(
              done: s.doneToday,
              total: s.entries.length,
              onTap: () => open(const WirdScreen()),
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: tiles,
            ),
          ],
        ),
      ),
    );
  }
}

class _WirdButton extends StatelessWidget {
  final int done, total;
  final VoidCallback onTap;
  const _WirdButton(
      {required this.done, required this.total, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: kGreen,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('الورد اليومي من القرآن الكريم',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 19,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(
            total == 0
                ? 'اختاري ورد يومك من الأقسام تحت'
                : 'خلّصتي $done من $total النهاردة',
            style: const TextStyle(color: Colors.white70),
          ),
          if (total > 0) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: done / total,
                minHeight: 8,
                color: Colors.white,
                backgroundColor: Colors.white24,
              ),
            ),
          ],
        ]),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _Tile(
      {required this.color,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: Colors.white, size: 38),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(color: Colors.white70)),
            ]),
          ],
        ),
      ),
    );
  }
}
