// lib/features/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../select/select_screen.dart';
import '../stats/stats_screen.dart';
import '../titles/titles_screen.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    void open(Widget page) =>
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

    final tiles = <Widget>[
      for (final sec in Section.values)
        _Tile(
          colors: kSectionGradients[sec.index],
          icon: sec.icon,
          title: sec.label,
          sub: s.countIn(sec) == 0 ? 'لم تختر بعدُ' : '${s.countIn(sec)} مختار',
          onTap: () => open(SelectScreen(section: sec)),
        ),
      _Tile(
        colors: const [Color(0xFF8E4A7C), Color(0xFF5B2750)],
        icon: Icons.emoji_events_rounded,
        title: 'ألقابي',
        sub: titleForXp(s.xp),
        onTap: () => open(const TitlesScreen()),
      ),
      _Tile(
        colors: const [Color(0xFF4A6572), Color(0xFF2A3A43)],
        icon: Icons.bar_chart_rounded,
        title: 'الإحصائيات',
        sub: 'اليوم: ${s.doneToday}',
        onTap: () => open(const StatsScreen()),
      ),
    ];

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _HomeHeader(xp: s.xp),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _WirdCard(
                done: s.doneToday,
                total: s.entries.length,
                onTap: () => open(const WirdScreen()),
              ),
              const SizedBox(height: 26),
              const SectionTitle('الأقسام'),
              const SizedBox(height: 14),
              GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 1.02,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: tiles,
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  final int xp;
  const _HomeHeader({required this.xp});

  @override
  Widget build(BuildContext context) {
    return ScreenHeader(
      showBack: false,
      title: 'مرحبًا بك يا حامل القرآن',
      subtitle: 'السلام عليكم ورحمة الله وبركاته',
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(30),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kGold.withAlpha(160)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.military_tech_rounded, color: kGoldLight, size: 20),
          const SizedBox(width: 5),
          Text(titleForXp(xp),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}

class _WirdCard extends StatelessWidget {
  final int done, total;
  final VoidCallback onTap;
  const _WirdCard(
      {required this.done, required this.total, required this.onTap});

  String get _msg {
    if (total == 0) return 'لم تختر وردك بعدُ، فاختر من الأقسام أدناه';
    if (done >= total) return 'أتممتَ وردك اليوم، تقبّل الله منك';
    return 'أنجزتَ $done من $total، واصل بارك الله فيك';
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(120)),
        child: Row(children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 70,
                height: 70,
                child: CircularProgressIndicator(
                  value: total == 0 ? 0 : done / total,
                  strokeWidth: 7,
                  color: kGreen,
                  backgroundColor: kBorder,
                ),
              ),
              Text('$done/$total',
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: kGreen)),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('وردك اليوم من القرآن الكريم',
                  style: TextStyle(
                      fontSize: 17.5,
                      fontWeight: FontWeight.w800,
                      color: kInk)),
              const SizedBox(height: 5),
              Text(_msg,
                  style: const TextStyle(color: Colors.black54, height: 1.5)),
            ]),
          ),
          const Icon(Icons.arrow_forward_ios_rounded, size: 17, color: kGold),
        ]),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _Tile(
      {required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    const r = BorderRadius.all(Radius.circular(24));
    return Container(
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: [
          BoxShadow(
            color: colors.last.withAlpha(90),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Material(
        borderRadius: r,
        clipBehavior: Clip.antiAlias,
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: r,
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: colors,
            ),
          ),
          child: InkWell(
            onTap: onTap,
            child: Stack(children: [
              const PatternLayer(alpha: 18, cell: 38),
              Positioned(
                left: -22,
                bottom: -22,
                child: Icon(icon, size: 116, color: Colors.white.withAlpha(26)),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withAlpha(38),
                        border: Border.all(color: kGoldLight.withAlpha(170)),
                      ),
                      child: Icon(icon, color: Colors.white, size: 26),
                    ),
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withAlpha(36),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(sub,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 12.5)),
                      ),
                    ]),
                  ],
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
