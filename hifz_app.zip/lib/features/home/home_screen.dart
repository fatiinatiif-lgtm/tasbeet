// lib/features/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../../data/quran/surah_data.dart';
import '../khatma/khatma_screen.dart';
import 'motivation_box.dart';
import '../../core/tile_style.dart';
import 'section_tile.dart';
import '../nawafil/nawafil_provider.dart';
import '../nawafil/nawafil_screen.dart';
import '../plan/plan_provider.dart';
import '../prayer/prayer_screen.dart';
import '../plan/plan_screen.dart';
import '../qiyam/qiyam_screen.dart';
import '../select/select_screen.dart';
import '../stats/stats_screen.dart';
import '../titles/titles_screen.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final plan = ref.watch(hifzPlanProvider);
    final naw = ref.watch(nawafilProvider);
    final style = TileStyle.values[ref.watch(tileStyleProvider)];

    void open(Widget page) =>
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

    final tiles = <Widget>[
      for (final sec in Section.values)
        SectionTile(
        style: style,
          colors: kSectionGradients[sec.index],
          icon: sec.icon,
          title: sec.label,
          sub: sec == Section.reading
              ? _khatmaSub(s.khatma)
              : sec == Section.qiyam
                  ? _qiyamSub(s)
                  : (s.countIn(sec) == 0 ? 'لم تختر بعدُ' : '${s.countIn(sec)} مختار'),
          onTap: () => open(sec == Section.reading
              ? const KhatmaScreen()
              : sec == Section.qiyam
                  ? const QiyamScreen()
                  : SelectScreen(section: sec)),
        ),
      SectionTile(
        style: style,
        colors: kSectionGradients[5],
        icon: Icons.timeline_rounded,
        title: 'خطة الحفظ',
        sub: plan == null
            ? 'ابدأ خطتك'
            : (plan.finished
                ? 'أتممتَ ${surahName(plan.surah)}'
                : '${surahName(plan.surah)} • ${(plan.done * 100 / plan.total).round()}%'),
        onTap: () => open(const PlanScreen()),
      ),
      SectionTile(
        style: style,
        colors: kSectionGradients[6],
        icon: Icons.wb_twilight_rounded,
        title: 'النوافل',
        sub: 'اليوم: ${nawafilCountOn(naw, todayString())}/${kNawafil.length}',
        onTap: () => open(const NawafilScreen()),
      ),
      SectionTile(
        style: style,
        colors: kSectionGradients[7],
        icon: Icons.emoji_events_rounded,
        title: 'ألقابي',
        sub: titleForXp(s.xp),
        onTap: () => open(const TitlesScreen()),
      ),
      SectionTile(
        style: style,
        colors: kSectionGradients[8],
        icon: Icons.bar_chart_rounded,
        title: 'الإحصائيات',
        sub: 'اليوم: ${s.doneToday}',
        onTap: () => open(const StatsScreen()),
      ),
    ];

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _HomeHeader(xp: s.xp),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const MotivationBox(),
              const SizedBox(height: 18),
              _WirdCard(
                done: s.doneToday,
                total: s.entries.length,
                onTap: () => open(const WirdScreen()),
              ),
              const SizedBox(height: 14),
              const PrayerCard(),
              const SizedBox(height: 26),
              const SectionTitle('الأقسام'),
              const SizedBox(height: 14),
              LayoutBuilder(
                  builder: (context, c) => _layoutTiles(style, tiles, c.maxWidth)),
            ]),
          ),
        ],
      ),
    );
  }
}

String _khatmaSub(KhatmaPlan? k) {
  if (k == null) return 'ابدأ ختمتك';
  if (!k.hasActive) return 'أتممتَ الختمة';
  return 'اليوم ${k.activeIndex} من ${k.days}';
}

class _HomeHeader extends StatelessWidget {
  final int xp;
  const _HomeHeader({required this.xp});

  @override
  Widget build(BuildContext context) {
    return ScreenHeader(
      showBack: false,
      title: 'مرحبًا بك يا حامل القرآن',
      subtitle: 'السلام عليكم ورحمة الله وبركاته',
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(30),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kGold.withAlpha(160)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.military_tech_rounded, color: kGoldLight, size: 20),
          const SizedBox(width: 5),
          Text(titleForXp(xp),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}

class _WirdCard extends StatelessWidget {
  final int done, total;
  final VoidCallback onTap;
  const _WirdCard(
      {required this.done, required this.total, required this.onTap});

  String get _msg {
    if (total == 0) return 'لم تختر وردك بعدُ، فاختر من الأقسام أدناه';
    if (done >= total) return 'أتممتَ وردك اليوم، تقبّل الله منك';
    return 'أنجزتَ $done من $total، واصل بارك الله فيك';
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(120)),
        child: Row(children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 70,
                height: 70,
                child: CircularProgressIndicator(
                  value: total == 0 ? 0 : done / total,
                  strokeWidth: 7,
                  color: kGreen,
                  backgroundColor: kBorder,
                ),
              ),
              Text('$done/$total',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: kGreen)),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('وردك اليوم من القرآن الكريم',
                  style: TextStyle(
                      fontSize: 17.5,
                      fontWeight: FontWeight.w800,
                      color: kInk)),
              const SizedBox(height: 5),
              Text(_msg,
                  style: TextStyle(color: kMuted, height: 1.5)),
            ]),
          ),
          Icon(Icons.arrow_forward_ios_rounded, size: 17, color: kGold),
        ]),
      ),
    );
  }
}

/// ترتيب المربعات بحسب الشكل المختار
Widget _layoutTiles(TileStyle style, List<Widget> tiles, double maxW) {
  const gap = 14.0;
  final half = (maxW - gap) / 2;
  final third = (maxW - 2 * 12) / 3;
  final n = tiles.length;

  double width(int i) {
    switch (style) {
      case TileStyle.list:
        return maxW;
      case TileStyle.compact:
      case TileStyle.circles:
        return third;
      case TileStyle.featured:
        if (i == 0) return maxW;
        return (i == n - 1 && (n - 1).isOdd) ? maxW : half;
      case TileStyle.classic:
      case TileStyle.cards:
        return (i == n - 1 && n.isOdd) ? maxW : half;
    }
  }

  double height(int i) {
    switch (style) {
      case TileStyle.list:
        return 88;
      case TileStyle.compact:
        return third * 1.05;
      case TileStyle.circles:
        return third * 1.2;
      case TileStyle.featured:
        return i == 0 ? 172 : half / 0.96;
      case TileStyle.classic:
        return half / 0.96;
      case TileStyle.cards:
        return half / 0.98;
    }
  }

  final spacing = (style == TileStyle.compact || style == TileStyle.circles)
      ? 12.0
      : gap;
  return Wrap(
    spacing: spacing,
    runSpacing: style == TileStyle.list ? 12 : spacing,
    children: [
      for (var i = 0; i < n; i++)
        SizedBox(width: width(i), height: height(i), child: tiles[i]),
    ],
  );
}


String _qiyamSub(WirdState s) {
  final q = s.userEntries.where((e) => e.section == Section.qiyam);
  final j = q.where((e) => e.type == UnitType.juz).length;
  final r = q.where((e) => e.type == UnitType.surah).length;
  if (j == 0 && r == 0) return 'اختر أجزاءك أو سورك';
  return [
    if (j > 0) '$j من 30 جزءًا',
    if (r > 0) '$r من السور',
  ].join(' • ');
}
