// lib/features/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../profile/profile_provider.dart';
import '../shell/app_shell.dart';

const _green = Color(0xFF0F5C4D);

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(profileProvider);
    final due = ref.watch(dueCountProvider).value ?? 0;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('السلام عليكم يا ${p.name}',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('لقبك: ${p.title}',
              style: const TextStyle(color: Colors.black54, fontSize: 16)),
          const SizedBox(height: 20),
          Row(children: [
            _Stat(label: 'أيام متواصلة', value: '${p.currentStreak}'),
            const SizedBox(width: 12),
            _Stat(label: 'نقاطك', value: '${p.xp}'),
          ]),
          const SizedBox(height: 20),
          _ActionCard(
            title: due == 0 ? 'مراجعة اليوم خلصت' : 'عندك $due للمراجعة',
            subtitle: due == 0 ? 'ما شاء الله، كمّلي بحفظ جديد' : 'ابدئي بالأضعف حفظاً',
            filled: due > 0,
            onTap: () => ref.read(tabIndexProvider.notifier).state = 2,
          ),
          const SizedBox(height: 12),
          _ActionCard(
            title: 'حفظ جديد',
            subtitle: 'سجّلي آيات حفظتيها النهاردة',
            onTap: () => ref.read(tabIndexProvider.notifier).state = 1,
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label, value;
  const _Stat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFD9E4E1)),
          ),
          child: Column(children: [
            Text(value,
                style: const TextStyle(
                    fontSize: 28, fontWeight: FontWeight.w700, color: _green)),
            Text(label, style: const TextStyle(color: Colors.black54)),
          ]),
        ),
      );
}

class _ActionCard extends StatelessWidget {
  final String title, subtitle;
  final bool filled;
  final VoidCallback onTap;
  const _ActionCard(
      {required this.title,
      required this.subtitle,
      required this.onTap,
      this.filled = false});

  @override
  Widget build(BuildContext context) {
    final fg = filled ? Colors.white : const Color(0xFF14211E);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: filled ? _green : Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFD9E4E1)),
        ),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      fontSize: 19, fontWeight: FontWeight.w700, color: fg)),
              const SizedBox(height: 4),
              Text(subtitle, style: TextStyle(color: fg.withOpacity(0.75))),
            ]),
          ),
          Icon(Icons.chevron_left, color: fg),
        ]),
      ),
    );
  }
}
