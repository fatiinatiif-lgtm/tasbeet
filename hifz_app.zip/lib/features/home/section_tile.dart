// lib/features/home/section_tile.dart
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/tile_style.dart';
import '../../core/widgets.dart';

/// مربع قسم في الصفحة الرئيسية: تدرّج + نقش + إطار ذهبي مزدوج + توهّج
class _ClassicTile extends StatefulWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _ClassicTile(
      {super.key,
      required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  State<_ClassicTile> createState() => _ClassicTileState();
}

class _ClassicTileState extends State<_ClassicTile> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const r = BorderRadius.all(Radius.circular(26));
    final c = widget.colors;
    final light = Color.lerp(c.first, Colors.white, 0.14)!;

    return AnimatedScale(
      scale: _down ? 0.96 : 1,
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOut,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: r,
          boxShadow: [
            BoxShadow(
              color: c.last.withAlpha(110),
              blurRadius: 18,
              offset: const Offset(0, 9),
            ),
          ],
        ),
        child: Material(
          borderRadius: r,
          clipBehavior: Clip.antiAlias,
          color: Colors.transparent,
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: r,
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [light, c.first, c.last],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
            child: InkWell(
              onTap: widget.onTap,
              onHighlightChanged: (v) => setState(() => _down = v),
              child: Stack(children: [
                const PatternLayer(alpha: 14, cell: 36),
                // توهّج ناعم في الزاوية العليا
                Positioned(
                  top: -40,
                  right: -40,
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        Colors.white.withAlpha(70),
                        Colors.white.withAlpha(0),
                      ]),
                    ),
                  ),
                ),
                // أيقونة كبيرة شفّافة في الخلفية
                Positioned(
                  left: -26,
                  bottom: -26,
                  child: Transform.rotate(
                    angle: -0.18,
                    child: Icon(widget.icon,
                        size: 124, color: Colors.white.withAlpha(30)),
                  ),
                ),
                // إطار ذهبي داخلي
                Positioned.fill(
                  child: IgnorePointer(
                    child: Container(
                      margin: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(21),
                        border: Border.all(
                            color: kGoldLight.withAlpha(95), width: 1),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [
                                  Colors.white.withAlpha(70),
                                  Colors.white.withAlpha(22),
                                ],
                              ),
                              border: Border.all(
                                  color: kGoldLight.withAlpha(200),
                                  width: 1.4),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withAlpha(40),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(widget.icon,
                                color: Colors.white, size: 27),
                          ),
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withAlpha(34),
                            ),
                            child: const Icon(Icons.arrow_back_rounded,
                                color: Colors.white, size: 16),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18.5,
                              height: 1.25,
                              fontWeight: FontWeight.w800,
                              shadows: [
                                Shadow(
                                    color: Colors.black26,
                                    blurRadius: 4,
                                    offset: Offset(0, 1)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.black.withAlpha(48),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: Colors.white.withAlpha(46)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                      color: kGoldLight,
                                      shape: BoxShape.circle),
                                ),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    widget.sub,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// مربع قسم بالشكل المختار من الإعدادات
class SectionTile extends StatelessWidget {
  final TileStyle style;
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const SectionTile(
      {super.key,
      this.style = TileStyle.classic,
      required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    switch (style) {
      case TileStyle.classic:
      case TileStyle.featured:
        return _ClassicTile(
            colors: colors, icon: icon, title: title, sub: sub, onTap: onTap);
      case TileStyle.list:
        return _ListRow(
            colors: colors, icon: icon, title: title, sub: sub, onTap: onTap);
      case TileStyle.compact:
        return _CompactTile(
            colors: colors, icon: icon, title: title, sub: sub, onTap: onTap);
      case TileStyle.cards:
        return _CardTile(
            colors: colors, icon: icon, title: title, sub: sub, onTap: onTap);
      case TileStyle.circles:
        return _CircleTile(
            colors: colors, icon: icon, title: title, sub: sub, onTap: onTap);
    }
  }
}

/// غلاف يعطي حركة انكماش عند اللمس
class _Press extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _Press({required this.child, required this.onTap});

  @override
  State<_Press> createState() => _PressState();
}

class _PressState extends State<_Press> {
  bool _down = false;

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: widget.onTap,
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) => setState(() => _down = false),
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedScale(
          scale: _down ? 0.95 : 1,
          duration: const Duration(milliseconds: 110),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      );
}

BoxDecoration _gradDeco(List<Color> c, double radius) => BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [Color.lerp(c.first, Colors.white, 0.14)!, c.first, c.last],
        stops: const [0.0, 0.45, 1.0],
      ),
      boxShadow: [
        BoxShadow(
          color: c.last.withAlpha(100),
          blurRadius: 14,
          offset: const Offset(0, 7),
        ),
      ],
    );

Widget _glassIcon(IconData icon, double size, double iconSize) => Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.white.withAlpha(70), Colors.white.withAlpha(22)],
        ),
        border: Border.all(color: kGoldLight.withAlpha(200), width: 1.3),
      ),
      child: Icon(icon, color: Colors.white, size: iconSize),
    );

/// شكل القائمة: صفوف عريضة
class _ListRow extends StatelessWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _ListRow(
      {required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) => _Press(
        onTap: onTap,
        child: Container(
          decoration: _gradDeco(colors, 22),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Stack(children: [
              const PatternLayer(alpha: 12, cell: 34),
              Positioned(
                left: -18,
                bottom: -22,
                child: Icon(icon, size: 96, color: Colors.white.withAlpha(26)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  _glassIcon(icon, 52, 27),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 3),
                        Text(sub,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withAlpha(34)),
                    child: const Icon(Icons.arrow_back_rounded,
                        color: Colors.white, size: 17),
                  ),
                ]),
              ),
            ]),
          ),
        ),
      );
}

/// شكل مدمج: مربعات صغيرة (3 في الصف)
class _CompactTile extends StatelessWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _CompactTile(
      {required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) => _Press(
        onTap: onTap,
        child: Container(
          decoration: _gradDeco(colors, 20),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(children: [
              const PatternLayer(alpha: 12, cell: 30),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _glassIcon(icon, 40, 22),
                    const SizedBox(height: 8),
                    Text(title,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            height: 1.25,
                            fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ]),
          ),
        ),
      );
}

/// شكل البطاقات: بطاقة بيضاء بشريط ملوّن
class _CardTile extends StatelessWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _CardTile(
      {required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) => _Press(
        onTap: onTap,
        child: Container(
          decoration: cardDeco(radius: 22),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Column(children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          gradient: LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: colors,
                          ),
                        ),
                        child: Icon(icon, color: Colors.white, size: 26),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: kInk,
                                  fontSize: 17,
                                  height: 1.25,
                                  fontWeight: FontWeight.w800)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 9, vertical: 3),
                            decoration: BoxDecoration(
                              color: colors.first.withAlpha(30),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(sub,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: colors.first,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: 5,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [colors.first, colors.last]),
                ),
              ),
            ]),
          ),
        ),
      );
}

/// شكل الدوائر: أيقونات دائرية بعنوان تحتها
class _CircleTile extends StatelessWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const _CircleTile(
      {required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  Widget build(BuildContext context) => _Press(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 66,
              height: 66,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [Color.lerp(colors.first, Colors.white, 0.14)!, colors.last],
                ),
                border: Border.all(color: kGold, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: colors.last.withAlpha(100),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 31),
            ),
            const SizedBox(height: 8),
            Text(title,
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: kInk,
                    fontSize: 13,
                    height: 1.25,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(sub,
                maxLines: 1,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: kMuted, fontSize: 11.5)),
          ],
        ),
      );
}
