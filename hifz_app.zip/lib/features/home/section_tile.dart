// lib/features/home/section_tile.dart
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

/// مربع قسم في الصفحة الرئيسية: تدرّج + نقش + إطار ذهبي مزدوج + توهّج
class SectionTile extends StatefulWidget {
  final List<Color> colors;
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const SectionTile(
      {super.key,
      required this.colors,
      required this.icon,
      required this.title,
      required this.sub,
      required this.onTap});

  @override
  State<SectionTile> createState() => _SectionTileState();
}

class _SectionTileState extends State<SectionTile> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const r = BorderRadius.all(Radius.circular(26));
    final c = widget.colors;
    final light = Color.lerp(c.first, Colors.white, 0.14)!;

    return AnimatedScale(
      scale: _down ? 0.96 : 1,
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOut,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: r,
          boxShadow: [
            BoxShadow(
              color: c.last.withAlpha(110),
              blurRadius: 18,
              offset: const Offset(0, 9),
            ),
          ],
        ),
        child: Material(
          borderRadius: r,
          clipBehavior: Clip.antiAlias,
          color: Colors.transparent,
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: r,
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [light, c.first, c.last],
                stops: const [0.0, 0.45, 1.0],
              ),
            ),
            child: InkWell(
              onTap: widget.onTap,
              onHighlightChanged: (v) => setState(() => _down = v),
              child: Stack(children: [
                const PatternLayer(alpha: 14, cell: 36),
                // توهّج ناعم في الزاوية العليا
                Positioned(
                  top: -40,
                  right: -40,
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        Colors.white.withAlpha(70),
                        Colors.white.withAlpha(0),
                      ]),
                    ),
                  ),
                ),
                // أيقونة كبيرة شفّافة في الخلفية
                Positioned(
                  left: -26,
                  bottom: -26,
                  child: Transform.rotate(
                    angle: -0.18,
                    child: Icon(widget.icon,
                        size: 124, color: Colors.white.withAlpha(30)),
                  ),
                ),
                // إطار ذهبي داخلي
                Positioned.fill(
                  child: IgnorePointer(
                    child: Container(
                      margin: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(21),
                        border: Border.all(
                            color: kGoldLight.withAlpha(95), width: 1),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [
                                  Colors.white.withAlpha(70),
                                  Colors.white.withAlpha(22),
                                ],
                              ),
                              border: Border.all(
                                  color: kGoldLight.withAlpha(200),
                                  width: 1.4),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withAlpha(40),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(widget.icon,
                                color: Colors.white, size: 27),
                          ),
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withAlpha(34),
                            ),
                            child: const Icon(Icons.arrow_back_rounded,
                                color: Colors.white, size: 16),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18.5,
                              height: 1.25,
                              fontWeight: FontWeight.w800,
                              shadows: [
                                Shadow(
                                    color: Colors.black26,
                                    blurRadius: 4,
                                    offset: Offset(0, 1)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.black.withAlpha(48),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: Colors.white.withAlpha(46)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                      color: kGoldLight,
                                      shape: BoxShape.circle),
                                ),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    widget.sub,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
