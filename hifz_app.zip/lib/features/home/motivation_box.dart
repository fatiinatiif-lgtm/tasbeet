// lib/features/home/motivation_box.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/motivation.dart';
import '../wird/wird_provider.dart';

/// صندوق العبارة التحفيزية: عبارة جديدة عند كل فتح للتطبيق
class MotivationBox extends ConsumerStatefulWidget {
  const MotivationBox({super.key});

  @override
  ConsumerState<MotivationBox> createState() => _MotivationBoxState();
}

class _MotivationBoxState extends ConsumerState<MotivationBox> {
  static const _key = 'quote_last_v1';
  late int _i;

  @override
  void initState() {
    super.initState();
    final prefs = ref.read(sharedPrefsProvider);
    final last = prefs.getInt(_key) ?? -1;
    _i = _pick(last);
    prefs.setInt(_key, _i);
  }

  int _pick(int avoid) {
    final r = Random();
    var n = r.nextInt(kQuotes.length);
    if (n == avoid && kQuotes.length > 1) n = (n + 1) % kQuotes.length;
    return n;
  }

  void _next() {
    final n = _pick(_i);
    ref.read(sharedPrefsProvider).setInt(_key, n);
    setState(() => _i = n);
  }

  @override
  Widget build(BuildContext context) {
    final q = kQuotes[_i];
    const r = BorderRadius.all(Radius.circular(24));
    return Container(
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: [
          BoxShadow(
            color: kGreenDark.withAlpha(90),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: r,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [kGreen, kGreenDark],
            ),
            border: Border.all(color: kGold.withAlpha(170), width: 1.2),
            borderRadius: r,
          ),
          child: Stack(children: [
            const PatternLayer(alpha: 16, cell: 40),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 12, 16),
              child: Column(children: [
                Row(children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: kGold,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(q.isAyah ? 'آية • ${q.topic}' : 'حديث • ${q.topic}',
                        style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                            color: kInk)),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: 'عبارة أخرى',
                    visualDensity: VisualDensity.compact,
                    onPressed: _next,
                    icon: Icon(Icons.refresh_rounded, color: kGoldLight),
                  ),
                ]),
                const SizedBox(height: 4),
                Text(
                  q.text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontFamily: 'ArefRuqaa',
                    fontWeight: FontWeight.w700,
                    fontSize: 21,
                    height: 1.9,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text('— ${q.source} —',
                    style: TextStyle(
                        color: kGoldLight,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w700)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
