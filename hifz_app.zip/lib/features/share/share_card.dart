// lib/features/share/share_card.dart
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/motivation.dart';
import '../wird/wird_provider.dart';

/// يعرض بطاقة الإنجاز مع زر المشاركة كصورة
Future<void> showShareCard(BuildContext context, WirdState s, int badges) {
  return showDialog<void>(
    context: context,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: _ShareDialog(state: s, badges: badges),
    ),
  );
}

class _ShareDialog extends ConsumerStatefulWidget {
  final WirdState state;
  final int badges;
  const _ShareDialog({required this.state, required this.badges});

  @override
  ConsumerState<_ShareDialog> createState() => _ShareDialogState();
}

class _ShareDialogState extends ConsumerState<_ShareDialog> {
  static const _nameKey = 'share_name_v1';
  final _key = GlobalKey();
  late String _name =
      ref.read(sharedPrefsProvider).getString(_nameKey) ?? '';
  late final List<Quote> _short =
      kQuotes.where((q) => q.text.length <= 100).toList();
  late int _i = (widget.state.totalCompleted + widget.state.xp) % _short.length;
  bool _busy = false;

  Future<void> _editName() async {
    final c = TextEditingController(text: _name);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('اسمك على البطاقة',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: TextField(
            controller: c,
            autofocus: true,
            maxLength: 24,
            textInputAction: TextInputAction.done,
            onSubmitted: (v) => Navigator.pop(ctx, v.trim()),
            decoration: InputDecoration(
              hintText: 'اكتب اسمك',
              helperText: 'اتركه فارغًا لإخفاء الاسم',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('إلغاء')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: kGreen),
              onPressed: () => Navigator.pop(ctx, c.text.trim()),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (v == null) return;
    final prefs = ref.read(sharedPrefsProvider);
    if (v.isEmpty) {
      prefs.remove(_nameKey);
    } else {
      prefs.setString(_nameKey, v);
    }
    setState(() => _name = v);
  }

  Future<void> _share() async {
    setState(() => _busy = true);
    try {
      final b = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await b.toImage(pixelRatio: 3.0);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/hifz_card.png');
      await f.writeAsBytes(data!.buffer.asUint8List());
      await Share.shareXFiles([XFile(f.path)],
          text: 'تقبّل الله منا ومنكم • تطبيق حفظ');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تعذّرت المشاركة، حاول مرة أخرى')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          RepaintBoundary(
            key: _key,
            child: _Card(
                state: widget.state,
                badges: widget.badges,
                quote: _short[_i],
                name: _name),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.tonalIcon(
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12)),
              onPressed: _editName,
              icon: Icon(_name.isEmpty
                  ? Icons.person_add_alt_1_rounded
                  : Icons.edit_rounded),
              label: Text(_name.isEmpty ? 'إضافة اسمي' : 'تعديل الاسم'),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: Colors.black87,
                    padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: _busy ? null : _share,
                icon: const Icon(Icons.share_rounded),
                label: Text(_busy ? 'لحظة...' : 'مشاركة'),
              ),
            ),
            const SizedBox(width: 10),
            IconButton.filledTonal(
              tooltip: 'عبارة أخرى',
              onPressed: () => setState(() => _i = (_i + 1) % _short.length),
              icon: const Icon(Icons.refresh_rounded),
            ),
            const SizedBox(width: 6),
            IconButton.filledTonal(
              tooltip: 'إغلاق',
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.close_rounded),
            ),
          ]),
        ]),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final WirdState state;
  final int badges;
  final Quote quote;
  final String name;
  const _Card(
      {required this.state,
      required this.badges,
      required this.quote,
      required this.name});

  @override
  Widget build(BuildContext context) {
    const r = BorderRadius.all(Radius.circular(28));
    return SizedBox(
      width: 320,
      height: 440,
      child: ClipRRect(
        borderRadius: r,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [kGreen, kGreenDark],
            ),
          ),
          child: Stack(children: [
            const PatternLayer(alpha: 18, cell: 40),
            Positioned.fill(
              child: Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kGoldLight.withAlpha(150)),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.menu_book_rounded, color: kGoldLight, size: 22),
                    const SizedBox(width: 8),
                    const Text('حفظ',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w800)),
                  ]),
                  Column(children: [
                    Container(
                      width: 66,
                      height: 66,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [kGoldLight, kGold]),
                      ),
                      child: const Icon(Icons.military_tech_rounded,
                          color: Colors.white, size: 40),
                    ),
                    const SizedBox(height: 10),
                    if (name.isNotEmpty) ...[
                      Text(name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: kGoldLight,
                              fontSize: 19,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                    ],
                    Text(titleForXp(state.xp),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.w800)),
                    Text('${state.xp} نقطة',
                        style: TextStyle(color: kGoldLight, fontSize: 14)),
                  ]),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.black.withAlpha(40),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(children: [
                      _Stat('${state.streak}', 'أيام متواصلة'),
                      _Stat('${state.totalCompleted}', 'مهمة منجزة'),
                      _Stat('$badges', 'وسامًا'),
                    ]),
                  ),
                  Column(children: [
                    Text(quote.text,
                        textAlign: TextAlign.center,
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 13.5, height: 1.7)),
                    const SizedBox(height: 4),
                    Text('— ${quote.source} —',
                        style: TextStyle(color: kGoldLight, fontSize: 12)),
                  ]),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String value, label;
  const _Stat(this.value, this.label);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Column(children: [
          Text(value,
              style: TextStyle(
                  color: kGoldLight, fontSize: 22, fontWeight: FontWeight.w800)),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
        ]),
      );
}
