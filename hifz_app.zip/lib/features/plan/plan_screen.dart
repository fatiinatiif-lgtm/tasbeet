// lib/features/plan/plan_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/celebration.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../../data/quran/surah_data.dart';
import '../wird/wird_provider.dart';
import 'plan_provider.dart';

const _durations = <(int, String)>[
  (7, 'أسبوع'),
  (10, '10 أيام'),
  (14, 'أسبوعان'),
  (21, '3 أسابيع'),
  (30, 'شهر'),
  (60, 'شهران'),
  (90, '3 أشهر'),
  (180, '6 أشهر'),
];

Widget _rtl(Widget child) =>
    Directionality(textDirection: TextDirection.rtl, child: child);

Future<int?> _pickSurah(BuildContext context) {
  return showModalBottomSheet<int>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kBg,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => _rtl(SizedBox(
      height: MediaQuery.of(ctx).size.height * 0.78,
      child: Column(children: [
        const SizedBox(height: 14),
        Text('اختر السورة',
            style: TextStyle(
                fontSize: 19, fontWeight: FontWeight.w800, color: kInk)),
        const SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: allSurahs.length,
            itemBuilder: (_, i) {
              final s = allSurahs[i];
              return ListTile(
                leading: NumBadge(text: '${s.number}', size: 42, color: kGreen),
                title: Text(s.name,
                    style: TextStyle(
                        fontWeight: FontWeight.w800, color: kInk)),
                subtitle: Text('${s.ayahCount} آية',
                    style: TextStyle(color: kMuted)),
                onTap: () => Navigator.pop(ctx, s.number),
              );
            },
          ),
        ),
      ]),
    )),
  );
}

Future<int?> _pickDays(BuildContext context, int surah) {
  final total = surahOf(surah).ayahCount;
  int? sel;
  return showDialog<int>(
    context: context,
    builder: (ctx) => _rtl(StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: Text('مدة حفظ سورة ${surahName(surah)}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final d in _durations)
              ChoiceChip(
                label: Text(d.$2),
                selected: sel == d.$1,
                selectedColor: kGreen.withAlpha(50),
                onSelected: (_) => setS(() => sel = d.$1),
              ),
          ]),
          const SizedBox(height: 16),
          Text(
            sel == null
                ? 'اختر المدة التي تناسبك'
                : 'تقريبًا ${(total + sel! - 1) ~/ sel!} آية يوميًا',
            style: TextStyle(color: kMuted, fontWeight: FontWeight.w700),
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kGreen),
            onPressed: sel == null ? null : () => Navigator.pop(ctx, sel),
            child: const Text('ابدأ الخطة'),
          ),
        ],
      ),
    )),
  );
}

class PlanScreen extends ConsumerWidget {
  const PlanScreen({super.key});

  Future<void> _start(BuildContext context, WidgetRef ref) async {
    final surah = await _pickSurah(context);
    if (surah == null || !context.mounted) return;
    final days = await _pickDays(context, surah);
    if (days == null) return;
    ref.read(hifzPlanProvider.notifier).start(surah, days);
  }

  Future<void> _extend(BuildContext context, WidgetRef ref) async {
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => _rtl(AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('تمديد المدة',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Wrap(spacing: 8, runSpacing: 8, children: [
          for (final d in const [(3, '3 أيام'), (7, 'أسبوع'), (14, 'أسبوعان'), (30, 'شهر')])
            ActionChip(
              label: Text(d.$2),
              onPressed: () => Navigator.pop(ctx, d.$1),
            ),
        ]),
      )),
    );
    if (v != null) ref.read(hifzPlanProvider.notifier).extend(v);
  }

  Future<void> _editProgress(
      BuildContext context, WidgetRef ref, HifzPlan p) async {
    final c = TextEditingController(text: '${p.done}');
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => _rtl(AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('كم آية تحفظها الآن؟',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            helperText: 'من 0 إلى ${p.total}',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kGreen),
            onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim())),
            child: const Text('حفظ'),
          ),
        ],
      )),
    );
    if (v != null) ref.read(hifzPlanProvider.notifier).setProgress(v);
  }

  Future<void> _cancel(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => _rtl(AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('إلغاء الخطة',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: const Text('سيُحذف تقدّمك في هذه الخطة. هل تريد المتابعة؟',
            style: TextStyle(height: 1.7)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('لا')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red[700]),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('نعم، ألغِ'),
          ),
        ],
      )),
    );
    if (ok == true) ref.read(hifzPlanProvider.notifier).cancel();
  }

  void _toggleToday(BuildContext context, WidgetRef ref, HifzPlan p) {
    final plan = ref.read(hifzPlanProvider.notifier);
    final wird = ref.read(wirdProvider.notifier);
    final entry = WirdEntry(Section.hifz, UnitType.plan, p.surah);
    final logged = ref.read(wirdProvider).isDoneToday(entry);
    if (!p.doneToday) {
      plan.complete();
      if (!logged) wird.toggleDone(entry);
      showCelebration(context, 'سورة ${surahName(p.surah)}');
    } else {
      plan.undo();
      if (logged) wird.toggleDone(entry);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(hifzPlanProvider);
    final colors = kSectionGradients[Section.hifz.index];

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'خطة الحفظ',
          subtitle: 'اختر سورة ومدة، ويوزّع التطبيق الآيات على أيامك',
          colors: colors,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: p == null
                ? [_Intro(onStart: () => _start(context, ref))]
                : _active(context, ref, p, colors[0]),
          ),
        ),
      ]),
    );
  }

  List<Widget> _active(
      BuildContext context, WidgetRef ref, HifzPlan p, Color accent) {
    final progress = p.total == 0 ? 0.0 : p.done / p.total;
    final r = p.todayRange;

    return [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(140)),
        child: Row(children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 70,
                height: 70,
                child: CircularProgressIndicator(
                  value: progress,
                  strokeWidth: 7,
                  color: accent,
                  backgroundColor: kBorder,
                ),
              ),
              Text('${(progress * 100).round()}%',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, color: accent)),
            ]),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('سورة ${surahName(p.surah)}',
                  style: TextStyle(
                      fontSize: 19, fontWeight: FontWeight.w800, color: kInk)),
              const SizedBox(height: 3),
              Text('حفظتَ ${p.done} من ${p.total} آية',
                  style: TextStyle(color: kMuted)),
              const SizedBox(height: 2),
              Text(
                  p.finished
                      ? 'أتممتَ السورة'
                      : (p.daysLeft >= 1
                          ? 'بقي ${p.daysLeft} يومًا (حتى ${p.end})'
                          : 'انتهت المدة (${p.end})'),
                  style: TextStyle(color: kMuted, fontSize: 13)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 16),
      if (p.overdue && !p.finished)
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.orange.withAlpha(34),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
              'انتهت المدة المحددة. يمكنك تمديدها، أو إكمال ما تبقى اليوم.',
              style: TextStyle(color: kInk, height: 1.6)),
        ),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: cardDeco(radius: 22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (r == null) ...[
            Row(children: [
              Icon(Icons.celebration_rounded, color: kGold, size: 28),
              const SizedBox(width: 10),
              Expanded(
                child: Text('أتممتَ حفظ السورة، تقبّل الله منك.',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, height: 1.6, color: kInk)),
              ),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                    backgroundColor: accent,
                    padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: () => _start(context, ref),
                icon: const Icon(Icons.add_rounded),
                label: const Text('ابدأ خطة جديدة'),
              ),
            ),
          ] else ...[
            Text('ورد اليوم', style: TextStyle(color: kMuted, fontSize: 13)),
            const SizedBox(height: 4),
            Text(
                r.$1 == r.$2
                    ? 'الآية ${r.$1}'
                    : 'من الآية ${r.$1} إلى الآية ${r.$2}',
                style: TextStyle(
                    fontSize: 21, fontWeight: FontWeight.w800, color: accent)),
            const SizedBox(height: 2),
            Text('${r.$2 - r.$1 + 1} آية',
                style: TextStyle(color: kMuted)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: p.doneToday ? kMuted : accent,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () => _toggleToday(context, ref, p),
                icon: Icon(p.doneToday ? Icons.undo_rounded : Icons.check_rounded),
                label: Text(p.doneToday
                    ? 'التراجع عن الإنجاز'
                    : 'أتممتُ حفظ ورد اليوم'),
              ),
            ),
          ],
        ]),
      ),
      const SizedBox(height: 12),
      Wrap(spacing: 4, runSpacing: 0, children: [
        TextButton.icon(
          onPressed: () => _editProgress(context, ref, p),
          icon: const Icon(Icons.edit_rounded, size: 18),
          label: const Text('تعديل ما حفظته'),
        ),
        TextButton.icon(
          onPressed: () => _extend(context, ref),
          icon: const Icon(Icons.update_rounded, size: 18),
          label: const Text('تمديد المدة'),
        ),
        TextButton.icon(
          onPressed: () => _cancel(context, ref),
          icon: Icon(Icons.close_rounded, color: Colors.red[700], size: 18),
          label:
              Text('إلغاء الخطة', style: TextStyle(color: Colors.red[700])),
        ),
      ]),
    ];
  }
}

class _Intro extends StatelessWidget {
  final VoidCallback onStart;
  const _Intro({required this.onStart});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(120)),
        child: Column(children: [
          Icon(Icons.timeline_rounded, size: 54, color: kGold),
          const SizedBox(height: 12),
          Text('ابدأ خطة حفظ',
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w800, color: kInk)),
          const SizedBox(height: 8),
          Text(
              'اختر السورة التي تريد حفظها والمدة، وسيحسب لك التطبيق ورد كل يوم، ويعيد توزيع ما تبقى إن تأخّرتَ أو سبقتَ.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kMuted, height: 1.7)),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                  backgroundColor: kGreen,
                  padding: const EdgeInsets.symmetric(vertical: 13)),
              onPressed: onStart,
              icon: const Icon(Icons.flag_rounded),
              label: const Text('اختيار سورة'),
            ),
          ),
        ]),
      );
}
