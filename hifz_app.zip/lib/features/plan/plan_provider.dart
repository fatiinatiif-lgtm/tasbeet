// lib/features/plan/plan_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/wird_models.dart';
import '../../data/quran/surah_data.dart';
import '../wird/wird_provider.dart';

/// خطة حفظ سورة خلال مدة محددة
class HifzPlan {
  final int surah;
  final String start, end; // yyyy-MM-dd
  final int done; // عدد الآيات المحفوظة حتى الآن
  final int prevDone; // قبل إنجاز اليوم (للتراجع)
  final String? lastDone; // تاريخ آخر إنجاز
  const HifzPlan({
    required this.surah,
    required this.start,
    required this.end,
    required this.done,
    required this.prevDone,
    required this.lastDone,
  });

  int get total => surahOf(surah).ayahCount;
  bool get finished => done >= total;
  bool get doneToday => lastDone == todayString();
  int get doneBeforeToday => doneToday ? prevDone : done;

  /// الأيام المتبقية بما فيها اليوم
  int get daysLeft {
    final n = DateTime.now();
    final e = DateTime.parse(end);
    return DateTime.utc(e.year, e.month, e.day)
            .difference(DateTime.utc(n.year, n.month, n.day))
            .inDays +
        1;
  }

  bool get overdue => daysLeft < 1;

  /// عدد آيات ورد اليوم
  int get perDay {
    final rem = total - doneBeforeToday;
    if (rem <= 0) return 0;
    final d = daysLeft < 1 ? 1 : daysLeft;
    return (rem + d - 1) ~/ d;
  }

  /// ورد اليوم (من آية، إلى آية) أو null إن اكتملت السورة
  (int, int)? get todayRange {
    final before = doneBeforeToday;
    if (before >= total) return null;
    final b = before + perDay > total ? total : before + perDay;
    return (before + 1, b);
  }

  Map<String, dynamic> toJson() => {
        's': surah,
        'a': start,
        'e': end,
        'd': done,
        'p': prevDone,
        'l': lastDone,
      };

  factory HifzPlan.fromJson(Map<String, dynamic> j) => HifzPlan(
        surah: j['s'] as int,
        start: j['a'] as String,
        end: j['e'] as String,
        done: j['d'] as int,
        prevDone: j['p'] as int,
        lastDone: j['l'] as String?,
      );
}

class HifzPlanNotifier extends Notifier<HifzPlan?> {
  static const _key = 'hifz_plan_v1';

  @override
  HifzPlan? build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return null;
    try {
      return HifzPlan.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  void _save(HifzPlan? p) {
    state = p;
    final prefs = ref.read(sharedPrefsProvider);
    if (p == null) {
      prefs.remove(_key);
    } else {
      prefs.setString(_key, jsonEncode(p.toJson()));
    }
  }

  /// بدء خطة لحفظ سورة خلال [days] يومًا (بما فيها اليوم)
  void start(int surah, int days) {
    final n = DateTime.now();
    final end = DateTime(n.year, n.month, n.day + days - 1);
    _save(HifzPlan(
      surah: surah,
      start: todayString(),
      end: dayString(end),
      done: 0,
      prevDone: 0,
      lastDone: null,
    ));
  }

  /// إتمام ورد اليوم
  void complete() {
    final p = state;
    final r = p?.todayRange;
    if (p == null || r == null || p.doneToday) return;
    _save(HifzPlan(
      surah: p.surah,
      start: p.start,
      end: p.end,
      done: r.$2,
      prevDone: p.done,
      lastDone: todayString(),
    ));
  }

  /// التراجع عن إنجاز اليوم
  void undo() {
    final p = state;
    if (p == null || !p.doneToday) return;
    _save(HifzPlan(
      surah: p.surah,
      start: p.start,
      end: p.end,
      done: p.prevDone,
      prevDone: p.prevDone,
      lastDone: null,
    ));
  }

  /// ضبط عدد الآيات المحفوظة يدويًا
  void setProgress(int v) {
    final p = state;
    if (p == null) return;
    final x = v < 0 ? 0 : (v > p.total ? p.total : v);
    _save(HifzPlan(
      surah: p.surah,
      start: p.start,
      end: p.end,
      done: x,
      prevDone: x,
      lastDone: null,
    ));
  }

  /// تمديد المدة بعدد أيام
  void extend(int days) {
    final p = state;
    if (p == null) return;
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final e = DateTime.parse(p.end);
    final base = e.isBefore(today) ? today : e;
    _save(HifzPlan(
      surah: p.surah,
      start: p.start,
      end: dayString(DateTime(base.year, base.month, base.day + days)),
      done: p.done,
      prevDone: p.prevDone,
      lastDone: p.lastDone,
    ));
  }

  void cancel() => _save(null);
}

final hifzPlanProvider =
    NotifierProvider<HifzPlanNotifier, HifzPlan?>(HifzPlanNotifier.new);
