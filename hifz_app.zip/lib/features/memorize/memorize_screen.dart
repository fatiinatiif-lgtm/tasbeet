// lib/features/memorize/memorize_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/models.dart';
import '../../data/quran/surah_data.dart';
import '../../data/local/storage.dart';
import '../review/review_provider.dart';
import '../profile/profile_provider.dart';
import '../achievements/achievements_provider.dart';

const _green = Color(0xFF0F5C4D);

class MemorizeScreen extends ConsumerStatefulWidget {
  const MemorizeScreen({super.key});

  @override
  ConsumerState<MemorizeScreen> createState() => _MemorizeScreenState();
}

class _MemorizeScreenState extends ConsumerState<MemorizeScreen> {
  Surah _surah = allSurahs.first;
  int _from = 1;
  int _to = 1;
  bool _saving = false;

  void _setSurah(Surah s) => setState(() {
        _surah = s;
        _from = 1;
        _to = 1;
      });

  void _setFrom(int v) => setState(() {
        _from = v.clamp(1, _surah.ayahCount);
        if (_to < _from) _to = _from;
      });

  void _setTo(int v) =>
      setState(() => _to = v.clamp(_from, _surah.ayahCount));

  Future<void> _pickSurah() async {
    final picked = await showModalBottomSheet<Surah>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _SurahPicker(),
    );
    if (picked != null) _setSurah(picked);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final item = MemorizationItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      surah: _surah.number,
      fromAyah: _from,
      toAyah: _to,
      memorizedAt: DateTime.now(),
    );
    final repo = ref.read(memorizationRepoProvider);
    await repo.add(item);
    final all = await repo.getAll();
    ref
        .read(profileProvider.notifier)
        .setMemorizedAyahs(memorizedAyahCount(all));
    final fresh = await ref.read(achievementsProvider.notifier).evaluate();
    ref.invalidate(reviewProvider);
    ref.invalidate(dueCountProvider);
    if (!mounted) return;
    setState(() {
      _saving = false;
      _from = _to < _surah.ayahCount ? _to + 1 : _to; // كمّلي من آخر موضع
      _to = _from;
    });
    final extra =
        fresh.isEmpty ? '' : '\nإنجاز جديد: ${fresh.map((e) => e.title).join('، ')}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
          'اتسجّل الحفظ، +${XpRules.newMemorization} نقطة. أول مراجعة بكرة$extra'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final count = _to - _from + 1;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F7F6),
        appBar: AppBar(
          title: const Text('حفظ جديد'),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              InkWell(
                onTap: _pickSurah,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFD9E4E1)),
                  ),
                  child: Row(children: [
                    Expanded(
                      child: Text('سورة ${_surah.name}',
                          style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                              color: _green)),
                    ),
                    Text('${_surah.ayahCount} آية'),
                    const Icon(Icons.expand_more),
                  ]),
                ),
              ),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                    child: _Stepper(
                        label: 'من آية', value: _from, onChanged: _setFrom)),
                const SizedBox(width: 12),
                Expanded(
                    child: _Stepper(
                        label: 'إلى آية', value: _to, onChanged: _setTo)),
              ]),
              const SizedBox(height: 16),
              Text('هتحفظي $count ${count == 1 ? 'آية' : 'آيات'}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16)),
              const Spacer(),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: _green,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: _saving ? null : _save,
                child: const Text('سجّلي الحفظ', style: TextStyle(fontSize: 17)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Stepper extends StatelessWidget {
  final String label;
  final int value;
  final ValueChanged<int> onChanged;
  const _Stepper(
      {required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFD9E4E1)),
        ),
        child: Column(children: [
          Text(label, style: const TextStyle(color: Colors.black54)),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(
                onPressed: () => onChanged(value + 1),
                icon: const Icon(Icons.add_circle_outline)),
            Text('$value',
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
            IconButton(
                onPressed: () => onChanged(value - 1),
                icon: const Icon(Icons.remove_circle_outline)),
          ]),
        ]),
      );
}

class _SurahPicker extends StatefulWidget {
  const _SurahPicker();
  @override
  State<_SurahPicker> createState() => _SurahPickerState();
}

class _SurahPickerState extends State<_SurahPicker> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final list = allSurahs.where((s) => s.name.contains(_q.trim())).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              autofocus: false,
              decoration: const InputDecoration(
                  hintText: 'ابحثي عن سورة', prefixIcon: Icon(Icons.search)),
              onChanged: (v) => setState(() => _q = v),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (_, i) => ListTile(
                leading: Text('${list[i].number}'),
                title: Text(list[i].name),
                trailing: Text('${list[i].ayahCount} آية'),
                onTap: () => Navigator.pop(context, list[i]),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
