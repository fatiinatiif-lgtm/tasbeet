// lib/features/splash/splash_screen.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../shell/app_shell.dart';

/// شاشة البداية: عدّاد من 1 إلى 5 وعبارة الترحيب تظهر كلمةً كلمة
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const _words = ['أهلًا', 'بحامل', 'القرآن'];
  static const _seconds = 5;

  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: _seconds),
  );

  @override
  void initState() {
    super.initState();
    _c.addStatusListener((st) {
      if (st == AnimationStatus.completed && mounted) {
        Navigator.of(context).pushReplacement(PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 500),
          pageBuilder: (_, __, ___) => const AppShell(),
          transitionsBuilder: (_, anim, __, child) =>
              FadeTransition(opacity: anim, child: child),
        ));
      }
    });
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  /// ظهور تدريجي ثم اختفاء لكل كلمة
  double _wordOpacity(double u) {
    if (u < 0.25) return Curves.easeOut.transform(u / 0.25);
    if (u > 0.75) return Curves.easeIn.transform((1 - u) / 0.25);
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [kGreen, kGreenDark],
          ),
        ),
        child: Stack(children: [
          const PatternLayer(alpha: 20, cell: 56),
          SafeArea(
            child: AnimatedBuilder(
              animation: _c,
              builder: (context, _) {
                final t = _c.value;
                final seg = t * _words.length;
                final i = math.min(seg.floor(), _words.length - 1);
                final u = math.min(1.0, math.max(0.0, seg - i));
                final o = _wordOpacity(u);
                final count = math.min(_seconds, (t * _seconds).floor() + 1);

                return Column(children: [
                  const Spacer(flex: 3),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: kGold, width: 2),
                      color: Colors.white.withAlpha(20),
                    ),
                    child: Icon(Icons.menu_book_rounded,
                        color: kGoldLight, size: 52),
                  ),
                  const Spacer(flex: 2),
                  SizedBox(
                    height: 100,
                    child: Center(
                      child: Opacity(
                        opacity: o,
                        child: Transform.scale(
                          scale: 0.88 + 0.12 * o,
                          child: Text(_words[i],
                              style: TextStyle(
                                  fontFamily: 'ArefRuqaa',
                                  color: Colors.white,
                                  fontSize: 64,
                                  height: 1.3,
                                  fontWeight: FontWeight.w700,
                                  shadows: [
                                    Shadow(
                                        color: kGold.withAlpha(120),
                                        blurRadius: 18),
                                  ])),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: 90,
                    height: 3,
                    decoration: BoxDecoration(
                        color: kGold, borderRadius: BorderRadius.circular(2)),
                  ),
                  const Spacer(flex: 3),
                  SizedBox(
                    width: 84,
                    height: 84,
                    child: Stack(alignment: Alignment.center, children: [
                      SizedBox(
                        width: 84,
                        height: 84,
                        child: CircularProgressIndicator(
                          value: t,
                          strokeWidth: 4,
                          color: kGold,
                          backgroundColor: Colors.white24,
                        ),
                      ),
                      Text('$count',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 34,
                              fontWeight: FontWeight.w800)),
                    ]),
                  ),
                  const Spacer(flex: 2),
                ]);
              },
            ),
          ),
        ]),
      ),
    );
  }
}
