// lib/features/prayer/prayer_data.dart
import 'package:adhan/adhan.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../quran/quran_data.dart' show arNum;
import '../wird/wird_provider.dart';

/// المدن المتاحة: (الاسم، خط العرض، خط الطول)
const List<(String, double, double)> kCities = [
  ('القاهرة', 30.0444, 31.2357),
  ('الإسكندرية', 31.2001, 29.9187),
  ('الجيزة', 30.0131, 31.2089),
  ('المنصورة', 31.0409, 31.3785),
  ('طنطا', 30.7865, 31.0004),
  ('الزقازيق', 30.5877, 31.5020),
  ('بورسعيد', 31.2653, 32.3019),
  ('الإسماعيلية', 30.5965, 32.2715),
  ('السويس', 29.9668, 32.5498),
  ('دمياط', 31.4165, 31.8133),
  ('الفيوم', 29.3084, 30.8428),
  ('بني سويف', 29.0661, 31.0994),
  ('المنيا', 28.1099, 30.7503),
  ('أسيوط', 27.1783, 31.1859),
  ('سوهاج', 26.5569, 31.6948),
  ('قنا', 26.1551, 32.7160),
  ('الأقصر', 25.6872, 32.6396),
  ('أسوان', 24.0889, 32.8998),
  ('الغردقة', 27.2579, 33.8116),
  ('شرم الشيخ', 27.9158, 34.3300),
  ('مكة المكرمة', 21.3891, 39.8579),
  ('المدينة المنورة', 24.5247, 39.5692),
  ('الرياض', 24.7136, 46.6753),
  ('جدة', 21.4858, 39.1925),
  ('الدمام', 26.4207, 50.0888),
  ('الكويت', 29.3759, 47.9774),
  ('الدوحة', 25.2854, 51.5310),
  ('المنامة', 26.2285, 50.5860),
  ('دبي', 25.2048, 55.2708),
  ('أبوظبي', 24.4539, 54.3773),
  ('مسقط', 23.5880, 58.3829),
  ('عمّان', 31.9454, 35.9284),
  ('القدس', 31.7683, 35.2137),
  ('غزة', 31.5017, 34.4668),
  ('بيروت', 33.8938, 35.5018),
  ('دمشق', 33.5138, 36.2765),
  ('بغداد', 33.3152, 44.3661),
  ('صنعاء', 15.3694, 44.1910),
  ('الخرطوم', 15.5007, 32.5599),
  ('طرابلس', 32.8872, 13.1913),
  ('تونس', 36.8065, 10.1815),
  ('الجزائر', 36.7538, 3.0588),
  ('الرباط', 34.0209, -6.8416),
  ('الدار البيضاء', 33.5731, -7.5898),
  ('إسطنبول', 41.0082, 28.9784),
];

/// طرق الحساب: (الاسم، الطريقة)
final List<(String, CalculationMethod)> kPrayerMethods = [
  ('الهيئة المصرية', CalculationMethod.egyptian),
  ('أم القرى', CalculationMethod.umm_al_qura),
  ('رابطة العالم الإسلامي', CalculationMethod.muslim_world_league),
];

/// الصلوات المعروضة
const kPrayerNames = ['الفجر', 'الشروق', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

/// أوقات اليوم بنفس ترتيب kPrayerNames
List<DateTime> prayerTimesFor(int city, int method) {
  final c = kCities[city];
  final params = kPrayerMethods[method].$2.getParameters();
  params.madhab = Madhab.shafi;
  final t = PrayerTimes.today(Coordinates(c.$2, c.$3), params);
  return [t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha];
}

/// الصلاة القادمة: (الاسم، الوقت، رقمها في kPrayerNames)
(String, DateTime, int) nextPrayer(List<DateTime> t, DateTime now) {
  for (final i in const [0, 2, 3, 4, 5]) {
    if (t[i].isAfter(now)) return (kPrayerNames[i], t[i], i);
  }
  return (kPrayerNames[0], t[0].add(const Duration(days: 1)), 0);
}

/// 5:07 ص
String fmtTime(DateTime t) {
  final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
  final m = t.minute.toString().padLeft(2, '0');
  return '${arNum(h)}:${m.split('').map((c) => arNum(int.parse(c))).join()} ${t.hour < 12 ? 'ص' : 'م'}';
}

String fmtLeft(Duration d) {
  final h = d.inHours, m = d.inMinutes % 60;
  if (h == 0) return '${arNum(m)} دقيقة';
  return '${arNum(h)} ساعة و${arNum(m)} دقيقة';
}

class _IntPref extends Notifier<int> {
  final String key;
  final int def;
  final int max;
  _IntPref(this.key, this.def, this.max);

  @override
  int build() {
    final v = ref.read(sharedPrefsProvider).getInt(key) ?? def;
    return (v >= 0 && v < max) ? v : def;
  }

  void set(int v) {
    ref.read(sharedPrefsProvider).setInt(key, v);
    state = v;
  }
}

final prayerCityProvider = NotifierProvider<_IntPref, int>(
    () => _IntPref('prayer_city_v1', 0, kCities.length));
final prayerMethodProvider = NotifierProvider<_IntPref, int>(
    () => _IntPref('prayer_method_v1', 0, kPrayerMethods.length));

/// وقت الورد: -1 بدون، وإلا رقم الصلاة في kPrayerNames (بعدها)
final prayerWirdProvider = NotifierProvider<_IntPref, int>(
    () => _IntPref('prayer_wird_v1', 0, 7));
