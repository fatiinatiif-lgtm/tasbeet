// lib/features/prayer/prayer_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import 'prayer_data.dart';

/// بطاقة الصفحة الرئيسية: الصلاة القادمة والوقت المتبقي
class PrayerCard extends ConsumerStatefulWidget {
  const PrayerCard({super.key});

  @override
  ConsumerState<PrayerCard> createState() => _PrayerCardState();
}

class _PrayerCardState extends ConsumerState<PrayerCard> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final city = ref.watch(prayerCityProvider);
    final method = ref.watch(prayerMethodProvider);
    final wird = ref.watch(prayerWirdProvider);
    final times = prayerTimesFor(city, method);
    final now = DateTime.now();
    final next = nextPrayer(times, now);

    return InkWell(
      onTap: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const PrayerScreen())),
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: cardDeco(radius: 22, border: kGold.withAlpha(120)),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: kGreen.withAlpha(26), shape: BoxShape.circle),
            child: Icon(Icons.mosque_rounded, color: kGreen, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الصلاة القادمة: ${next.$1} ${fmtTime(next.$2)}',
                  style: TextStyle(
                      fontSize: 16.5, fontWeight: FontWeight.w800, color: kInk)),
              const SizedBox(height: 3),
              Text(
                  'بعد ${fmtLeft(next.$2.difference(now))} • ${kCities[city].$1}',
                  style: TextStyle(color: kMuted, fontSize: 13)),
              if (wird > 0) ...[
                const SizedBox(height: 3),
                Text(
                    'وردك بعد ${kPrayerNames[wird - 1]} (${fmtTime(times[wird - 1])})',
                    style: TextStyle(
                        color: kGreen, fontSize: 13, fontWeight: FontWeight.w700)),
              ],
            ]),
          ),
          Icon(Icons.arrow_forward_ios_rounded, size: 16, color: kGold),
        ]),
      ),
    );
  }
}

class PrayerScreen extends ConsumerWidget {
  const PrayerScreen({super.key});

  void _pickCity(BuildContext context, WidgetRef ref) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: Column(children: [
            const SizedBox(height: 14),
            Text('اختر مدينتك',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 6),
            Expanded(
              child: ListView.builder(
                itemCount: kCities.length,
                itemBuilder: (_, i) => ListTile(
                  title: Text(kCities[i].$1),
                  trailing: i == ref.read(prayerCityProvider)
                      ? Icon(Icons.check_circle_rounded, color: kGreen)
                      : null,
                  onTap: () {
                    ref.read(prayerCityProvider.notifier).set(i);
                    Navigator.pop(ctx);
                  },
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final city = ref.watch(prayerCityProvider);
    final method = ref.watch(prayerMethodProvider);
    final wird = ref.watch(prayerWirdProvider);
    final times = prayerTimesFor(city, method);
    final next = nextPrayer(times, DateTime.now());

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'أوقات الصلاة',
          subtitle: kCities[city].$1,
          colors: kSectionGradients[6],
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              InkWell(
                onTap: () => _pickCity(context, ref),
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: cardDeco(radius: 18),
                  child: Row(children: [
                    Icon(Icons.location_city_rounded, color: kGreen),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('المدينة: ${kCities[city].$1}',
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              color: kInk)),
                    ),
                    Text('تغيير', style: TextStyle(color: kGreen)),
                  ]),
                ),
              ),
              const SizedBox(height: 14),
              for (var i = 0; i < times.length; i++)
                Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: next.$3 == i ? kGreen.withAlpha(24) : kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: next.$3 == i ? kGreen : kBorder,
                        width: next.$3 == i ? 1.8 : 1),
                  ),
                  child: Row(children: [
                    Expanded(
                      child: Text(kPrayerNames[i],
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: next.$3 == i ? kGreen : kInk)),
                    ),
                    if (wird == i + 1)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 10),
                        child: Icon(Icons.menu_book_rounded,
                            color: kGold, size: 20),
                      ),
                    Text(fmtTime(times[i]),
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: kInk)),
                  ]),
                ),
              const SizedBox(height: 14),
              const SectionTitle('طريقة الحساب'),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < kPrayerMethods.length; i++)
                  ChoiceChip(
                    label: Text(kPrayerMethods[i].$1),
                    selected: method == i,
                    selectedColor: kGreen.withAlpha(50),
                    onSelected: (_) =>
                        ref.read(prayerMethodProvider.notifier).set(i),
                  ),
              ]),
              const SizedBox(height: 20),
              const SectionTitle('وقت وردك'),
              const SizedBox(height: 4),
              Text('اختر الصلاة التي تقرأ ورد القرآن بعدها، ويظهر وقتها في الصفحة الرئيسية.',
                  style: TextStyle(color: kMuted, height: 1.6)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                ChoiceChip(
                  label: const Text('بدون'),
                  selected: wird == 0,
                  selectedColor: kGreen.withAlpha(50),
                  onSelected: (_) => ref.read(prayerWirdProvider.notifier).set(0),
                ),
                for (var i = 0; i < kPrayerNames.length; i++)
                  ChoiceChip(
                    label: Text('بعد ${kPrayerNames[i]}'),
                    selected: wird == i + 1,
                    selectedColor: kGreen.withAlpha(50),
                    onSelected: (_) =>
                        ref.read(prayerWirdProvider.notifier).set(i + 1),
                  ),
              ]),
              const SizedBox(height: 18),
              Text(
                  'الأوقات محسوبة تقريبيًا حسب المدينة وطريقة الحساب، فقد تختلف دقيقة أو دقيقتين عن المسجد القريب منك.',
                  style: TextStyle(color: kMuted, fontSize: 12.5, height: 1.6)),
            ],
          ),
        ),
      ]),
    );
  }
}
