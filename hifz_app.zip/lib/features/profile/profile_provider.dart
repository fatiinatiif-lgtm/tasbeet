// lib/features/profile/profile_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/storage.dart';
import '../../data/models/models.dart';

DateTime _day(DateTime t) => DateTime.utc(t.year, t.month, t.day);

class ProfileNotifier extends Notifier<UserProfile> {
  static const _key = 'profile';

  @override
  UserProfile build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return UserProfile(id: 'me', name: 'حافظة');
    return UserProfile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  void _commit(UserProfile p) {
    state = p;
    ref.read(sharedPrefsProvider).setString(_key, jsonEncode(p.toJson()));
  }

  void _touchStreak(UserProfile p) {
    final d = _day(DateTime.now());
    if (p.lastActive == null) {
      p.streakDays = 1;
    } else {
      final diff = d.difference(p.lastActive!).inDays;
      if (diff == 1) {
        p.streakDays += 1;
        p.xp += XpRules.dailyStreakBonus;
      } else if (diff > 1) {
        p.streakDays = 1;
      }
    }
    p.lastActive = d;
  }

  /// بعد تسجيل حفظ جديد: نمرّر العدد الفعلي للآيات المحفوظة
  void setMemorizedAyahs(int uniqueAyahs) {
    final p = state.copy();
    _touchStreak(p);
    p.totalAyahs = uniqueAyahs;
    p.totalPagesMemorized = (uniqueAyahs / 10).floor(); // الوجه ≈ 10 آيات
    p.xp += XpRules.newMemorization;
    _commit(p);
  }

  void addReview() {
    final p = state.copy();
    _touchStreak(p);
    p.totalReviews += 1;
    p.xp += XpRules.review;
    _commit(p);
  }

  /// نقاط مكافأة الإنجازات (بدون التأثير على السلسلة)
  void addBonusXp(int xp) {
    final p = state.copy()..xp += xp;
    _commit(p);
  }
}

final profileProvider =
    NotifierProvider<ProfileNotifier, UserProfile>(ProfileNotifier.new);

/// عدد المراجعات المستحقة اليوم
final dueCountProvider = FutureProvider.autoDispose<int>((ref) async {
  final all = await ref.read(memorizationRepoProvider).getAll();
  return all.where((e) => e.isDue()).length;
});
