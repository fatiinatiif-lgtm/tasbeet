// lib/features/quran/quran_reader.dart
import 'dart:async';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qcf_quran/qcf_quran.dart' show getPageNumber;
import 'package:quran/quran.dart' as quran;
import '../../core/theme.dart';
import '../../data/quran/surah_data.dart';
import 'quran_data.dart';

const _basmala = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';
const _chunk = 6; // عدد الآيات في كل فقرة

/// المصحف الشريف كنصوص (تمرير عمودي بدل الصفحات)، يناسب كل مقاسات الشاشات
class MushafReader extends ConsumerStatefulWidget {
  final int surah;
  final int ayah;
  const MushafReader({super.key, this.surah = 1, this.ayah = 1});

  @override
  ConsumerState<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends ConsumerState<MushafReader> {
  late int _surah = widget.surah.clamp(1, 114);
  final _scroll = ScrollController();
  final _viewKey = GlobalKey();
  final _recs = <int, TapGestureRecognizer>{};
  List<GlobalKey> _keys = [];
  Timer? _timer;
  int? _selVerse;

  int get _count => allSurahs[_surah - 1].ayahCount;

  @override
  void initState() {
    super.initState();
    _buildKeys();
    _scroll.addListener(_onScroll);
    final v = widget.ayah;
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpTo(v));
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpTo(v, later: true));
    ref.read(quranLastProvider.notifier).set(_surah, v);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scroll.dispose();
    for (final r in _recs.values) {
      r.dispose();
    }
    super.dispose();
  }

  void _buildKeys() {
    _keys = List.generate((_count + _chunk - 1) ~/ _chunk, (_) => GlobalKey());
  }

  /// الانتقال إلى آية (بعد اكتمال قياس النصوص)
  void _jumpTo(int verse, {bool later = false}) {
    if (!mounted || verse <= 1) return;
    final i = ((verse - 1) ~/ _chunk).clamp(0, _keys.length - 1);
    final ctx = _keys[i].currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(ctx, alignment: 0.0);
  }

  void _onScroll() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 500), _saveVisible);
  }

  void _saveVisible() {
    if (!mounted) return;
    final vb = _viewKey.currentContext?.findRenderObject() as RenderBox?;
    if (vb == null || !vb.attached) return;
    final top = vb.localToGlobal(Offset.zero).dy + 40;
    var best = 0;
    for (var i = 0; i < _keys.length; i++) {
      final box = _keys[i].currentContext?.findRenderObject() as RenderBox?;
      if (box == null || !box.attached) continue;
      if (box.localToGlobal(Offset.zero).dy <= top) {
        best = i;
      } else {
        break;
      }
    }
    ref.read(quranLastProvider.notifier).set(_surah, best * _chunk + 1);
  }

  void _msg(String t) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(t), duration: const Duration(seconds: 2)));

  void _changeSurah(int s) {
    if (s < 1 || s > 114) return;
    for (final r in _recs.values) {
      r.dispose();
    }
    _recs.clear();
    setState(() {
      _surah = s;
      _selVerse = null;
      _buildKeys();
    });
    if (_scroll.hasClients) _scroll.jumpTo(0);
    ref.read(quranLastProvider.notifier).set(s, 1);
  }

  void _onTap(int v) {
    setState(() => _selVerse = v);
    final s = _surah;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 14),
            Text('سورة ${surahName(s)} • الآية ${arNum(v)}',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 6),
            ListTile(
              leading: Icon(Icons.bookmark_add_rounded, color: kGold),
              title: const Text('علامة قراءة هنا'),
              onTap: () {
                ref
                    .read(quranBookmarkProvider.notifier)
                    .set(getPageNumber(s, v), s, v);
                Navigator.pop(ctx);
                _msg('تم حفظ علامة القراءة');
              },
            ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    ).whenComplete(() {
      if (mounted) setState(() => _selVerse = null);
    });
  }

  void _fontSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Consumer(builder: (_, ref, __) {
            final size = ref.watch(quranFontSizeProvider);
            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('حجم الخط',
                    style: TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
                const SizedBox(height: 6),
                Row(children: [
                  Text('أ', style: TextStyle(fontSize: 16, color: kMuted)),
                  Expanded(
                    child: Slider(
                      value: size,
                      min: 18,
                      max: 44,
                      divisions: 26,
                      activeColor: kGreen,
                      onChanged: (v) =>
                          ref.read(quranFontSizeProvider.notifier).set(v),
                    ),
                  ),
                  Text('أ', style: TextStyle(fontSize: 30, color: kMuted)),
                ]),
              ]),
            );
          }),
        ),
      ),
    );
  }

  TapGestureRecognizer _rec(int v) =>
      _recs.putIfAbsent(v, () => TapGestureRecognizer()..onTap = () => _onTap(v));

  @override
  Widget build(BuildContext context) {
    final size = ref.watch(quranFontSizeProvider);
    final bm = ref.watch(quranBookmarkProvider);
    int? bmVerse;
    if (bm != null) {
      final p = bm.split(':');
      if (p.length == 3 && int.tryParse(p[1]) == _surah) {
        bmVerse = int.tryParse(p[2]);
      }
    }
    final pad = MediaQuery.of(context).padding;
    final showBasmala = _surah != 1 && _surah != 9;

    final base = TextStyle(
      fontFamily: 'AmiriQuran',
      fontFamilyFallback: const ['Noto Naskh Arabic', 'serif'],
      fontSize: size,
      height: 2.0,
      color: kInk,
    );

    Widget chunk(int i) {
      final from = i * _chunk + 1;
      final to = (from + _chunk - 1).clamp(1, _count);
      final spans = <InlineSpan>[];
      for (var v = from; v <= to; v++) {
        final hl = v == _selVerse
            ? kGold.withAlpha(95)
            : (v == bmVerse ? kGold.withAlpha(55) : null);
        spans.add(TextSpan(
          text: quran.getVerse(_surah, v),
          style: TextStyle(backgroundColor: hl),
          recognizer: _rec(v),
        ));
        spans.add(TextSpan(
          text: ' ﴿${arNum(v)}﴾ ',
          style: TextStyle(
              color: kGold,
              fontSize: size * 0.8,
              backgroundColor: hl),
          recognizer: _rec(v),
        ));
      }
      return Padding(
        key: _keys[i],
        padding: const EdgeInsets.only(bottom: 4),
        child: Text.rich(
          TextSpan(children: spans, style: base),
          textAlign: TextAlign.justify,
          textDirection: TextDirection.rtl,
        ),
      );
    }

    return Scaffold(
      backgroundColor: kBg,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(children: [
          // الشريط العلوي: يحترم حافة الشاشة (النوتش) من كل الجهات
          Container(
            padding: EdgeInsets.fromLTRB(
                4 + pad.left, pad.top + 4, 8 + pad.right, 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kGreen, kGreenDark]),
            ),
            child: Row(children: [
              IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon:
                    const Icon(Icons.arrow_forward_rounded, color: Colors.white),
              ),
              Expanded(
                child: Text(
                  'سورة ${surahName(_surah)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                tooltip: 'حجم الخط',
                onPressed: _fontSheet,
                icon: const Icon(Icons.text_fields_rounded, color: Colors.white),
              ),
            ]),
          ),
          Expanded(
            // نثبّت مقياس خط النظام حتى لا يتغيّر التنسيق؛ الحجم يتحكم فيه القارئ
            child: MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(textScaler: TextScaler.noScaling),
              child: SingleChildScrollView(
                key: _viewKey,
                controller: _scroll,
                padding: EdgeInsets.fromLTRB(
                  20 + pad.left,
                  18,
                  20 + pad.right,
                  28 + pad.bottom,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        border: Border.symmetric(
                            horizontal: BorderSide(color: kGold, width: 1.4)),
                      ),
                      child: Text(
                        'سورة ${surahName(_surah)}',
                        textAlign: TextAlign.center,
                        style: base.copyWith(
                            fontSize: 26, height: 1.5, color: kGreen),
                      ),
                    ),
                    if (showBasmala)
                      Padding(
                        padding: const EdgeInsets.only(top: 14, bottom: 4),
                        child: Text(
                          _basmala,
                          textAlign: TextAlign.center,
                          style: base.copyWith(fontSize: size),
                        ),
                      ),
                    const SizedBox(height: 8),
                    for (var i = 0; i < _keys.length; i++) chunk(i),
                    const SizedBox(height: 16),
                    Row(children: [
                      if (_surah < 114)
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _changeSurah(_surah + 1),
                            icon: const Icon(Icons.chevron_right_rounded),
                            label: Text('سورة ${surahName(_surah + 1)}',
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                        ),
                      if (_surah < 114 && _surah > 1) const SizedBox(width: 10),
                      if (_surah > 1)
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _changeSurah(_surah - 1),
                            icon: const Icon(Icons.chevron_left_rounded),
                            label: Text('سورة ${surahName(_surah - 1)}',
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                        ),
                    ]),
                  ],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
