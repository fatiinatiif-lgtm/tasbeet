// lib/features/quran/quran_reader.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qcf_quran/qcf_quran.dart';
import '../../core/theme.dart';
import '../../data/quran/surah_data.dart';
import 'quran_data.dart';

/// المصحف الشريف بالصفحات (604 صفحة، خط مجمع الملك فهد)
class MushafReader extends ConsumerStatefulWidget {
  final int initialPage;
  const MushafReader({super.key, this.initialPage = 1});

  @override
  ConsumerState<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends ConsumerState<MushafReader> {
  late int _page = widget.initialPage.clamp(1, 604);
  (int, int)? _sel;

  void _msg(String t) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(t), duration: const Duration(seconds: 2)));

  void _onTap(int s, int v) {
    setState(() => _sel = (s, v));
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 14),
            Text('سورة ${surahName(s)} • الآية ${arNum(v)}',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 6),
            ListTile(
              leading: Icon(Icons.bookmark_add_rounded, color: kGold),
              title: const Text('علامة قراءة هنا'),
              onTap: () {
                ref.read(quranBookmarkProvider.notifier).set(_page, s, v);
                Navigator.pop(ctx);
                _msg('تم حفظ علامة القراءة');
              },
            ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    ).whenComplete(() {
      if (mounted) setState(() => _sel = null);
    });
  }

  Future<void> _goToPage() async {
    final c = TextEditingController();
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('الانتقال إلى صفحة',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: TextField(
            controller: c,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              helperText: 'من 1 إلى 604',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: kGreen),
              onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim())),
              child: const Text('انتقال'),
            ),
          ],
        ),
      ),
    );
    if (v == null || v < 1 || v > 604 || !mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => MushafReader(initialPage: v)));
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final theme = dark
        ? QcfThemeData.dark()
        : QcfThemeData(
            pageBackgroundColor: const Color(0xFFFFFBF1),
            verseTextColor: const Color(0xFF1B1B1B),
            verseBackgroundColor: (s, v) =>
                (_sel != null && _sel!.$1 == s && _sel!.$2 == v)
                    ? kGold.withAlpha(80)
                    : null,
          );
    final surah = surahOfPage(_page);

    return Scaffold(
      backgroundColor: dark ? Colors.black : const Color(0xFFFFFBF1),
      body: SafeArea(
        minimum: const EdgeInsets.only(top: 8),
        child: Column(children: [
          Container(
            padding: const EdgeInsets.fromLTRB(4, 4, 8, 4),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kGreen, kGreenDark]),
            ),
            child: Row(children: [
              IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
              ),
              Expanded(
                child: Text(
                  'سورة ${surahName(surah)} • الجزء ${arNum(juzOfPage(_page))}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16.5,
                      fontWeight: FontWeight.w800),
                ),
              ),
              InkWell(
                onTap: _goToPage,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(36),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('صفحة ${arNum(_page)}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
          Expanded(
            // نمنع تكبير خط الجوال من تغيير مقاس الصفحة حتى لا تُقصّ أطرافها
            child: MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(textScaler: TextScaler.noScaling),
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: PageviewQuran(
                initialPageNumber: _page,
                theme: theme,
                onPageChanged: (p) {
                  setState(() => _page = p);
                  ref.read(quranPageProvider.notifier).set(p);
                },
                  onTap: (s, v) => _onTap(s, v),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
