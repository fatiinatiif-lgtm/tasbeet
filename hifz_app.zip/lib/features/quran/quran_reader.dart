// lib/features/quran/quran_reader.dart
import 'dart:async';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qcf_quran/qcf_quran.dart' show getPageNumber;
import 'package:quran/quran.dart' as quran;
import '../../core/theme.dart';
import '../../data/quran/surah_data.dart';
import 'quran_data.dart';

const _basmala = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';
const _chunk = 6; // عدد الآيات في كل فقرة

/// ألوان صفحة القراءة
class _Paper {
  final Color bg, ink, frame;
  final bool dark;
  const _Paper(this.bg, this.ink, this.frame, this.dark);
}

_Paper _paperFor(int idx, bool appDark) {
  var i = idx;
  if (i == 0) i = appDark ? 4 : 1;
  final p = kQuranPapers[i];
  return _Paper(Color(p.$2), Color(p.$3), Color(p.$4), p.$5);
}

/// المصحف الشريف كنصوص (تمرير عمودي بدل الصفحات)، يناسب كل مقاسات الشاشات
class MushafReader extends ConsumerStatefulWidget {
  final int surah;
  final int ayah;
  const MushafReader({super.key, this.surah = 1, this.ayah = 1});

  @override
  ConsumerState<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends ConsumerState<MushafReader> {
  late int _surah = widget.surah.clamp(1, 114);
  final _scroll = ScrollController();
  final _viewKey = GlobalKey();
  final _recs = <int, TapGestureRecognizer>{};
  final _progress = ValueNotifier<double>(0);
  List<GlobalKey> _keys = [];
  Timer? _timer;
  int? _selVerse;

  int get _count => allSurahs[_surah - 1].ayahCount;

  @override
  void initState() {
    super.initState();
    _buildKeys();
    _scroll.addListener(_onScroll);
    final v = widget.ayah;
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpTo(v));
    ref.read(quranLastProvider.notifier).set(_surah, v);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scroll.dispose();
    _progress.dispose();
    for (final r in _recs.values) {
      r.dispose();
    }
    super.dispose();
  }

  void _buildKeys() {
    _keys = List.generate((_count + _chunk - 1) ~/ _chunk, (_) => GlobalKey());
  }

  void _jumpTo(int verse) {
    if (!mounted || verse <= 1) return;
    final i = ((verse - 1) ~/ _chunk).clamp(0, _keys.length - 1);
    final ctx = _keys[i].currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(ctx, alignment: 0.0);
  }

  void _onScroll() {
    if (_scroll.hasClients) {
      final m = _scroll.position.maxScrollExtent;
      _progress.value = m <= 0 ? 0 : (_scroll.offset / m).clamp(0.0, 1.0);
    }
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 500), _saveVisible);
  }

  void _saveVisible() {
    if (!mounted) return;
    final vb = _viewKey.currentContext?.findRenderObject() as RenderBox?;
    if (vb == null || !vb.attached) return;
    final top = vb.localToGlobal(Offset.zero).dy + 40;
    var best = 0;
    for (var i = 0; i < _keys.length; i++) {
      final box = _keys[i].currentContext?.findRenderObject() as RenderBox?;
      if (box == null || !box.attached) continue;
      if (box.localToGlobal(Offset.zero).dy <= top) {
        best = i;
      } else {
        break;
      }
    }
    ref.read(quranLastProvider.notifier).set(_surah, best * _chunk + 1);
  }

  void _msg(String t) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(t), duration: const Duration(seconds: 2)));

  void _changeSurah(int s) {
    if (s < 1 || s > 114) return;
    for (final r in _recs.values) {
      r.dispose();
    }
    _recs.clear();
    setState(() {
      _surah = s;
      _selVerse = null;
      _buildKeys();
    });
    if (_scroll.hasClients) _scroll.jumpTo(0);
    ref.read(quranLastProvider.notifier).set(s, 1);
  }

  void _onTap(int v) {
    setState(() => _selVerse = v);
    final s = _surah;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 14),
            Text('سورة ${surahName(s)} • الآية ${arNum(v)}',
                style: TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 6),
            ListTile(
              leading: Icon(Icons.bookmark_add_rounded, color: kGold),
              title: const Text('علامة قراءة هنا'),
              onTap: () {
                ref
                    .read(quranBookmarkProvider.notifier)
                    .set(getPageNumber(s, v), s, v);
                Navigator.pop(ctx);
                _msg('تم حفظ علامة القراءة');
              },
            ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    ).whenComplete(() {
      if (mounted) setState(() => _selVerse = null);
    });
  }

  /// نافذة خيارات القراءة: الخط والحجم والخلفية
  void _settingsSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
            child: Consumer(builder: (_, ref, __) {
              final size = ref.watch(quranFontSizeProvider);
              final font = ref.watch(quranFontProvider);
              final paper = ref.watch(quranPaperProvider);
              Widget label(String t) => Padding(
                    padding: const EdgeInsets.only(top: 14, bottom: 8),
                    child: Text(t,
                        style: TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w800,
                            color: kInk)),
                  );
              return Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text('خيارات القراءة',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: kInk)),
                    ),
                    label('نوع الخط'),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (var i = 0; i < kQuranFonts.length; i++)
                        InkWell(
                          onTap: () =>
                              ref.read(quranFontProvider.notifier).set(i),
                          borderRadius: BorderRadius.circular(14),
                          child: Container(
                            width: 150,
                            padding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 10),
                            decoration: BoxDecoration(
                              color: i == font ? kGreen.withAlpha(28) : kCard,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: i == font ? kGreen : kBorder,
                                  width: i == font ? 2 : 1),
                            ),
                            child: Column(children: [
                              Text('بِسْمِ ٱللَّهِ',
                                  style: TextStyle(
                                      fontFamily: kQuranFonts[i].$2,
                                      fontSize: 22 * kQuranFonts[i].$3,
                                      color: kInk)),
                              Text(kQuranFonts[i].$1,
                                  style: TextStyle(
                                      fontSize: 12.5,
                                      color: i == font ? kGreen : kMuted,
                                      fontWeight: FontWeight.w700)),
                            ]),
                          ),
                        ),
                    ]),
                    label('حجم الخط'),
                    Row(children: [
                      Text('أ', style: TextStyle(fontSize: 16, color: kMuted)),
                      Expanded(
                        child: Slider(
                          value: size,
                          min: 18,
                          max: 44,
                          divisions: 26,
                          activeColor: kGreen,
                          onChanged: (v) =>
                              ref.read(quranFontSizeProvider.notifier).set(v),
                        ),
                      ),
                      Text('أ', style: TextStyle(fontSize: 30, color: kMuted)),
                    ]),
                    label('لون الصفحة'),
                    Wrap(spacing: 10, runSpacing: 10, children: [
                      for (var i = 0; i < kQuranPapers.length; i++)
                        InkWell(
                          onTap: () =>
                              ref.read(quranPaperProvider.notifier).set(i),
                          borderRadius: BorderRadius.circular(14),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: i == 0
                                  ? kCard
                                  : Color(kQuranPapers[i].$2),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: i == paper ? kGreen : kBorder,
                                  width: i == paper ? 2.2 : 1),
                            ),
                            child: Text(kQuranPapers[i].$1,
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: i == 0
                                        ? kInk
                                        : Color(kQuranPapers[i].$3))),
                          ),
                        ),
                    ]),
                    const SizedBox(height: 8),
                  ]);
            }),
          ),
        ),
      ),
    );
  }

  TapGestureRecognizer _rec(int v) =>
      _recs.putIfAbsent(v, () => TapGestureRecognizer()..onTap = () => _onTap(v));

  @override
  Widget build(BuildContext context) {
    final fontSize = ref.watch(quranFontSizeProvider);
    final fontIdx = ref.watch(quranFontProvider);
    final paperIdx = ref.watch(quranPaperProvider);
    final bm = ref.watch(quranBookmarkProvider);
    final appDark = Theme.of(context).brightness == Brightness.dark;
    final paper = _paperFor(paperIdx, appDark);
    final font = kQuranFonts[fontIdx];
    final size = fontSize * font.$3;

    int? bmVerse;
    if (bm != null) {
      final p = bm.split(':');
      if (p.length == 3 && int.tryParse(p[1]) == _surah) {
        bmVerse = int.tryParse(p[2]);
      }
    }
    final pad = MediaQuery.of(context).padding;
    final showBasmala = _surah != 1 && _surah != 9;

    final base = TextStyle(
      fontFamily: font.$2,
      fontFamilyFallback: const ['AmiriQuran', 'Noto Naskh Arabic', 'serif'],
      fontSize: size,
      height: 2.05,
      color: paper.ink,
    );

    // رقم الآية داخل دائرة مزخرفة
    Widget marker(int v, Color? hl) {
      final d = size * 1.05;
      return GestureDetector(
        onTap: () => _onTap(v),
        child: Container(
          width: d,
          height: d,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: hl ?? paper.frame.withAlpha(30),
            border: Border.all(color: paper.frame, width: 1.4),
          ),
          child: Padding(
            padding: const EdgeInsets.all(2),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(arNum(v),
                  style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: size * 0.5,
                      height: 1.1,
                      fontWeight: FontWeight.w700,
                      color: paper.dark ? paper.frame : paper.ink)),
            ),
          ),
        ),
      );
    }

    Widget chunk(int i) {
      final from = i * _chunk + 1;
      final to = (from + _chunk - 1).clamp(1, _count);
      final spans = <InlineSpan>[];
      for (var v = from; v <= to; v++) {
        final hl = v == _selVerse
            ? paper.frame.withAlpha(110)
            : (v == bmVerse ? paper.frame.withAlpha(60) : null);
        spans.add(TextSpan(
          text: quran.getVerse(_surah, v),
          style: TextStyle(backgroundColor: hl),
          recognizer: _rec(v),
        ));
        spans.add(WidgetSpan(
            alignment: PlaceholderAlignment.middle, child: marker(v, hl)));
        spans.add(const TextSpan(text: ' '));
      }
      return Padding(
        key: _keys[i],
        padding: const EdgeInsets.only(bottom: 2),
        child: Text.rich(
          TextSpan(children: spans, style: base),
          textAlign: TextAlign.justify,
          textDirection: TextDirection.rtl,
        ),
      );
    }

    // لافتة اسم السورة
    Widget banner() => Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [kGreen, kGreenDark]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: paper.frame, width: 2),
            boxShadow: [
              BoxShadow(
                  color: paper.frame.withAlpha(70),
                  blurRadius: 10,
                  offset: const Offset(0, 3)),
            ],
          ),
          child: Row(children: [
            Text('۞',
                style: TextStyle(fontSize: 26, color: kGoldLight, height: 1)),
            Expanded(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('سورة ${surahName(_surah)}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'AmiriQuran',
                        fontSize: 29,
                        height: 1.5,
                        color: Colors.white)),
                Text(
                    'آياتها ${arNum(_count)} • الجزء ${arNum(juzOfAyah(_surah, 1))}',
                    style: TextStyle(
                        fontSize: 12.5, color: Colors.white.withAlpha(215))),
              ]),
            ),
            Text('۞',
                style: TextStyle(fontSize: 26, color: kGoldLight, height: 1)),
          ]),
        );

    Widget divider() => Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(children: [
            Expanded(child: Container(height: 1, color: paper.frame.withAlpha(120))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text('❁', style: TextStyle(color: paper.frame, fontSize: 18)),
            ),
            Expanded(child: Container(height: 1, color: paper.frame.withAlpha(120))),
          ]),
        );

    Widget navButton(String text, IconData icon, VoidCallback onTap) =>
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: paper.dark ? paper.frame : kGreen,
              side: BorderSide(color: paper.frame),
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: onTap,
            icon: Icon(icon),
            label: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
        );

    return Scaffold(
      backgroundColor: paper.bg,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(children: [
          Container(
            padding: EdgeInsets.fromLTRB(
                4 + pad.left, pad.top + 4, 8 + pad.right, 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kGreen, kGreenDark]),
            ),
            child: Row(children: [
              IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon:
                    const Icon(Icons.arrow_forward_rounded, color: Colors.white),
              ),
              Expanded(
                child: Text(
                  'سورة ${surahName(_surah)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                tooltip: 'خيارات القراءة',
                onPressed: _settingsSheet,
                icon: const Icon(Icons.text_fields_rounded, color: Colors.white),
              ),
            ]),
          ),
          // شريط تقدّم القراءة في السورة
          ValueListenableBuilder<double>(
            valueListenable: _progress,
            builder: (_, v, __) => LinearProgressIndicator(
              value: v,
              minHeight: 3,
              backgroundColor: paper.frame.withAlpha(50),
              valueColor: AlwaysStoppedAnimation(paper.frame),
            ),
          ),
          Expanded(
            child: MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(textScaler: TextScaler.noScaling),
              child: SingleChildScrollView(
                key: _viewKey,
                controller: _scroll,
                padding: EdgeInsets.fromLTRB(
                    12 + pad.left, 14, 12 + pad.right, 24 + pad.bottom),
                child: Container(
                  // إطار المصحف المزخرف
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: paper.frame, width: 2),
                  ),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(17),
                      border: Border.all(
                          color: paper.frame.withAlpha(120), width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        banner(),
                        if (showBasmala)
                          Padding(
                            padding: const EdgeInsets.only(top: 16, bottom: 2),
                            child: Text(
                              _basmala,
                              textAlign: TextAlign.center,
                              style: base.copyWith(
                                  fontSize: size * 1.05,
                                  fontFamily: 'AmiriQuran',
                                  color: paper.dark ? paper.frame : kGreen),
                            ),
                          ),
                        divider(),
                        for (var i = 0; i < _keys.length; i++) chunk(i),
                        divider(),
                        Row(children: [
                          if (_surah < 114)
                            navButton('سورة ${surahName(_surah + 1)}',
                                Icons.chevron_right_rounded,
                                () => _changeSurah(_surah + 1)),
                          if (_surah < 114 && _surah > 1)
                            const SizedBox(width: 10),
                          if (_surah > 1)
                            navButton('سورة ${surahName(_surah - 1)}',
                                Icons.chevron_left_rounded,
                                () => _changeSurah(_surah - 1)),
                        ]),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
