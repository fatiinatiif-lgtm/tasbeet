// lib/features/quran/quran_search.dart
import 'package:quran/quran.dart' as quran;
import '../../data/quran/surah_data.dart';

/// تطبيع النص العربي للبحث: حذف التشكيل والألف وتوحيد الياء والتاء المربوطة
String normalizeAr(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    // التشكيل والعلامات القرآنية والتطويل
    if ((r >= 0x0610 && r <= 0x061A) ||
        (r >= 0x064B && r <= 0x065F) ||
        r == 0x0670 ||
        (r >= 0x06D6 && r <= 0x06ED) ||
        r == 0x0640) {
      continue;
    }
    switch (r) {
      case 0x0627: // ا
      case 0x0623: // أ
      case 0x0625: // إ
      case 0x0622: // آ
      case 0x0671: // ٱ
      case 0x0621: // ء
        continue; // نحذف الألف والهمزة فيتطابق الرسم العثماني مع الإملائي
      case 0x0649: // ى
      case 0x0626: // ئ
        b.writeCharCode(0x064A); // ي
        break;
      case 0x0629: // ة
        b.writeCharCode(0x0647); // ه
        break;
      case 0x0624: // ؤ
        b.writeCharCode(0x0648); // و
        break;
      default:
        b.writeCharCode(r);
    }
  }
  return b.toString();
}

class QuranHit {
  final int surah, ayah;
  const QuranHit(this.surah, this.ayah);
}

class QuranSearchResult {
  final List<QuranHit> hits; // أول 100 نتيجة
  final int total;
  const QuranSearchResult(this.hits, this.total);
}

List<String>? _index;
final List<QuranHit> _pos = [];

Future<void>? _building;

Future<void> _ensureIndex() => _building ??= _build();

Future<void> _build() async {
  final idx = <String>[];
  for (final sr in allSurahs) {
    for (var v = 1; v <= sr.ayahCount; v++) {
      idx.add(normalizeAr(quran.getVerse(sr.number, v)));
      _pos.add(QuranHit(sr.number, v));
    }
    // نترك للواجهة فرصة للتحديث أثناء بناء الفهرس أول مرة
    if (sr.number % 20 == 0) await Future<void>.delayed(Duration.zero);
  }
  _index = idx;
}

Future<QuranSearchResult> searchQuran(String query) async {
  final q = normalizeAr(query.trim());
  if (q.length < 2) return const QuranSearchResult([], 0);
  await _ensureIndex();
  final idx = _index!;
  final hits = <QuranHit>[];
  var total = 0;
  for (var i = 0; i < idx.length; i++) {
    if (idx[i].contains(q)) {
      total++;
      if (hits.length < 100) hits.add(_pos[i]);
    }
  }
  return QuranSearchResult(hits, total);
}
