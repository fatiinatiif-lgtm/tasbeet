// lib/features/quran/quran_data.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qcf_quran/qcf_quran.dart';
import '../wird/wird_provider.dart';

/// بداية كل جزء: (رقم السورة، رقم الآية)
const List<(int, int)> kJuzStart = [
  (1, 1), (2, 142), (2, 253), (3, 93), (4, 24), (4, 148), (5, 82), (6, 111),
  (7, 88), (8, 41), (9, 93), (11, 6), (12, 53), (15, 1), (17, 1), (18, 75),
  (21, 1), (23, 1), (25, 21), (27, 56), (29, 46), (33, 31), (36, 28), (39, 32),
  (41, 47), (46, 1), (51, 31), (58, 1), (67, 1), (78, 1),
];

const _digits = '٠١٢٣٤٥٦٧٨٩';

/// تحويل الأرقام إلى الأرقام العربية
String arNum(int n) =>
    n.toString().split('').map((c) => _digits[int.parse(c)]).join();

/// صفحة بداية كل سورة في مصحف المدينة (604 صفحة)
final List<int> kSurahStartPage =
    List.generate(114, (i) => getPageNumber(i + 1, 1));

/// صفحة بداية كل جزء
final List<int> kJuzStartPage =
    [for (final j in kJuzStart) getPageNumber(j.$1, j.$2)];

/// السورة التي تبدأ بها الصفحة (أو التي تتصدّرها)
int surahOfPage(int page) {
  for (var i = 113; i >= 0; i--) {
    if (kSurahStartPage[i] <= page) return i + 1;
  }
  return 1;
}

/// الجزء الذي تقع فيه الصفحة
int juzOfPage(int page) {
  for (var i = 29; i >= 0; i--) {
    if (kJuzStartPage[i] <= page) return i + 1;
  }
  return 1;
}

/// الجزء الذي تقع فيه آية
int juzOfAyah(int surah, int ayah) {
  final k = surah * 1000 + ayah;
  for (var i = 29; i >= 0; i--) {
    if (kJuzStart[i].$1 * 1000 + kJuzStart[i].$2 <= k) return i + 1;
  }
  return 1;
}

/// الخطوط المتاحة للقراءة: (الاسم، العائلة، معامل الحجم)
const List<(String, String, double)> kQuranFonts = [
  ('أميري قرآن', 'AmiriQuran', 1.0),
  ('أميري', 'Amiri', 1.0),
  ('شهرزاد', 'ScheherazadeNew', 0.95),
  ('لطيف', 'Lateef', 1.28),
];

/// خلفيات القراءة: (الاسم، لون الورق، لون النص، لون الإطار، داكنة؟)
/// الخيار 0 «تلقائي» يتبع وضع التطبيق (فاتح/داكن)
const List<(String, int, int, int, bool)> kQuranPapers = [
  ('تلقائي', 0, 0, 0, false),
  ('كريمي', 0xFFFAF3E0, 0xFF2B2118, 0xFFC9A227, false),
  ('أبيض', 0xFFFFFFFF, 0xFF111111, 0xFFB8A25A, false),
  ('أخضر هادئ', 0xFFEAF3E8, 0xFF14281A, 0xFF5E8C61, false),
  ('ليلي', 0xFF10151C, 0xFFE8E2D0, 0xFFB8963E, true),
];

/// إعداد رقمي بسيط يُحفظ في SharedPreferences
class _IntPref extends Notifier<int> {
  final String key;
  final int def;
  final int max;
  _IntPref(this.key, this.def, this.max);

  @override
  int build() {
    final v = ref.read(sharedPrefsProvider).getInt(key) ?? def;
    return (v >= 0 && v < max) ? v : def;
  }

  void set(int v) {
    ref.read(sharedPrefsProvider).setInt(key, v);
    state = v;
  }
}

final quranFontProvider = NotifierProvider<_IntPref, int>(
    () => _IntPref('quran_font_v1', 0, kQuranFonts.length));
final quranPaperProvider = NotifierProvider<_IntPref, int>(
    () => _IntPref('quran_paper_v1', 0, kQuranPapers.length));

/// آخر موضع وصلتَ إليه "سورة:آية" (يُحفظ تلقائيًا أثناء القراءة)
class QuranLastNotifier extends Notifier<(int, int)?> {
  static const _key = 'quran_last_v2';
  static const _oldKey = 'quran_page_v1'; // نسخة قديمة كانت تحفظ رقم الصفحة

  @override
  (int, int)? build() {
    final prefs = ref.read(sharedPrefsProvider);
    final v = prefs.getString(_key);
    if (v != null) {
      final p = v.split(':');
      if (p.length == 2) {
        final s = int.tryParse(p[0]), a = int.tryParse(p[1]);
        if (s != null && a != null && s >= 1 && s <= 114) return (s, a);
      }
    }
    final old = prefs.getInt(_oldKey);
    if (old != null) return (surahOfPage(old), 1);
    return null;
  }

  void set(int surah, int ayah) {
    if (state == (surah, ayah)) return;
    ref.read(sharedPrefsProvider).setString(_key, '$surah:$ayah');
    state = (surah, ayah);
  }
}

final quranLastProvider =
    NotifierProvider<QuranLastNotifier, (int, int)?>(QuranLastNotifier.new);

/// حجم خط القراءة
class QuranFontSizeNotifier extends Notifier<double> {
  static const _key = 'quran_font_size_v1';

  @override
  double build() =>
      (ref.read(sharedPrefsProvider).getDouble(_key) ?? 26).clamp(18, 44);

  void set(double v) {
    ref.read(sharedPrefsProvider).setDouble(_key, v);
    state = v;
  }
}

final quranFontSizeProvider =
    NotifierProvider<QuranFontSizeNotifier, double>(QuranFontSizeNotifier.new);

/// علامة قراءة (يمكن تسميتها)
class QuranBookmark {
  final int surah, ayah;
  final String? name;
  const QuranBookmark(this.surah, this.ayah, [this.name]);

  Map<String, dynamic> toJson() => {'s': surah, 'a': ayah, 'n': name};

  factory QuranBookmark.fromJson(Map<String, dynamic> j) =>
      QuranBookmark(j['s'] as int, j['a'] as int, j['n'] as String?);
}

/// علامات القراءة المتعددة
class QuranBookmarksNotifier extends Notifier<List<QuranBookmark>> {
  static const _key = 'quran_bookmarks_v3';
  static const _oldKey = 'quran_bookmark_v2'; // علامة واحدة بصيغة "صفحة:سورة:آية"

  @override
  List<QuranBookmark> build() {
    final prefs = ref.read(sharedPrefsProvider);
    final raw = prefs.getString(_key);
    if (raw != null) {
      try {
        return (jsonDecode(raw) as List)
            .map((e) => QuranBookmark.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        return [];
      }
    }
    final old = prefs.getString(_oldKey);
    if (old != null) {
      final p = old.split(':');
      if (p.length == 3) {
        final sr = int.tryParse(p[1]), ay = int.tryParse(p[2]);
        if (sr != null && ay != null) return [QuranBookmark(sr, ay)];
      }
    }
    return [];
  }

  bool has(int surah, int ayah) =>
      state.any((b) => b.surah == surah && b.ayah == ayah);

  void _save(List<QuranBookmark> l) {
    ref
        .read(sharedPrefsProvider)
        .setString(_key, jsonEncode(l.map((b) => b.toJson()).toList()));
    state = l;
  }

  void add(int surah, int ayah, {String? name}) {
    final n = (name ?? '').trim();
    _save([
      QuranBookmark(surah, ayah, n.isEmpty ? null : n),
      ...state.where((b) => !(b.surah == surah && b.ayah == ayah)),
    ]);
  }

  void remove(int surah, int ayah) => _save(
      state.where((b) => !(b.surah == surah && b.ayah == ayah)).toList());
}

final quranBookmarksProvider =
    NotifierProvider<QuranBookmarksNotifier, List<QuranBookmark>>(
        QuranBookmarksNotifier.new);

/// وضع الحفظ: 0 إيقاف، 1 إخفاء الآيات، 2 إخفاء مع إظهار أول كلمة
final quranHideProvider = StateProvider<int>((ref) => 0);
