// lib/features/quran/quran_data.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qcf_quran/qcf_quran.dart';
import '../wird/wird_provider.dart';

/// بداية كل جزء: (رقم السورة، رقم الآية)
const List<(int, int)> kJuzStart = [
  (1, 1), (2, 142), (2, 253), (3, 93), (4, 24), (4, 148), (5, 82), (6, 111),
  (7, 88), (8, 41), (9, 93), (11, 6), (12, 53), (15, 1), (17, 1), (18, 75),
  (21, 1), (23, 1), (25, 21), (27, 56), (29, 46), (33, 31), (36, 28), (39, 32),
  (41, 47), (46, 1), (51, 31), (58, 1), (67, 1), (78, 1),
];

const _digits = '٠١٢٣٤٥٦٧٨٩';

/// تحويل الأرقام إلى الأرقام العربية
String arNum(int n) =>
    n.toString().split('').map((c) => _digits[int.parse(c)]).join();

/// صفحة بداية كل سورة في مصحف المدينة (604 صفحة)
final List<int> kSurahStartPage =
    List.generate(114, (i) => getPageNumber(i + 1, 1));

/// صفحة بداية كل جزء
final List<int> kJuzStartPage =
    [for (final j in kJuzStart) getPageNumber(j.$1, j.$2)];

/// السورة التي تبدأ بها الصفحة (أو التي تتصدّرها)
int surahOfPage(int page) {
  for (var i = 113; i >= 0; i--) {
    if (kSurahStartPage[i] <= page) return i + 1;
  }
  return 1;
}

/// الجزء الذي تقع فيه الصفحة
int juzOfPage(int page) {
  for (var i = 29; i >= 0; i--) {
    if (kJuzStartPage[i] <= page) return i + 1;
  }
  return 1;
}

/// آخر موضع وصلتَ إليه "سورة:آية" (يُحفظ تلقائيًا أثناء القراءة)
class QuranLastNotifier extends Notifier<(int, int)?> {
  static const _key = 'quran_last_v2';
  static const _oldKey = 'quran_page_v1'; // نسخة قديمة كانت تحفظ رقم الصفحة

  @override
  (int, int)? build() {
    final prefs = ref.read(sharedPrefsProvider);
    final v = prefs.getString(_key);
    if (v != null) {
      final p = v.split(':');
      if (p.length == 2) {
        final s = int.tryParse(p[0]), a = int.tryParse(p[1]);
        if (s != null && a != null && s >= 1 && s <= 114) return (s, a);
      }
    }
    final old = prefs.getInt(_oldKey);
    if (old != null) return (surahOfPage(old), 1);
    return null;
  }

  void set(int surah, int ayah) {
    if (state == (surah, ayah)) return;
    ref.read(sharedPrefsProvider).setString(_key, '$surah:$ayah');
    state = (surah, ayah);
  }
}

final quranLastProvider =
    NotifierProvider<QuranLastNotifier, (int, int)?>(QuranLastNotifier.new);

/// حجم خط القراءة
class QuranFontSizeNotifier extends Notifier<double> {
  static const _key = 'quran_font_size_v1';

  @override
  double build() =>
      (ref.read(sharedPrefsProvider).getDouble(_key) ?? 26).clamp(18, 44);

  void set(double v) {
    ref.read(sharedPrefsProvider).setDouble(_key, v);
    state = v;
  }
}

final quranFontSizeProvider =
    NotifierProvider<QuranFontSizeNotifier, double>(QuranFontSizeNotifier.new);

/// علامة قراءة محددة: "صفحة:سورة:آية"
class QuranBookmarkNotifier extends Notifier<String?> {
  static const _key = 'quran_bookmark_v2';

  @override
  String? build() => ref.read(sharedPrefsProvider).getString(_key);

  void set(int page, int surah, int ayah) {
    final v = '$page:$surah:$ayah';
    ref.read(sharedPrefsProvider).setString(_key, v);
    state = v;
  }

  void clear() {
    ref.read(sharedPrefsProvider).remove(_key);
    state = null;
  }
}

final quranBookmarkProvider =
    NotifierProvider<QuranBookmarkNotifier, String?>(QuranBookmarkNotifier.new);
