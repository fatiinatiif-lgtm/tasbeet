// lib/features/quran/quran_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/quran/surah_data.dart';
import 'quran_data.dart';
import 'quran_reader.dart';

/// خانة «القرآن الكريم» في الشريط السفلي
class QuranTab extends ConsumerStatefulWidget {
  const QuranTab({super.key});

  @override
  ConsumerState<QuranTab> createState() => _QuranTabState();
}

class _QuranTabState extends ConsumerState<QuranTab> {
  String _q = '';
  int _mode = 0; // 0 سور، 1 أجزاء

  void _open(int page) => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => MushafReader(initialPage: page)));

  void _info() {
    showDialog<void>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('عن المصحف',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: const SingleChildScrollView(
            child: Text(
              'مصحف المدينة النبوية برواية حفص عن عاصم، 604 صفحة، بنفس تقسيم الصفحات والأسطر في المصحف المطبوع.\n\n'
              'الخط: خطوط مجمع الملك فهد لطباعة المصحف الشريف (QCF)، وهي مضمّنة داخل التطبيق فلا يحتاج إنترنت.\n\n'
              'للتأكد التام يُنصح بمقابلة بعض المواضع بالمصحف المطبوع.',
              style: TextStyle(height: 1.8),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final last = ref.watch(quranPageProvider);
    final bm = ref.watch(quranBookmarkProvider);
    final q = _q.replaceAll('سورة', '').trim();
    final list = allSurahs.where((s) {
      if (q.isEmpty) return true;
      return s.name.contains(q) || s.number.toString() == q;
    }).toList();

    int? bp, bs, ba;
    if (bm != null) {
      final p = bm.split(':');
      if (p.length == 3) {
        bp = int.tryParse(p[0]);
        bs = int.tryParse(p[1]);
        ba = int.tryParse(p[2]);
      }
    }

    return Column(children: [
      ScreenHeader(
        title: 'القرآن الكريم',
        subtitle: 'مصحف المدينة النبوية • 604 صفحة',
        showBack: false,
        trailing: IconButton(
          tooltip: 'عن المصحف',
          onPressed: _info,
          icon: const Icon(Icons.verified_rounded, color: Colors.white),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: TextField(
          onChanged: (v) => setState(() => _q = v),
          decoration: InputDecoration(
            hintText: 'ابحث باسم السورة أو رقمها',
            prefixIcon: const Icon(Icons.search_rounded),
            filled: true,
            fillColor: kCard,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: kBorder)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: kBorder)),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Row(children: [
          ChoiceChip(
            label: const Text('السور'),
            selected: _mode == 0,
            selectedColor: kGreen.withAlpha(50),
            onSelected: (_) => setState(() => _mode = 0),
          ),
          const SizedBox(width: 8),
          ChoiceChip(
            label: const Text('الأجزاء'),
            selected: _mode == 1,
            selectedColor: kGreen.withAlpha(50),
            onSelected: (_) => setState(() => _mode = 1),
          ),
        ]),
      ),
      Expanded(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
          children: [
            if (last != null)
              _card(
                Icons.menu_book_rounded,
                'متابعة القراءة',
                'صفحة ${arNum(last)} • سورة ${surahName(surahOfPage(last))} • الجزء ${arNum(juzOfPage(last))}',
                () => _open(last),
              ),
            if (bp != null && bs != null && ba != null && bs >= 1 && bs <= 114)
              _card(
                Icons.bookmark_rounded,
                'علامة القراءة',
                'صفحة ${arNum(bp)} • سورة ${surahName(bs)} • الآية ${arNum(ba)}',
                () => _open(bp!),
                onClear: () => ref.read(quranBookmarkProvider.notifier).clear(),
              ),
            if (_mode == 0)
              for (final s in list)
                _row(
                    NumBadge(text: '${s.number}', size: 44, color: kGreen),
                    'سورة ${s.name}',
                    '${arNum(s.ayahCount)} آية • صفحة ${arNum(kSurahStartPage[s.number - 1])}',
                    () => _open(kSurahStartPage[s.number - 1]))
            else
              for (var i = 0; i < kJuzStart.length; i++)
                _row(
                    NumBadge(text: '${i + 1}', size: 44, color: kGold),
                    'الجزء ${arNum(i + 1)}',
                    'يبدأ من سورة ${surahName(kJuzStart[i].$1)} • صفحة ${arNum(kJuzStartPage[i])}',
                    () => _open(kJuzStartPage[i])),
          ],
        ),
      ),
    ]);
  }

  Widget _card(IconData icon, String title, String sub, VoidCallback onTap,
          {VoidCallback? onClear}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: cardDeco(radius: 18, border: kGold.withAlpha(150)),
            child: Row(children: [
              Icon(icon, color: kGold, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              color: kInk)),
                      Text(sub, style: TextStyle(color: kMuted)),
                    ]),
              ),
              if (onClear != null)
                IconButton(
                  tooltip: 'حذف العلامة',
                  onPressed: onClear,
                  icon: Icon(Icons.close_rounded, color: kMuted),
                ),
            ]),
          ),
        ),
      );

  Widget _row(Widget lead, String title, String sub, VoidCallback onTap) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: cardDeco(radius: 16),
            child: Row(children: [
              lead,
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w800,
                              color: kInk)),
                      Text(sub, style: TextStyle(color: kMuted, fontSize: 12.5)),
                    ]),
              ),
              Icon(Icons.chevron_left_rounded, color: kMuted),
            ]),
          ),
        ),
      );
}
