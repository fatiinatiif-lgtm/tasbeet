// lib/features/quran/quran_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/quran/surah_data.dart';
import 'quran_data.dart';
import 'package:quran/quran.dart' as quran;
import 'quran_reader.dart';
import 'quran_search.dart';

/// خانة «القرآن الكريم» في الشريط السفلي
class QuranTab extends ConsumerStatefulWidget {
  const QuranTab({super.key});

  @override
  ConsumerState<QuranTab> createState() => _QuranTabState();
}

class _QuranTabState extends ConsumerState<QuranTab> {
  String _q = '';
  int _mode = 0; // 0 سور، 1 أجزاء، 2 بحث في الآيات
  final _ctrl = TextEditingController();
  QuranSearchResult? _res;
  bool _searching = false;
  int _token = 0;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _open(int surah, [int ayah = 1]) => Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MushafReader(surah: surah, ayah: ayah)));

  void _info() {
    showDialog<void>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: const Text('عن المصحف',
              style: TextStyle(fontWeight: FontWeight.w800)),
          content: const SingleChildScrollView(
            child: Text(
              'القرآن الكريم برواية حفص عن عاصم بالرسم العثماني، يُعرض كنص مقروء يتكيّف مع عرض شاشة جوالك، ويمكنك البحث في الآيات وتكبير الخط أو تصغيره من أيقونة الخط داخل السورة.\n\n'
              'الخط مضمّن داخل التطبيق ولا يحتاج إنترنت.\n\n'
              'للتأكد التام يُنصح بمقابلة بعض المواضع بالمصحف المطبوع.',
              style: TextStyle(height: 1.8),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
          ],
        ),
      ),
    );
  }

  Future<void> _runSearch(String v) async {
    final token = ++_token;
    if (normalizeAr(v.trim()).length < 2) {
      setState(() {
        _res = null;
        _searching = false;
      });
      return;
    }
    setState(() => _searching = true);
    final r = await searchQuran(v);
    if (!mounted || token != _token) return;
    setState(() {
      _res = r;
      _searching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final last = ref.watch(quranLastProvider);
    final bms = ref.watch(quranBookmarksProvider);
    final q = _q.replaceAll('سورة', '').trim();
    final list = allSurahs.where((s) {
      if (q.isEmpty) return true;
      return s.name.contains(q) || s.number.toString() == q;
    }).toList();

    return Column(children: [
      ScreenHeader(
        title: 'القرآن الكريم',
        subtitle: 'المصحف الشريف • نص مقروء',
        showBack: false,
        trailing: IconButton(
          tooltip: 'عن المصحف',
          onPressed: _info,
          icon: const Icon(Icons.verified_rounded, color: Colors.white),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: TextField(
          controller: _ctrl,
          onChanged: (v) {
            setState(() => _q = v);
            if (_mode == 2) _runSearch(v);
          },
          decoration: InputDecoration(
            hintText: _mode == 2
                ? 'ابحث في الآيات بكلمة أو أكثر'
                : 'ابحث باسم السورة أو رقمها',
            prefixIcon: const Icon(Icons.search_rounded),
            filled: true,
            fillColor: kCard,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: kBorder)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: kBorder)),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Wrap(spacing: 8, children: [
          for (final m in const [(0, 'السور'), (1, 'الأجزاء'), (2, 'بحث في الآيات')])
            ChoiceChip(
              label: Text(m.$2),
              selected: _mode == m.$1,
              selectedColor: kGreen.withAlpha(50),
              onSelected: (_) {
                setState(() => _mode = m.$1);
                if (m.$1 == 2) _runSearch(_q);
              },
            ),
        ]),
      ),
      Expanded(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
          children: [
            if (_mode == 2) ..._searchBody() else ...[
              if (last != null)
                _card(
                  Icons.menu_book_rounded,
                  'متابعة القراءة',
                  'سورة ${surahName(last.$1)} • الآية ${arNum(last.$2)}',
                  () => _open(last.$1, last.$2),
                ),
              if (bms.isNotEmpty) _bookmarksBox(bms),
              if (_mode == 0)
                for (final s in list)
                  _row(
                      NumBadge(text: '${s.number}', size: 44, color: kGreen),
                      'سورة ${s.name}',
                      '${arNum(s.ayahCount)} آية • صفحة ${arNum(kSurahStartPage[s.number - 1])}',
                      () => _open(s.number))
              else
                for (var i = 0; i < kJuzStart.length; i++)
                  _row(
                      NumBadge(text: '${i + 1}', size: 44, color: kGold),
                      'الجزء ${arNum(i + 1)}',
                      'يبدأ من سورة ${surahName(kJuzStart[i].$1)} • الآية ${arNum(kJuzStart[i].$2)}',
                      () => _open(kJuzStart[i].$1, kJuzStart[i].$2)),
            ],
          ],
        ),
      ),
    ]);
  }

  List<Widget> _searchBody() {
    if (_searching) {
      return [
        const Padding(
            padding: EdgeInsets.all(30),
            child: Center(child: CircularProgressIndicator()))
      ];
    }
    final r = _res;
    if (r == null) {
      return [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
              'اكتب كلمة أو أكثر (حرفان على الأقل). البحث يتجاوز التشكيل والهمزات، فيكفي أن تكتب الكلمة كما تنطقها.',
              style: TextStyle(color: kMuted, height: 1.7)),
        ),
      ];
    }
    if (r.total == 0) {
      return [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text('لا توجد نتائج.', style: TextStyle(color: kMuted)),
        ),
      ];
    }
    return [
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(
            r.total > r.hits.length
                ? '${arNum(r.total)} نتيجة (تُعرض أول ${arNum(r.hits.length)})'
                : '${arNum(r.total)} نتيجة',
            style: TextStyle(color: kMuted, fontWeight: FontWeight.w700)),
      ),
      for (final h in r.hits)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => _open(h.surah, h.ayah),
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: cardDeco(radius: 16),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('سورة ${surahName(h.surah)} • الآية ${arNum(h.ayah)}',
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: kGreen,
                            fontSize: 13.5)),
                    const SizedBox(height: 6),
                    Text(quran.getVerse(h.surah, h.ayah),
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                            fontFamily: 'AmiriQuran',
                            fontSize: 20,
                            height: 1.9,
                            color: kInk)),
                  ]),
            ),
          ),
        ),
    ];
  }

  Widget _bookmarksBox(List<QuranBookmark> bms) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Container(
          decoration: cardDeco(radius: 18, border: kGold.withAlpha(150)),
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              leading: Icon(Icons.bookmark_rounded, color: kGold, size: 28),
              title: Text('علامات القراءة (${arNum(bms.length)})',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 16, color: kInk)),
              children: [
                for (final b in bms)
                  ListTile(
                    onTap: () => _open(b.surah, b.ayah),
                    title: Text(
                        b.name ?? 'سورة ${surahName(b.surah)} • الآية ${arNum(b.ayah)}',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: b.name == null
                        ? null
                        : Text(
                            'سورة ${surahName(b.surah)} • الآية ${arNum(b.ayah)}'),
                    trailing: IconButton(
                      tooltip: 'حذف العلامة',
                      icon: Icon(Icons.close_rounded, color: kMuted),
                      onPressed: () => ref
                          .read(quranBookmarksProvider.notifier)
                          .remove(b.surah, b.ayah),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );

  Widget _card(IconData icon, String title, String sub, VoidCallback onTap,
          {VoidCallback? onClear}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: cardDeco(radius: 18, border: kGold.withAlpha(150)),
            child: Row(children: [
              Icon(icon, color: kGold, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              color: kInk)),
                      Text(sub, style: TextStyle(color: kMuted)),
                    ]),
              ),
              if (onClear != null)
                IconButton(
                  tooltip: 'حذف العلامة',
                  onPressed: onClear,
                  icon: Icon(Icons.close_rounded, color: kMuted),
                ),
            ]),
          ),
        ),
      );

  Widget _row(Widget lead, String title, String sub, VoidCallback onTap) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: cardDeco(radius: 16),
            child: Row(children: [
              lead,
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w800,
                              color: kInk)),
                      Text(sub, style: TextStyle(color: kMuted, fontSize: 12.5)),
                    ]),
              ),
              Icon(Icons.chevron_left_rounded, color: kMuted),
            ]),
          ),
        ),
      );
}
