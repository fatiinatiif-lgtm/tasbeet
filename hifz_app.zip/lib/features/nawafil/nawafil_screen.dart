// lib/features/nawafil/nawafil_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import 'nawafil_provider.dart';

const nawafilColors = [Color(0xFFB06A1B), Color(0xFF6B3A08)];

const _dayShort = {6: 'س', 7: 'ح', 1: 'ن', 2: 'ث', 3: 'ر', 4: 'خ', 5: 'ج'};

class NawafilScreen extends ConsumerWidget {
  const NawafilScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.watch(nawafilProvider);
    final n = ref.read(nawafilProvider.notifier);
    final today = todayString();
    final wd = DateTime.now().weekday;
    final accent = nawafilColors[0];
    final doneCount = nawafilCountOn(m, today);

    String? dayHint;
    if (wd == 1) dayHint = 'اليوم الإثنين: يُستحب صيامه';
    if (wd == 4) dayHint = 'اليوم الخميس: يُستحب صيامه';

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'النوافل',
          subtitle: 'اليوم: $doneCount من ${kNawafil.length}',
          colors: nawafilColors,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: cardDeco(radius: 18, border: kGold.withAlpha(120)),
                child: Row(children: [
                  Icon(Icons.wb_twilight_rounded, color: kGold, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      '${dayHint == null ? '' : '$dayHint. '}الأيام البيض: 13 و14 و15 من كل شهر هجري.',
                      style: TextStyle(
                          color: kInk, fontWeight: FontWeight.w700, height: 1.6),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 18),
              const SectionTitle('نوافل اليوم'),
              const SizedBox(height: 12),
              for (final it in kNawafil)
                _ItemCard(
                  item: it,
                  done: nawafilDone(m, today, it.key),
                  streak: nawafilStreak(m, it.key),
                  month: nawafilMonth(m, it.key),
                  accent: accent,
                  onTap: () => n.toggle(today, it.key),
                ),
              const SizedBox(height: 18),
              const SectionTitle('آخر 7 أيام'),
              const SizedBox(height: 4),
              Text('اضغط على أي دائرة لتسجيل يوم فاتك',
                  style: TextStyle(color: kMuted, fontSize: 12.5)),
              const SizedBox(height: 12),
              _WeekGrid(map: m, accent: accent, onToggle: n.toggle),
            ],
          ),
        ),
      ]),
    );
  }
}

class _ItemCard extends StatelessWidget {
  final NawafilItem item;
  final bool done;
  final int streak, month;
  final Color accent;
  final VoidCallback onTap;
  const _ItemCard(
      {required this.item,
      required this.done,
      required this.streak,
      required this.month,
      required this.accent,
      required this.onTap});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: done ? accent.withAlpha(24) : kCard,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: done ? accent : kBorder, width: done ? 1.6 : 1),
              boxShadow: done ? null : softShadow(0.05),
            ),
            child: Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withAlpha(done ? 60 : 28),
                ),
                child: Icon(item.icon, color: accent),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.title,
                      style: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w800,
                          color: done ? accent : kInk)),
                  const SizedBox(height: 2),
                  Text(item.sub,
                      style: TextStyle(fontSize: 12.5, color: kMuted)),
                  const SizedBox(height: 3),
                  Text('متتالية: $streak • هذا الشهر: $month',
                      style: TextStyle(
                          fontSize: 12.5,
                          color: kGoldText,
                          fontWeight: FontWeight.w700)),
                ]),
              ),
              CheckDot(on: done, color: accent),
            ]),
          ),
        ),
      );
}

class _WeekGrid extends StatelessWidget {
  final Map<String, List<String>> map;
  final Color accent;
  final void Function(String date, String key) onToggle;
  const _WeekGrid(
      {required this.map, required this.accent, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final days = [
      for (var i = 6; i >= 0; i--) DateTime(now.year, now.month, now.day - i),
    ];
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      decoration: cardDeco(radius: 20),
      child: Column(children: [
        Row(children: [
          const SizedBox(width: 96),
          for (final d in days)
            Expanded(
              child: Center(
                child: Text(_dayShort[d.weekday]!,
                    style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: kMuted)),
              ),
            ),
        ]),
        const SizedBox(height: 6),
        for (final it in kNawafil)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [
              SizedBox(
                width: 96,
                child: Text(it.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 13, color: kInk)),
              ),
              for (final d in days)
                Expanded(
                  child: Center(
                    child: GestureDetector(
                      onTap: () => onToggle(dayString(d), it.key),
                      child: CheckDot(
                        on: nawafilDone(map, dayString(d), it.key),
                        color: accent,
                        size: 22,
                      ),
                    ),
                  ),
                ),
            ]),
          ),
      ]),
    );
  }
}
