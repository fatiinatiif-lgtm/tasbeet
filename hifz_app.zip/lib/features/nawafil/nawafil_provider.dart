// lib/features/nawafil/nawafil_provider.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

class NawafilItem {
  final String key, title, sub;
  final IconData icon;
  const NawafilItem(this.key, this.title, this.sub, this.icon);
}

const kNawafil = <NawafilItem>[
  NawafilItem('duha', 'صلاة الضحى', 'ركعتان فأكثر', Icons.wb_sunny_rounded),
  NawafilItem('witr', 'الوتر', 'ركعة فأكثر قبل الفجر', Icons.nights_stay_rounded),
  NawafilItem('rawatib', 'السنن الرواتب', 'اثنتا عشرة ركعة في اليوم',
      Icons.mosque_rounded),
  NawafilItem('fast', 'صيام تطوّع', 'الإثنين والخميس والأيام البيض',
      Icons.hourglass_bottom_rounded),
  NawafilItem('sadaqa', 'الصدقة', 'ولو بالقليل', Icons.volunteer_activism_rounded),
];

/// تاريخ اليوم (yyyy-MM-dd) ← قائمة النوافل المنجزة
class NawafilNotifier extends Notifier<Map<String, List<String>>> {
  static const _key = 'nawafil_v1';

  @override
  Map<String, List<String>> build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return {};
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      return j.map((k, v) => MapEntry(k, (v as List).cast<String>()));
    } catch (_) {
      return {};
    }
  }

  void toggle(String date, String key) {
    final m = {...state};
    final l = [...(m[date] ?? <String>[])];
    if (l.contains(key)) {
      l.remove(key);
    } else {
      l.add(key);
    }
    if (l.isEmpty) {
      m.remove(date);
    } else {
      m[date] = l;
    }
    state = m;
    ref.read(sharedPrefsProvider).setString(_key, jsonEncode(m));
  }
}

final nawafilProvider =
    NotifierProvider<NawafilNotifier, Map<String, List<String>>>(
        NawafilNotifier.new);

bool nawafilDone(Map<String, List<String>> m, String date, String key) =>
    m[date]?.contains(key) ?? false;

int nawafilCountOn(Map<String, List<String>> m, String date) =>
    m[date]?.length ?? 0;

/// أيام متتالية على نافلة معينة
int nawafilStreak(Map<String, List<String>> m, String key) {
  final n = DateTime.now();
  String d(int back) => dayString(DateTime(n.year, n.month, n.day - back));
  bool has(int back) => nawafilDone(m, d(back), key);
  final start = has(0) ? 0 : (has(1) ? 1 : -1);
  if (start < 0) return 0;
  var c = 0;
  while (has(start + c)) {
    c++;
  }
  return c;
}

/// عدد مرات نافلة معينة هذا الشهر
int nawafilMonth(Map<String, List<String>> m, String key) {
  final n = DateTime.now();
  final prefix = '${n.year}-${n.month.toString().padLeft(2, '0')}-';
  return m.entries
      .where((e) => e.key.startsWith(prefix) && e.value.contains(key))
      .length;
}
