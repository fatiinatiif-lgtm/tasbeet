// lib/features/khatma/khatma_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/celebration.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

/// خيارات مدة الختمة
const khatmaOptions = <(int, String)>[
  (30, 'الختم في شهر'),
  (15, 'الختم في 15 يومًا'),
  (10, 'الختم في 10 أيام'),
  (6, 'الختم في 6 أيام'),
  (3, 'الختم في 3 أيام'),
];

String _perDay(int days) {
  final n = 30 ~/ days;
  if (n == 1) return 'جزء واحد يوميًا';
  if (n == 2) return 'جزءان يوميًا';
  return '$n أجزاء يوميًا';
}

String _rangeText(int days, int i) {
  final r = KhatmaPlan.range(days, i);
  return r.$1 == r.$2 ? 'الجزء ${r.$1}' : 'الأجزاء من ${r.$1} إلى ${r.$2}';
}

class KhatmaScreen extends ConsumerWidget {
  const KhatmaScreen({super.key});

  Future<void> _choose(BuildContext context, WidgetRef ref, int days,
      KhatmaPlan? current) async {
    final n = ref.read(wirdProvider.notifier);
    if (current != null && current.done > 0 && !current.finished) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22)),
            title: const Text('بدء ختمة جديدة',
                style: TextStyle(fontWeight: FontWeight.w800)),
            content: const Text(
                'لديك ختمة قيد التنفيذ، وسيبدأ تقدّمك فيها من جديد. هل تريد المتابعة؟',
                style: TextStyle(height: 1.7)),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('إلغاء')),
              FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: kGreen),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('نعم، ابدأ')),
            ],
          ),
        ),
      );
      if (ok != true) return;
    }
    n.startKhatma(days);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final plan = s.khatma;
    final colors = kSectionGradients[Section.reading.index];

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'ختمتي',
          subtitle: 'اختر مدة ختمتك، وسيُوزَّع القرآن على أيامك',
          colors: colors,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              if (plan != null) ...[
                _ActiveCard(plan: plan, colors: colors),
                const SizedBox(height: 22),
              ],
              SectionTitle(plan == null ? 'اختر مدة الختمة' : 'تغيير المدة'),
              const SizedBox(height: 12),
              for (final o in khatmaOptions)
                _OptionCard(
                  days: o.$1,
                  title: o.$2,
                  sub: _perDay(o.$1),
                  selected: plan?.days == o.$1,
                  accent: colors[0],
                  onTap: () => _choose(context, ref, o.$1, plan),
                ),
              if (plan != null) ...[
                const SizedBox(height: 22),
                const SectionTitle('توزيع الأجزاء على الأيام'),
                const SizedBox(height: 12),
                for (var i = 1; i <= plan.days; i++)
                  _DayRow(
                    index: i,
                    text: _rangeText(plan.days, i),
                    done: i <= plan.done,
                    today: plan.hasActive && i == plan.activeIndex,
                    accent: colors[0],
                  ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: () =>
                      ref.read(wirdProvider.notifier).cancelKhatma(),
                  icon: Icon(Icons.close_rounded, color: Colors.red[700]),
                  label: Text('إلغاء الختمة',
                      style: TextStyle(color: Colors.red[700])),
                ),
              ],
            ],
          ),
        ),
      ]),
    );
  }
}

class _ActiveCard extends ConsumerWidget {
  final KhatmaPlan plan;
  final List<Color> colors;
  const _ActiveCard({required this.plan, required this.colors});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entry = plan.entry;
    final done = entry != null && ref.watch(wirdProvider).isDoneToday(entry);
    final progress = plan.done / plan.days;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: cardDeco(radius: 22, border: kGold.withAlpha(140)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 64,
                height: 64,
                child: CircularProgressIndicator(
                  value: progress,
                  strokeWidth: 7,
                  color: colors[0],
                  backgroundColor: kBorder,
                ),
              ),
              Text('${(progress * 100).round()}%',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, color: colors[0])),
            ]),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                  khatmaOptions
                      .firstWhere((o) => o.$1 == plan.days,
                          orElse: () => (plan.days, 'ختمتي'))
                      .$2,
                  style: const TextStyle(
                      fontSize: 17.5, fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text('أنجزتَ ${plan.done} من ${plan.days} يومًا',
                  style: TextStyle(color: kMuted)),
            ]),
          ),
        ]),
        const Divider(height: 28),
        if (entry == null) ...[
          Row(children: [
            Icon(Icons.celebration_rounded, color: kGold, size: 28),
            SizedBox(width: 10),
            Expanded(
              child: Text('أتممتَ ختمتك، تقبّل الله منك. اختر مدة جديدة لتبدأ ختمة أخرى.',
                  style: TextStyle(fontWeight: FontWeight.w700, height: 1.6)),
            ),
          ]),
        ] else ...[
          Text('وردك اليوم (اليوم ${plan.activeIndex})',
              style: TextStyle(color: kMuted, fontSize: 13)),
          const SizedBox(height: 4),
          Text(entry.fullName,
              style: TextStyle(
                  fontSize: 21, fontWeight: FontWeight.w800, color: colors[0])),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: done ? kMuted : colors[0],
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () {
                ref.read(wirdProvider.notifier).toggleDone(entry);
                if (!done) showCelebration(context, entry.fullName);
              },
              icon: Icon(done ? Icons.undo_rounded : Icons.check_rounded),
              label: Text(done ? 'التراجع عن الإنجاز' : 'أتممتُ ورد اليوم'),
            ),
          ),
        ],
      ]),
    );
  }
}

class _OptionCard extends StatelessWidget {
  final int days;
  final String title, sub;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;
  const _OptionCard(
      {required this.days,
      required this.title,
      required this.sub,
      required this.selected,
      required this.accent,
      required this.onTap});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: selected ? accent.withAlpha(22) : kCard,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: selected ? accent : kBorder, width: selected ? 1.6 : 1),
              boxShadow: selected ? null : softShadow(0.05),
            ),
            child: Row(children: [
              NumBadge(
                  text: days == 30 ? 'شهر' : '$days',
                  active: selected,
                  color: accent),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title,
                      style: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w800,
                          color: selected ? accent : kInk)),
                  const SizedBox(height: 2),
                  Text(sub,
                      style: TextStyle(
                          fontSize: 13, color: kMuted)),
                ]),
              ),
              CheckDot(on: selected, color: accent),
            ]),
          ),
        ),
      );
}

class _DayRow extends StatelessWidget {
  final int index;
  final String text;
  final bool done, today;
  final Color accent;
  const _DayRow(
      {required this.index,
      required this.text,
      required this.done,
      required this.today,
      required this.accent});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: today ? kGold.withAlpha(34) : kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: today ? kGold : (done ? accent : kBorder),
              width: today ? 1.6 : 1),
        ),
        child: Row(children: [
          Text('اليوم $index',
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: done ? accent : kInk)),
          const SizedBox(width: 12),
          Expanded(
              child: Text(text,
                  style: TextStyle(color: kInk, fontSize: 14.5))),
          if (today)
            Text('اليوم',
                style: TextStyle(
                    color: kGoldDark, fontWeight: FontWeight.w800, fontSize: 12.5))
          else if (done)
            Icon(Icons.check_circle_rounded, color: accent, size: 20),
        ]),
      );
}
