// lib/features/select/select_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class SelectScreen extends ConsumerWidget {
  final Section section;
  const SelectScreen({super.key, required this.section});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(section.label),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(children: [
        Expanded(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _Column(section: section, type: UnitType.surah, title: 'السور', count: 114),
            _Column(section: section, type: UnitType.hizb, title: 'الأحزاب', count: 60),
            _Column(section: section, type: UnitType.rub, title: 'الأرباع', count: 240),
          ]),
        ),
        SafeArea(
          top: false,
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: kBorder)),
            ),
            child: Row(children: [
              Expanded(child: Text('مختار هنا: ${s.countIn(section)}')),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: kGreen),
                onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const WirdScreen())),
                child: const Text('الورد اليومي'),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Column extends ConsumerWidget {
  final Section section;
  final UnitType type;
  final String title;
  final int count;
  const _Column(
      {required this.section,
      required this.type,
      required this.title,
      required this.count});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    return Expanded(
      child: Container(
        decoration: const BoxDecoration(
          border: Border(left: BorderSide(color: kBorder)),
        ),
        child: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            color: kGreen,
            child: Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 15)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: count,
              itemExtent: 58,
              itemBuilder: (_, i) {
                final entry = WirdEntry(section, type, i + 1);
                final sel = s.isSelected(entry);
                return InkWell(
                  onTap: () =>
                      ref.read(wirdProvider.notifier).toggleSelect(entry),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    decoration: BoxDecoration(
                      color: sel ? const Color(0xFFDDEEE9) : Colors.white,
                      border: const Border(bottom: BorderSide(color: kBorder)),
                    ),
                    child: Row(children: [
                      Icon(
                        sel ? Icons.check_circle : Icons.radio_button_unchecked,
                        size: 22,
                        color: sel ? kGreen : Colors.black38,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(unitTitle(type, i + 1),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w600)),
                            Text(unitSub(type, i + 1),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.black54)),
                          ],
                        ),
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
