// lib/features/select/select_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';
import '../wird/wird_screen.dart';

class SelectScreen extends ConsumerWidget {
  final Section section;
  const SelectScreen({super.key, required this.section});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final accent = kSectionGradients[section.index][0];

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: Column(children: [
          ScreenHeader(
            title: section.label,
            subtitle: 'اختر ما تريد إدراجه في وردك',
            colors: kSectionGradients[section.index],
            bottom: Container(
              height: 44,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: Colors.black.withAlpha(40),
                borderRadius: BorderRadius.circular(22),
              ),
              child: TabBar(
                dividerColor: Colors.transparent,
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  color: kGold,
                  borderRadius: BorderRadius.circular(18),
                ),
                labelColor: kInk,
                unselectedLabelColor: Colors.white,
                labelStyle: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14.5),
                unselectedLabelStyle:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                tabs: const [
                  Tab(text: 'السور'),
                  Tab(text: 'الأحزاب'),
                  Tab(text: 'الأرباع'),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(children: [
              _UnitList(
                  section: section,
                  type: UnitType.surah,
                  count: 114,
                  accent: accent),
              _UnitList(
                  section: section,
                  type: UnitType.hizb,
                  count: 60,
                  accent: accent),
              _UnitList(
                  section: section,
                  type: UnitType.rub,
                  count: 240,
                  accent: accent),
            ]),
          ),
          Container(
            decoration: BoxDecoration(
              color: kCard,
              boxShadow: softShadow(0.1),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(22)),
            ),
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
                child: Row(children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: accent.withAlpha(24),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text('المختار هنا: ${s.countIn(section)}',
                        style: TextStyle(
                            color: accent, fontWeight: FontWeight.w800)),
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: kGreen,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 12),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const WirdScreen())),
                    icon: const Icon(Icons.checklist_rounded, size: 20),
                    label: const Text('وردي اليومي'),
                  ),
                ]),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class _UnitList extends ConsumerWidget {
  final Section section;
  final UnitType type;
  final int count;
  final Color accent;
  const _UnitList(
      {required this.section,
      required this.type,
      required this.count,
      required this.accent});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      itemCount: count,
      itemBuilder: (_, i) {
        final entry = WirdEntry(section, type, i + 1);
        final sel = s.isSelected(entry);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => ref.read(wirdProvider.notifier).toggleSelect(entry),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: sel ? accent.withAlpha(22) : kCard,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                    color: sel ? accent : kBorder, width: sel ? 1.6 : 1),
                boxShadow: sel ? null : softShadow(0.05),
              ),
              child: Row(children: [
                NumBadge(text: '${i + 1}', active: sel, color: accent),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(unitTitle(type, i + 1),
                          style: TextStyle(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w800,
                              color: sel ? accent : kInk)),
                      const SizedBox(height: 2),
                      Text(unitSub(type, i + 1),
                          style: TextStyle(
                              fontSize: 12.5, color: kMuted)),
                    ],
                  ),
                ),
                CheckDot(on: sel, color: accent),
              ]),
            ),
          ),
        );
      },
    );
  }
}
