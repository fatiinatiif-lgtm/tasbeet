// lib/features/titles/titles_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../wird/wird_provider.dart';

class _Badge {
  final String title, desc;
  final bool Function(WirdState) test;
  const _Badge(this.title, this.desc, this.test);
}

final _badges = <_Badge>[
  _Badge('أول إنجاز', 'أنهِ أول مهمة', (s) => s.totalCompleted >= 1),
  _Badge('عشر مهام', 'أنهِ 10 مهام', (s) => s.totalCompleted >= 10),
  _Badge('مئة مهمة', 'أنهِ 100 مهمة', (s) => s.totalCompleted >= 100),
  _Badge('ثلاثة أيام', 'واظب 3 أيام متتالية', (s) => s.streak >= 3),
  _Badge('أسبوع متواصل', 'واظب 7 أيام متتالية', (s) => s.streak >= 7),
  _Badge('وسام الثبات', 'واظب 30 يومًا متتاليًا', (s) => s.streak >= 30),
  _Badge('بداية الحفظ', 'أنهِ 10 مهام في الحفظ الجديد',
      (s) => s.logs.where((l) => l.entry.section.name == 'hifz').length >= 10),
  _Badge('ختمة', 'اقرأ السور الـ114 كلها في القراءة اليومية',
      (s) => s.readSurahsDistinct >= 114),
];

class TitlesScreen extends ConsumerWidget {
  const TitlesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final xp = s.xp;
    final next = titleLadder.where((e) => e.$1 > xp).firstOrNull;
    final unlockedCount = _badges.where((b) => b.test(s)).length;

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'ألقابي',
          subtitle: 'ارتقِ بالمواظبة على وردك',
          colors: const [Color(0xFF8E4A7C), Color(0xFF4F2146)],
          bottom: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGold.withAlpha(150)),
            ),
            child: Column(children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: kGold),
                  child: const Icon(Icons.military_tech_rounded,
                      color: Colors.white, size: 30),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('لقبك: ${titleForXp(xp)}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w800)),
                        Text('$xp نقطة',
                            style: const TextStyle(color: kGoldLight)),
                      ]),
                ),
              ]),
              const SizedBox(height: 12),
              if (next != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: (xp / next.$1).clamp(0.0, 1.0),
                    minHeight: 9,
                    color: kGold,
                    backgroundColor: Colors.white24,
                  ),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                      'اللقب التالي: ${next.$2} (يتبقى ${next.$1 - xp} نقطة)',
                      style: const TextStyle(color: Colors.white70)),
                ),
              ] else
                const Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text('بلغتَ أعلى الألقاب، بارك الله فيك',
                      style: TextStyle(color: Colors.white70)),
                ),
            ]),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            children: [
              const SectionTitle('الألقاب'),
              const SizedBox(height: 12),
              for (final e in titleLadder)
                _Line(
                  title: e.$2,
                  sub: '${e.$1} نقطة',
                  done: xp >= e.$1,
                  icon: Icons.military_tech_rounded,
                ),
              const SizedBox(height: 18),
              SectionTitle('الأوسمة ($unlockedCount من ${_badges.length})'),
              const SizedBox(height: 12),
              for (final b in _badges)
                _Line(
                  title: b.title,
                  sub: b.desc,
                  done: b.test(s),
                  icon: Icons.emoji_events_rounded,
                ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kGold.withAlpha(30),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Text(
                    'النقاط: الحفظ الجديد 20، السرد غيبًا 15، المراجعة 10، القراءة 10',
                    style: TextStyle(color: Color(0xFF6B5410), height: 1.6)),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Line extends StatelessWidget {
  final String title, sub;
  final bool done;
  final IconData icon;
  const _Line(
      {required this.title,
      required this.sub,
      required this.done,
      required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: cardDeco(
          radius: 18,
          color: done ? Colors.white : const Color(0xFFF2EEE2),
          border: done ? kGold : kBorder,
        ),
        child: Row(children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: done
                  ? const LinearGradient(
                      colors: [kGold, Color(0xFFA6821A)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft)
                  : null,
              color: done ? null : Colors.black12,
            ),
            child: Icon(done ? icon : Icons.lock_outline_rounded,
                color: done ? Colors.white : Colors.black38, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      fontSize: 16.5,
                      fontWeight: FontWeight.w800,
                      color: done ? kGreen : Colors.black54)),
              const SizedBox(height: 2),
              Text(sub,
                  style: const TextStyle(color: Colors.black54, fontSize: 13)),
            ]),
          ),
          if (done)
            const Icon(Icons.verified_rounded, color: kGreen, size: 22),
        ]),
      );
}
