// lib/features/titles/titles_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../share/share_card.dart';
import '../wird/wird_provider.dart';

class _Badge {
  final String title, desc;
  final bool Function(WirdState) test;
  const _Badge(this.title, this.desc, this.test);
}

final _badges = <_Badge>[
  _Badge('أول إنجاز', 'أنهِ أول مهمة', (s) => s.totalCompleted >= 1),
  _Badge('عشر مهام', 'أنهِ 10 مهام', (s) => s.totalCompleted >= 10),
  _Badge('مئة مهمة', 'أنهِ 100 مهمة', (s) => s.totalCompleted >= 100),
  _Badge('ثلاثة أيام', 'واظب 3 أيام متتالية', (s) => s.streak >= 3),
  _Badge('أسبوع متواصل', 'واظب 7 أيام متتالية', (s) => s.streak >= 7),
  _Badge('وسام الثبات', 'واظب 30 يومًا متتاليًا', (s) => s.streak >= 30),
  _Badge('بداية الحفظ', 'أنهِ 10 مهام في الحفظ الجديد',
      (s) => s.logs.where((l) => l.entry.section.name == 'hifz').length >= 10),
  _Badge('ختمة', 'أتمم قراءة الأجزاء الثلاثين ضمن ختمتي',
      (s) => s.juzCovered >= 30),
  _Badge('أسبوع مثمر', 'أنهِ 20 مهمة في أسبوع واحد', (s) => s.bestWeek >= 20),
  _Badge('أسبوع ذهبي', 'أنهِ 50 مهمة في أسبوع واحد', (s) => s.bestWeek >= 50),
  _Badge('أسبوعان متواصلان', 'واظب 14 يومًا متتاليًا',
      (s) => s.bestStreak >= 14),
  _Badge('ثلاثون يومًا نشطًا', 'سجّل إنجازًا في 30 يومًا مختلفًا',
      (s) => s.activeDays >= 30),
  _Badge('قائم الليل', 'أنهِ 10 مهام من ختمة القيام',
      (s) => s.completedIn(Section.qiyam) >= 10),
  _Badge('ختمة القيام', 'أنهِ الأجزاء الثلاثين في ختمة القيام',
      (s) => s.qiyamJuzDone >= 30),
];

class TitlesScreen extends ConsumerWidget {
  const TitlesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final xp = s.xp;
    final next = titleLadder.where((e) => e.$1 > xp).firstOrNull;
    final unlockedCount = _badges.where((b) => b.test(s)).length;

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'ألقابي',
          subtitle: 'ارتقِ بالمواظبة على وردك',
          colors: kSectionGradients[7],
          bottom: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGold.withAlpha(150)),
            ),
            child: Column(children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kGold),
                  child: const Icon(Icons.military_tech_rounded,
                      color: Colors.white, size: 30),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('لقبك: ${titleForXp(xp)}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w800)),
                        Text('$xp نقطة',
                            style: TextStyle(color: kGoldLight)),
                      ]),
                ),
              ]),
              const SizedBox(height: 12),
              if (next != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: (xp / next.$1).clamp(0.0, 1.0),
                    minHeight: 9,
                    color: kGold,
                    backgroundColor: Colors.white24,
                  ),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                      'اللقب التالي: ${next.$2} (يتبقى ${next.$1 - xp} نقطة)',
                      style: const TextStyle(color: Colors.white70)),
                ),
              ] else
                const Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text('بلغتَ أعلى الألقاب، بارك الله فيك',
                      style: TextStyle(color: Colors.white70)),
                ),
            ]),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: kGold,
                  foregroundColor: Colors.black87,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => showShareCard(context, s, unlockedCount),
                icon: const Icon(Icons.share_rounded),
                label: const Text('مشاركة بطاقة إنجازي'),
              ),
              const SizedBox(height: 18),
              const SectionTitle('الألقاب'),
              const SizedBox(height: 12),
              for (final e in titleLadder)
                _Line(
                  title: e.$2,
                  sub: '${e.$1} نقطة',
                  done: xp >= e.$1,
                  icon: Icons.military_tech_rounded,
                ),
              const SizedBox(height: 18),
              SectionTitle('الأوسمة ($unlockedCount من ${_badges.length})'),
              const SizedBox(height: 12),
              for (final b in _badges)
                _Line(
                  title: b.title,
                  sub: b.desc,
                  done: b.test(s),
                  icon: Icons.emoji_events_rounded,
                ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kGold.withAlpha(30),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                    'النقاط: الحفظ الجديد 20، السرد غيبًا 15، ختمة القيام 15، المراجعة 10، ختمتي 10',
                    style: TextStyle(color: kGoldText, height: 1.6)),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Line extends StatelessWidget {
  final String title, sub;
  final bool done;
  final IconData icon;
  const _Line(
      {required this.title,
      required this.sub,
      required this.done,
      required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: cardDeco(
          radius: 18,
          color: done ? kCard : kBg,
          border: done ? kGold : kBorder,
        ),
        child: Row(children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: done
                  ? LinearGradient(
                      colors: [kGold, kGoldDark],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft)
                  : null,
              color: done ? null : kBorder,
            ),
            child: Icon(done ? icon : Icons.lock_outline_rounded,
                color: done ? Colors.white : kFaint, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      fontSize: 16.5,
                      fontWeight: FontWeight.w800,
                      color: done ? kGreen : kMuted)),
              const SizedBox(height: 2),
              Text(sub,
                  style: TextStyle(color: kMuted, fontSize: 13)),
            ]),
          ),
          if (done)
            Icon(Icons.verified_rounded, color: kGreen, size: 22),
        ]),
      );
}
