// lib/features/titles/titles_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../wird/wird_provider.dart';

class _Badge {
  final String title, desc;
  final bool Function(WirdState) test;
  const _Badge(this.title, this.desc, this.test);
}

final _badges = <_Badge>[
  _Badge('أول إنجاز', 'أنهي أول مهمة', (s) => s.totalCompleted >= 1),
  _Badge('عشر مهام', 'أنهي 10 مهام', (s) => s.totalCompleted >= 10),
  _Badge('مئة مهمة', 'أنهي 100 مهمة', (s) => s.totalCompleted >= 100),
  _Badge('ثلاثة أيام', '3 أيام متتالية', (s) => s.streak >= 3),
  _Badge('أسبوع متواصل', '7 أيام متتالية', (s) => s.streak >= 7),
  _Badge('وسام الثبات', '30 يوماً متتالياً', (s) => s.streak >= 30),
  _Badge('بداية الحفظ', 'أنهي 10 مهام في الحفظ الجديد',
      (s) => s.logs.where((l) => l.entry.section.name == 'hifz').length >= 10),
  _Badge('ختمة', 'اقرأي كل السور الـ114 في القراءة اليومية',
      (s) => s.readSurahsDistinct >= 114),
];

class TitlesScreen extends ConsumerWidget {
  const TitlesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final xp = s.xp;
    final next = titleLadder.where((e) => e.$1 > xp).firstOrNull;
    final unlockedCount = _badges.where((b) => b.test(s)).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ألقابي'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: kGreen,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('لقبك: ${titleForXp(xp)}',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('$xp نقطة', style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 10),
              if (next != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: (xp / next.$1).clamp(0.0, 1.0),
                    minHeight: 8,
                    color: Colors.white,
                    backgroundColor: Colors.white24,
                  ),
                ),
                const SizedBox(height: 8),
                Text('اللقب الجاي: ${next.$2} (باقي ${next.$1 - xp} نقطة)',
                    style: const TextStyle(color: Colors.white70)),
              ] else
                const Text('وصلتي لأعلى لقب',
                    style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 20),
          const Text('الألقاب',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final e in titleLadder)
            _Line(
              title: e.$2,
              sub: '${e.$1} نقطة',
              done: xp >= e.$1,
              icon: Icons.military_tech,
            ),
          const SizedBox(height: 20),
          Text('الأوسمة ($unlockedCount من ${_badges.length})',
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final b in _badges)
            _Line(
              title: b.title,
              sub: b.desc,
              done: b.test(s),
              icon: Icons.emoji_events,
            ),
          const SizedBox(height: 12),
          const Text(
              'النقاط: الحفظ الجديد 20، السرد غيبًا 15، المراجعة 10، القراءة 10',
              style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class _Line extends StatelessWidget {
  final String title, sub;
  final bool done;
  final IconData icon;
  const _Line(
      {required this.title,
      required this.sub,
      required this.done,
      required this.icon});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: done ? kGreen : kBorder),
        ),
        child: Row(children: [
          Icon(done ? icon : Icons.lock_outline,
              color: done ? kGold : Colors.black26, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: done ? kGreen : Colors.black54)),
              Text(sub, style: const TextStyle(color: Colors.black54)),
            ]),
          ),
        ]),
      );
}
