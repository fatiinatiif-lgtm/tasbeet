// lib/features/qiyam/qiyam_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../../data/quran/surah_data.dart';
import '../wird/wird_provider.dart';

/// ختمة القيام: يختار المستخدم ما يشاء من الأجزاء أو من السور كلها
class QiyamScreen extends ConsumerStatefulWidget {
  const QiyamScreen({super.key});

  @override
  ConsumerState<QiyamScreen> createState() => _QiyamScreenState();
}

class _QiyamScreenState extends ConsumerState<QiyamScreen> {
  int _tab = 0; // 0 أجزاء، 1 سور

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(wirdProvider);
    final colors = kSectionGradients[Section.qiyam.index];
    final accent = kGold;
    final n = ref.read(wirdProvider.notifier);
    final q = s.userEntries.where((e) => e.section == Section.qiyam);
    final juzCount = q.where((e) => e.type == UnitType.juz).length;
    final surahCount = q.where((e) => e.type == UnitType.surah).length;
    final total = juzCount + surahCount;
    final type = _tab == 0 ? UnitType.juz : UnitType.surah;
    final tabCount = _tab == 0 ? juzCount : surahCount;

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'ختمة القيام',
          subtitle: 'اختر الأجزاء أو السور التي تريد قراءتها في قيام الليل',
          colors: colors,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: cardDeco(radius: 18, border: kGold.withAlpha(120)),
                child: Row(children: [
                  Icon(Icons.nightlight_round, color: kGold, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      total == 0
                          ? 'لم تختر شيئًا بعدُ. المختار يظهر في وردك اليومي.'
                          : 'اخترتَ $juzCount من 30 جزءًا و$surahCount من 114 سورة، وتظهر في وردك اليومي.',
                      style: TextStyle(
                          color: kInk, fontWeight: FontWeight.w700, height: 1.6),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: ChoiceChip(
                    label: const Center(child: Text('الأجزاء')),
                    selected: _tab == 0,
                    selectedColor: kGold.withAlpha(50),
                    onSelected: (_) => setState(() => _tab = 0),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ChoiceChip(
                    label: const Center(child: Text('السور')),
                    selected: _tab == 1,
                    selectedColor: kGold.withAlpha(50),
                    onSelected: (_) => setState(() => _tab = 1),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => n.setQiyamType(type, true),
                    icon: const Icon(Icons.done_all_rounded),
                    label: const Text('اختيار الكل'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed:
                        tabCount == 0 ? null : () => n.setQiyamType(type, false),
                    icon: const Icon(Icons.remove_done_rounded),
                    label: const Text('مسح الاختيار'),
                  ),
                ),
              ]),
              const SizedBox(height: 18),
              SectionTitle(_tab == 0 ? 'الأجزاء' : 'السور'),
              const SizedBox(height: 12),
              if (_tab == 0)
                GridView.count(
                  crossAxisCount: 3,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.35,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (var j = 1; j <= 30; j++)
                      _JuzCell(
                        number: j,
                        selected: s.isSelected(
                            WirdEntry(Section.qiyam, UnitType.juz, j)),
                        accent: accent,
                        onTap: () => n.toggleSelect(
                            WirdEntry(Section.qiyam, UnitType.juz, j)),
                      ),
                  ],
                )
              else
                for (final sr in allSurahs)
                  _SurahRow(
                    surah: sr,
                    selected: s.isSelected(
                        WirdEntry(Section.qiyam, UnitType.surah, sr.number)),
                    accent: accent,
                    onTap: () => n.toggleSelect(
                        WirdEntry(Section.qiyam, UnitType.surah, sr.number)),
                  ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _SurahRow extends StatelessWidget {
  final Surah surah;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;
  const _SurahRow(
      {required this.surah,
      required this.selected,
      required this.accent,
      required this.onTap});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: selected ? accent.withAlpha(24) : kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: selected ? accent : kBorder,
                  width: selected ? 1.6 : 1),
            ),
            child: Row(children: [
              NumBadge(
                  text: '${surah.number}',
                  size: 42,
                  active: selected,
                  color: accent),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('سورة ${surah.name}',
                          style: TextStyle(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w800,
                              color: selected ? accent : kInk)),
                      Text('${surah.ayahCount} آية',
                          style: TextStyle(color: kMuted, fontSize: 12.5)),
                    ]),
              ),
              CheckDot(on: selected, color: accent),
            ]),
          ),
        ),
      );
}

class _JuzCell extends StatelessWidget {
  final int number;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;
  const _JuzCell(
      {required this.number,
      required this.selected,
      required this.accent,
      required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: selected ? accent.withAlpha(30) : kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: selected ? accent : kBorder, width: selected ? 1.8 : 1),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('الجزء',
                style: TextStyle(fontSize: 12, color: kMuted)),
            Text('$number',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: selected ? accent : kInk)),
          ]),
        ),
      );
}
