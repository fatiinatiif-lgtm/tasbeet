// lib/features/qiyam/qiyam_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

/// ختمة القيام: يختار المستخدم ما يشاء من الأجزاء الثلاثين فقط
class QiyamScreen extends ConsumerWidget {
  const QiyamScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final colors = kSectionGradients[Section.qiyam.index];
    final accent = kGold;
    final n = ref.read(wirdProvider.notifier);
    final count = s.countIn(Section.qiyam);

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'ختمة القيام',
          subtitle: 'اختر الأجزاء التي تريد قراءتها في قيام الليل',
          colors: colors,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: cardDeco(radius: 18, border: kGold.withAlpha(120)),
                child: Row(children: [
                  Icon(Icons.nightlight_round, color: kGold, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      count == 0
                          ? 'لم تختر أجزاءً بعدُ. المختار يظهر في وردك اليومي.'
                          : 'اخترتَ $count من 30 جزءًا، وتظهر في وردك اليومي.',
                      style: TextStyle(
                          color: kInk, fontWeight: FontWeight.w700, height: 1.6),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => n.setAllQiyam(true),
                    icon: const Icon(Icons.done_all_rounded),
                    label: const Text('اختيار الكل'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: count == 0 ? null : () => n.setAllQiyam(false),
                    icon: const Icon(Icons.remove_done_rounded),
                    label: const Text('مسح الاختيار'),
                  ),
                ),
              ]),
              const SizedBox(height: 18),
              const SectionTitle('الأجزاء'),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 3,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.35,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  for (var j = 1; j <= 30; j++)
                    _JuzCell(
                      number: j,
                      selected:
                          s.isSelected(WirdEntry(Section.qiyam, UnitType.juz, j)),
                      accent: accent,
                      onTap: () => n.toggleSelect(
                          WirdEntry(Section.qiyam, UnitType.juz, j)),
                    ),
                ],
              ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _JuzCell extends StatelessWidget {
  final int number;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;
  const _JuzCell(
      {required this.number,
      required this.selected,
      required this.accent,
      required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: selected ? accent.withAlpha(30) : kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: selected ? accent : kBorder, width: selected ? 1.8 : 1),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('الجزء',
                style: TextStyle(fontSize: 12, color: kMuted)),
            Text('$number',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: selected ? accent : kInk)),
          ]),
        ),
      );
}
