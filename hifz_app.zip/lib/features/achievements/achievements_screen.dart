// lib/features/achievements/achievements_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../profile/profile_provider.dart';
import 'achievements_provider.dart';

const _green = Color(0xFF0F5C4D);

// (عدد الأوجه، اللقب)
const _ladder = [
  (1, 'مُرتّل'),
  (20, 'حافظ جزء'),
  (100, 'حافظ خمسة أجزاء'),
  (300, 'حافظ نصف'),
  (600, 'مُتقن'),
];

class AchievementsScreen extends ConsumerWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(profileProvider);
    final unlocked = ref.watch(achievementsProvider);

    final next = _ladder.where((e) => e.$1 > p.totalPagesMemorized).firstOrNull;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('إنجازاتي',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _green,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('لقبك: ${p.title}',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              if (next != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: (p.totalPagesMemorized / next.$1).clamp(0.0, 1.0),
                    minHeight: 8,
                    color: Colors.white,
                    backgroundColor: Colors.white24,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                    'اللقب الجاي: ${next.$2} (باقي ${next.$1 - p.totalPagesMemorized} وجه)',
                    style: const TextStyle(color: Colors.white70)),
              ] else
                const Text('وصلتي لأعلى لقب',
                    style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 20),
          Text('${unlocked.length} من ${achievementDefs.length} إنجاز',
              style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 8),
          for (final d in achievementDefs)
            _AchievementTile(def: d, unlockedAt: unlocked[d.id]),
        ],
      ),
    );
  }
}

class _AchievementTile extends StatelessWidget {
  final AchievementDef def;
  final String? unlockedAt;
  const _AchievementTile({required this.def, this.unlockedAt});

  @override
  Widget build(BuildContext context) {
    final done = unlockedAt != null;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: done ? _green : const Color(0xFFD9E4E1)),
      ),
      child: Row(children: [
        Icon(done ? Icons.emoji_events : Icons.lock_outline,
            color: done ? const Color(0xFFC98A12) : Colors.black26, size: 30),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(def.title,
                style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: done ? _green : Colors.black54)),
            Text(def.description,
                style: const TextStyle(color: Colors.black54)),
          ]),
        ),
        Text('+${def.xp}', style: TextStyle(color: done ? _green : Colors.black38)),
      ]),
    );
  }
}
