// lib/features/achievements/achievements_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/storage.dart';
import '../profile/profile_provider.dart';

class Stats {
  final int ayahs;
  final int completedSurahs;
  final int reviews;
  final int streak;
  const Stats(this.ayahs, this.completedSurahs, this.reviews, this.streak);
}

class AchievementDef {
  final String id;
  final String title;
  final String description;
  final int xp;
  final bool Function(Stats) test;
  const AchievementDef(this.id, this.title, this.description, this.xp, this.test);
}

final achievementDefs = <AchievementDef>[
  AchievementDef('first_ayah', 'البداية', 'سجّلي أول حفظ', 10,
      (s) => s.ayahs >= 1),
  AchievementDef('first_surah', 'أول سورة', 'أتمّي حفظ سورة كاملة', 50,
      (s) => s.completedSurahs >= 1),
  AchievementDef('ayahs_100', '100 آية', 'احفظي 100 آية', 80,
      (s) => s.ayahs >= 100),
  AchievementDef('juz', 'حافظ جزء', 'احفظي ما يعادل جزءاً (200 آية)', 150,
      (s) => s.ayahs >= 200),
  AchievementDef('surahs_5', 'خمس سور', 'أتمّي حفظ 5 سور', 100,
      (s) => s.completedSurahs >= 5),
  AchievementDef('review_10', 'مراجِعة', 'أتمّي 10 مراجعات', 30,
      (s) => s.reviews >= 10),
  AchievementDef('review_100', '100 مراجعة', 'أتمّي 100 مراجعة', 150,
      (s) => s.reviews >= 100),
  AchievementDef('streak_3', 'ثلاثة أيام', '3 أيام متتالية', 30,
      (s) => s.streak >= 3),
  AchievementDef('streak_7', 'أسبوع متواصل', '7 أيام متتالية', 70,
      (s) => s.streak >= 7),
  AchievementDef('streak_30', 'وسام الثبات', '30 يوماً متتالياً', 300,
      (s) => s.streak >= 30),
];

/// id ← تاريخ فتح الإنجاز
class AchievementsNotifier extends Notifier<Map<String, String>> {
  static const _key = 'achievements';

  @override
  Map<String, String> build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return {};
    return Map<String, String>.from(jsonDecode(raw) as Map);
  }

  /// يفحص كل الإنجازات ويرجّع الجديد منها
  Future<List<AchievementDef>> evaluate() async {
    final items = await ref.read(memorizationRepoProvider).getAll();
    final profile = ref.read(profileProvider);
    final stats = Stats(
      memorizedAyahCount(items),
      completedSurahCount(items),
      profile.totalReviews,
      profile.currentStreak,
    );

    final unlocked = Map<String, String>.from(state);
    final fresh = <AchievementDef>[];
    for (final d in achievementDefs) {
      if (!unlocked.containsKey(d.id) && d.test(stats)) {
        unlocked[d.id] = DateTime.now().toIso8601String();
        fresh.add(d);
      }
    }
    if (fresh.isNotEmpty) {
      state = unlocked;
      await ref.read(sharedPrefsProvider).setString(_key, jsonEncode(unlocked));
      for (final d in fresh) {
        ref.read(profileProvider.notifier).addBonusXp(d.xp);
      }
    }
    return fresh;
  }
}

final achievementsProvider =
    NotifierProvider<AchievementsNotifier, Map<String, String>>(
        AchievementsNotifier.new);
