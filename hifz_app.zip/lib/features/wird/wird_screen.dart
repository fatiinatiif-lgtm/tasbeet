// lib/features/wird/wird_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/models/wird_models.dart';
import 'wird_provider.dart';

class WirdScreen extends ConsumerWidget {
  const WirdScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الورد اليومي من القرآن الكريم'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: s.entries.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(28),
                child: Text(
                  'لسه ما اخترتيش حاجة.\nادخلي أي قسم من الشاشة الرئيسية واختاري السور أو الأحزاب أو الأرباع.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 17, height: 1.6),
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('خلّصتي ${s.doneToday} من ${s.entries.length} النهاردة',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: s.doneToday / s.entries.length,
                    minHeight: 8,
                    color: kGreen,
                    backgroundColor: kBorder,
                  ),
                ),
                for (final sec in Section.values)
                  if (s.countIn(sec) > 0) ...[
                    Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 8),
                      child: Row(children: [
                        Icon(sec.icon, color: kGreen, size: 22),
                        const SizedBox(width: 8),
                        Text(sec.label,
                            style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: kGreen)),
                      ]),
                    ),
                    for (final e in s.entries.where((x) => x.section == sec))
                      _Row(entry: e, done: s.isDoneToday(e)),
                  ],
              ],
            ),
    );
  }
}

class _Row extends ConsumerWidget {
  final WirdEntry entry;
  final bool done;
  const _Row({required this.entry, required this.done});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return InkWell(
      onTap: () => ref.read(wirdProvider.notifier).toggleDone(entry),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: done ? const Color(0xFFDDEEE9) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: done ? kGreen : kBorder),
        ),
        child: Row(children: [
          Icon(done ? Icons.check_circle : Icons.radio_button_unchecked,
              color: done ? kGreen : Colors.black38, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Text(entry.fullName,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: done ? kGreen : kInk)),
          ),
        ]),
      ),
    );
  }
}
