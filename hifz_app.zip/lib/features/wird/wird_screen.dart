// lib/features/wird/wird_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/celebration.dart';
import '../../core/reminders.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import 'wird_provider.dart';

class WirdScreen extends ConsumerWidget {
  const WirdScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(wirdProvider);
    final total = s.entries.length;
    final allDone = total > 0 && s.doneToday >= total;

    return Scaffold(
      body: Column(children: [
        ScreenHeader(
          title: 'وردك اليومي',
          subtitle: 'من القرآن الكريم',
          bottom: total == 0
              ? null
              : Column(children: [
                  Row(children: [
                    Text('أنجزتَ ${s.doneToday} من $total اليوم',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w700)),
                    const Spacer(),
                    Text('${(s.doneToday * 100 / total).round()}%',
                        style: TextStyle(
                            color: kGoldLight,
                            fontSize: 15,
                            fontWeight: FontWeight.w800)),
                  ]),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: s.doneToday / total,
                      minHeight: 10,
                      color: kGold,
                      backgroundColor: Colors.white24,
                    ),
                  ),
                ]),
        ),
        Expanded(
          child: total == 0
              ? const _Empty()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                  children: [
                    if (allDone) const _DoneBanner(),
                    for (final sec in Section.values)
                      if (s.countIn(sec) > 0) ...[
                        Padding(
                          padding: const EdgeInsets.only(top: 12, bottom: 10),
                          child: Row(children: [
                            Container(
                              padding: const EdgeInsets.all(7),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                    colors: kSectionGradients[sec.index]),
                              ),
                              child: Icon(sec.icon,
                                  color: Colors.white, size: 18),
                            ),
                            const SizedBox(width: 10),
                            Text(sec.label,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w800,
                                    color: kInk)),
                          ]),
                        ),
                        for (final e
                            in s.entries.where((x) => x.section == sec))
                          _Row(
                            entry: e,
                            done: s.isDoneToday(e),
                            accent: kSectionGradients[sec.index][0],
                          ),
                      ],
                  ],
                ),
        ),
      ]),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kGreen.withAlpha(18),
                border: Border.all(color: kGold.withAlpha(140), width: 1.5),
              ),
              child: Icon(Icons.menu_book_rounded,
                  size: 54, color: kGreen),
            ),
            const SizedBox(height: 22),
            Text('لم تختر وردك بعدُ',
                style: TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w800, color: kInk)),
            const SizedBox(height: 8),
            Text(
              'ادخل إلى أي قسم من الشاشة الرئيسية، ثم اختر السور أو الأحزاب أو الأرباع التي تريدها.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15.5, height: 1.7, color: kMuted),
            ),
            const SizedBox(height: 20),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: kGreen,
                padding:
                    const EdgeInsets.symmetric(horizontal: 26, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => Navigator.of(context).maybePop(),
              child: const Text('اختيار الورد'),
            ),
          ]),
        ),
      );
}

class _DoneBanner extends StatelessWidget {
  const _DoneBanner();

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [kGold, kGoldDark]),
          borderRadius: BorderRadius.circular(18),
          boxShadow: softShadow(0.12),
        ),
        child: const Row(children: [
          Icon(Icons.celebration_rounded, color: Colors.white, size: 30),
          SizedBox(width: 12),
          Expanded(
            child: Text('تقبّل الله منك، لقد أتممتَ وردك اليوم',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800)),
          ),
        ]),
      );
}

class _Row extends ConsumerWidget {
  final WirdEntry entry;
  final bool done;
  final Color accent;
  const _Row({required this.entry, required this.done, required this.accent});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: () {
          ref.read(wirdProvider.notifier).toggleDone(entry);
          if (!done) showCelebration(context, entry.fullName);
        },
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: done ? accent.withAlpha(22) : kCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
                color: done ? accent : kBorder, width: done ? 1.6 : 1),
            boxShadow: done ? null : softShadow(0.05),
          ),
          child: Row(children: [
            NumBadge(
                text: entry.badgeText,
                active: done,
                color: accent,
                size: 42),
            const SizedBox(width: 14),
            Expanded(
              child: Text(entry.fullName,
                  style: TextStyle(
                      fontSize: 16.5,
                      fontWeight: FontWeight.w700,
                      decoration: done ? TextDecoration.lineThrough : null,
                      decorationColor: accent,
                      color: done ? accent : kInk)),
            ),
            _BellChip(entry: entry, accent: accent),
            const SizedBox(width: 8),
            CheckDot(on: done, color: accent, size: 30),
          ]),
        ),
      ),
    );
  }
}


/// زر التذكير على كل عنصر: يعرض وقته، ويفتح نافذة لتغييره أو إيقافه
class _BellChip extends ConsumerWidget {
  final WirdEntry entry;
  final Color accent;
  const _BellChip({required this.entry, required this.accent});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cfg = ref.watch(remindersProvider);
    final m = cfg.minutesFor(entry);
    final off = !cfg.enabled || m == kReminderOff;
    return InkWell(
      onTap: () => _edit(context, ref, cfg),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: (off ? kFaint : accent).withAlpha(off ? 30 : 24),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(off ? Icons.notifications_off_outlined : Icons.notifications_active_rounded,
              size: 17, color: off ? kMuted : accent),
          if (!off)
            Text(fmtMinutes(m),
                style: TextStyle(
                    fontSize: 10.5, fontWeight: FontWeight.w800, color: accent)),
        ]),
      ),
    );
  }

  Future<void> _edit(BuildContext context, WidgetRef ref, ReminderConfig cfg) async {
    final notifier = ref.read(remindersProvider.notifier);
    final current = cfg.minutesFor(entry);
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: kCard,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('تذكير: ${entry.fullName}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800, color: kInk)),
              const SizedBox(height: 4),
              Text(
                  current == kReminderOff
                      ? 'التذكير متوقف لهذا العنصر'
                      : 'يصلك التذكير يوميًا الساعة ${fmtMinutes(current)}',
                  style: TextStyle(color: kMuted)),
              const SizedBox(height: 14),
              ListTile(
                leading: Icon(Icons.access_time_rounded, color: kGreen),
                title: const Text('تغيير وقت التذكير'),
                onTap: () => Navigator.pop(ctx, 'time'),
              ),
              if (cfg.hasOverride(entry))
                ListTile(
                  leading: Icon(Icons.restart_alt_rounded, color: kGreen),
                  title: Text(
                      'الرجوع لوقت القسم (${fmtMinutes(cfg.sectionMinutes(entry.section))})'),
                  onTap: () => Navigator.pop(ctx, 'reset'),
                ),
              if (current != kReminderOff)
                ListTile(
                  leading: Icon(Icons.notifications_off_outlined,
                      color: Colors.red[700]),
                  title: const Text('إيقاف تذكير هذا العنصر'),
                  onTap: () => Navigator.pop(ctx, 'off'),
                ),
            ]),
          ),
        ),
      ),
    );
    if (choice == null || !context.mounted) return;
    if (choice == 'reset') notifier.setItem(entry, null);
    if (choice == 'off') notifier.setItem(entry, kReminderOff);
    if (choice == 'time') {
      final init = current == kReminderOff
          ? cfg.sectionMinutes(entry.section)
          : current;
      final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: init ~/ 60, minute: init % 60),
      );
      if (t != null) notifier.setItem(entry, t.hour * 60 + t.minute);
    }
  }
}
