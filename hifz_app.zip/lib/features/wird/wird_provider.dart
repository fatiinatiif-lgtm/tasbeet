// lib/features/wird/wird_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/wird_models.dart';

/// يتم تمريره في main.dart
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('override in main'),
);

/// الألقاب حسب النقاط
const titleLadder = <(int, String)>[
  (0, 'مبتدئ'),
  (100, 'مجتهد'),
  (300, 'مواظب'),
  (700, 'مُرتّل'),
  (1500, 'مُتقن'),
  (3000, 'سابق بالخيرات'),
];

String titleForXp(int xp) {
  var t = titleLadder.first.$2;
  for (final e in titleLadder) {
    if (xp >= e.$1) t = e.$2;
  }
  return t;
}

class WirdState {
  final List<WirdEntry> entries; // الورد اليومي (المختار)
  final List<CompletionLog> logs; // كل مرة اتم فيها إنجاز مهمة
  const WirdState(this.entries, this.logs);

  bool isSelected(WirdEntry e) => entries.any((x) => x.key == e.key);

  bool isDoneToday(WirdEntry e) {
    final today = todayString();
    return logs.any((l) => l.entry.key == e.key && l.date == today);
  }

  int countIn(Section s) => entries.where((e) => e.section == s).length;

  int get doneToday => entries.where(isDoneToday).length;
  int get totalCompleted => logs.length;
  int get xp => logs.fold(0, (sum, l) => sum + l.entry.section.xp);

  int completedIn(Section s) =>
      logs.where((l) => l.entry.section == s).length;

  int get streak {
    final days = logs.map((l) => l.date).toSet();
    final n = DateTime.now();
    String d(int back) =>
        dayString(DateTime.utc(n.year, n.month, n.day - back));
    final start = days.contains(d(0)) ? 0 : (days.contains(d(1)) ? 1 : -1);
    if (start < 0) return 0;
    var c = 0;
    while (days.contains(d(start + c))) {
      c++;
    }
    return c;
  }

  /// عدد السور المختلفة اللي اتقرأت في القراءة اليومية
  int get readSurahsDistinct => logs
      .where((l) =>
          l.entry.section == Section.reading &&
          l.entry.type == UnitType.surah)
      .map((l) => l.entry.number)
      .toSet()
      .length;
}

class WirdNotifier extends Notifier<WirdState> {
  static const _key = 'wird_v1';

  @override
  WirdState build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return const WirdState([], []);
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      return WirdState(
        (j['entries'] as List)
            .map((e) => WirdEntry.fromJson(e as Map<String, dynamic>))
            .toList(),
        (j['logs'] as List)
            .map((e) => CompletionLog.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
    } catch (_) {
      return const WirdState([], []);
    }
  }

  void _save(WirdState s) {
    state = s;
    ref.read(sharedPrefsProvider).setString(
          _key,
          jsonEncode({
            'entries': s.entries.map((e) => e.toJson()).toList(),
            'logs': s.logs.map((l) => l.toJson()).toList(),
          }),
        );
  }

  /// اختيار / إلغاء اختيار عنصر في قسم
  void toggleSelect(WirdEntry e) {
    final list = [...state.entries];
    final i = list.indexWhere((x) => x.key == e.key);
    if (i >= 0) {
      list.removeAt(i);
    } else {
      list.add(e);
    }
    _save(WirdState(list, state.logs));
  }

  /// تسجيل إنجاز مهمة اليوم (أو التراجع عنه)
  void toggleDone(WirdEntry e) {
    final today = todayString();
    final logs = [...state.logs];
    final i = logs.indexWhere((l) => l.entry.key == e.key && l.date == today);
    if (i >= 0) {
      logs.removeAt(i);
    } else {
      logs.add(CompletionLog(e, today));
    }
    _save(WirdState(state.entries, logs));
  }
}

final wirdProvider =
    NotifierProvider<WirdNotifier, WirdState>(WirdNotifier.new);
