// lib/features/wird/wird_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/wird_models.dart';

/// يتم تمريره في main.dart
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('override in main'),
);

/// الألقاب حسب النقاط
const titleLadder = <(int, String)>[
  (0, 'مبتدئ'),
  (100, 'مجتهد'),
  (300, 'مواظب'),
  (700, 'مُرتّل'),
  (1500, 'مُتقن'),
  (3000, 'سابق بالخيرات'),
];

String titleForXp(int xp) {
  var t = titleLadder.first.$2;
  for (final e in titleLadder) {
    if (xp >= e.$1) t = e.$2;
  }
  return t;
}

/// خطة الختمة: توزَّع أجزاء القرآن الثلاثون على عدد من الأيام
class KhatmaPlan {
  final int days; // عدد أيام الختمة
  final int done; // عدد الأيام المنجزة
  final String? lastDone; // تاريخ آخر يوم أُنجز
  const KhatmaPlan(this.days, this.done, this.lastDone);

  bool get doneToday => lastDone == todayString();
  bool get finished => done >= days;

  /// رقم ورد اليوم (يبدأ من 1)
  int get activeIndex => doneToday ? done : done + 1;

  /// هل يوجد ورد للختمة اليوم؟
  bool get hasActive => !(finished && !doneToday);

  /// الأجزاء (من، إلى) في اليوم رقم i
  static (int, int) range(int days, int i) =>
      ((i - 1) * 30 ~/ days + 1, i * 30 ~/ days);

  WirdEntry? get entry {
    if (!hasActive) return null;
    final r = range(days, activeIndex);
    return WirdEntry(Section.reading, UnitType.khatma, r.$1 * 100 + r.$2);
  }

  Map<String, dynamic> toJson() => {'d': days, 'n': done, 'l': lastDone};

  factory KhatmaPlan.fromJson(Map<String, dynamic> j) =>
      KhatmaPlan(j['d'] as int, j['n'] as int, j['l'] as String?);
}

class WirdState {
  final List<WirdEntry> userEntries; // ما اختاره المستخدم
  final List<CompletionLog> logs; // كل مرة اتم فيها إنجاز مهمة
  final KhatmaPlan? khatma;
  const WirdState(this.userEntries, this.logs, [this.khatma]);

  /// الورد اليومي = المختار + ورد ختمتي لهذا اليوم
  List<WirdEntry> get entries {
    final k = khatma?.entry;
    return [...userEntries, if (k != null) k];
  }

  bool isSelected(WirdEntry e) => userEntries.any((x) => x.key == e.key);

  bool isDoneToday(WirdEntry e) {
    final today = todayString();
    return logs.any((l) => l.entry.key == e.key && l.date == today);
  }

  int countIn(Section s) => entries.where((e) => e.section == s).length;

  int get doneToday => entries.where(isDoneToday).length;
  int get totalCompleted => logs.length;
  int get xp => logs.fold(0, (sum, l) => sum + l.entry.section.xp);

  int completedIn(Section s) =>
      logs.where((l) => l.entry.section == s).length;

  // ---------- إحصائيات متقدمة ----------

  /// بداية الأسبوع (السبت)
  static DateTime weekStartOf(DateTime d) =>
      DateTime(d.year, d.month, d.day - ((d.weekday + 1) % 7));

  int countOnDate(String d) => logs.where((l) => l.date == d).length;

  /// عدد المهام المنجزة في [from, to)
  int countBetween(DateTime from, DateTime to) {
    final a = dayString(from), b = dayString(to);
    return logs
        .where((l) => l.date.compareTo(a) >= 0 && l.date.compareTo(b) < 0)
        .length;
  }

  int get weekDone {
    final ws = weekStartOf(DateTime.now());
    return countBetween(ws, DateTime(ws.year, ws.month, ws.day + 7));
  }

  int get monthDone {
    final n = DateTime.now();
    return countBetween(DateTime(n.year, n.month, 1),
        DateTime(n.year, n.month + 1, 1));
  }

  int get activeDays => logs.map((l) => l.date).toSet().length;

  /// أطول سلسلة أيام متتالية في تاريخك
  int get bestStreak {
    final days = logs.map((l) => l.date).toSet().toList()..sort();
    var best = 0, run = 0;
    DateTime? prev;
    for (final d in days) {
      final p = DateTime.parse(d);
      final cur = DateTime.utc(p.year, p.month, p.day);
      run = (prev != null && cur.difference(prev).inDays == 1) ? run + 1 : 1;
      if (run > best) best = run;
      prev = cur;
    }
    return best;
  }

  /// أكثر عدد مهام أُنجزت في أسبوع واحد
  int get bestWeek {
    final m = <String, int>{};
    for (final l in logs) {
      final k = dayString(weekStartOf(DateTime.parse(l.date)));
      m[k] = (m[k] ?? 0) + 1;
    }
    return m.values.fold(0, (a, b) => b > a ? b : a);
  }

  /// أنشط يوم في الأسبوع (1=الإثنين .. 7=الأحد)، أو null
  int? get bestWeekday {
    if (logs.isEmpty) return null;
    final c = List.filled(8, 0);
    for (final l in logs) {
      c[DateTime.parse(l.date).weekday]++;
    }
    var b = 1;
    for (var i = 2; i <= 7; i++) {
      if (c[i] > c[b]) b = i;
    }
    return b;
  }

  /// عدد أجزاء ختمة القيام المختلفة التي أُنجزت
  int get qiyamJuzDone => logs
      .where((l) => l.entry.section == Section.qiyam)
      .map((l) => l.entry.number)
      .toSet()
      .length;

  int get streak {
    final days = logs.map((l) => l.date).toSet();
    final n = DateTime.now();
    String d(int back) =>
        dayString(DateTime.utc(n.year, n.month, n.day - back));
    final start = days.contains(d(0)) ? 0 : (days.contains(d(1)) ? 1 : -1);
    if (start < 0) return 0;
    var c = 0;
    while (days.contains(d(start + c))) {
      c++;
    }
    return c;
  }

  /// عدد الأجزاء المختلفة التي قُرئت ضمن ختمتي
  int get juzCovered {
    final set = <int>{};
    for (final l in logs) {
      if (l.entry.type != UnitType.khatma) continue;
      final a = l.entry.number ~/ 100, b = l.entry.number % 100;
      for (var j = a; j <= b; j++) {
        set.add(j);
      }
    }
    return set.length;
  }
}

class WirdNotifier extends Notifier<WirdState> {
  static const _key = 'wird_v1';

  @override
  WirdState build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return const WirdState([], []);
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      final k = j['khatma'];
      return WirdState(
        (j['entries'] as List)
            .map((e) => WirdEntry.fromJson(e as Map<String, dynamic>))
            // القراءة اليومية القديمة استُبدلت بـ «ختمتي»
            .where((e) => e.section != Section.reading)
            .toList(),
        (j['logs'] as List)
            .map((e) => CompletionLog.fromJson(e as Map<String, dynamic>))
            .toList(),
        k == null ? null : KhatmaPlan.fromJson(k as Map<String, dynamic>),
      );
    } catch (_) {
      return const WirdState([], []);
    }
  }

  void _save(WirdState s) {
    state = s;
    ref.read(sharedPrefsProvider).setString(
          _key,
          jsonEncode({
            'entries': s.userEntries.map((e) => e.toJson()).toList(),
            'logs': s.logs.map((l) => l.toJson()).toList(),
            'khatma': s.khatma?.toJson(),
          }),
        );
  }

  /// اختيار / إلغاء اختيار عنصر في قسم
  void toggleSelect(WirdEntry e) {
    final list = [...state.userEntries];
    final i = list.indexWhere((x) => x.key == e.key);
    if (i >= 0) {
      list.removeAt(i);
    } else {
      list.add(e);
    }
    if (e.section == Section.qiyam) {
      final q = list.where((x) => x.section == Section.qiyam).toList()
        ..sort((a, b) => a.number.compareTo(b.number));
      list
        ..removeWhere((x) => x.section == Section.qiyam)
        ..addAll(q);
    }
    _save(WirdState(list, state.logs, state.khatma));
  }

  /// بدء ختمة جديدة بعدد أيام معيّن (30 / 15 / 10 / 6 / 3)
  void startKhatma(int days) =>
      _save(WirdState(state.userEntries, state.logs, KhatmaPlan(days, 0, null)));

  void cancelKhatma() => _save(WirdState(state.userEntries, state.logs, null));

  /// اختيار كل الأجزاء الثلاثين لختمة القيام (أو إلغاؤها كلها)
  void setAllQiyam(bool on) {
    final list = state.userEntries.where((e) => e.section != Section.qiyam).toList();
    if (on) {
      for (var j = 1; j <= 30; j++) {
        list.add(WirdEntry(Section.qiyam, UnitType.juz, j));
      }
    }
    _save(WirdState(list, state.logs, state.khatma));
  }

  void clearEntries() => _save(WirdState(const [], state.logs, null));

  void clearLogs() => _save(WirdState(state.userEntries, const [], state.khatma));

  void clearAll() => _save(const WirdState([], [], null));

  /// تسجيل إنجاز مهمة اليوم (أو التراجع عنه)
  void toggleDone(WirdEntry e) {
    final today = todayString();
    final logs = [...state.logs];
    final i = logs.indexWhere((l) => l.entry.key == e.key && l.date == today);
    var k = state.khatma;
    if (i >= 0) {
      logs.removeAt(i);
      if (k != null && e.type == UnitType.khatma && k.doneToday) {
        k = KhatmaPlan(k.days, k.done - 1, null);
      }
    } else {
      logs.add(CompletionLog(e, today));
      if (k != null && e.type == UnitType.khatma && !k.doneToday) {
        k = KhatmaPlan(k.days, k.done + 1, today);
      }
    }
    _save(WirdState(state.userEntries, logs, k));
  }
}

final wirdProvider =
    NotifierProvider<WirdNotifier, WirdState>(WirdNotifier.new);

/// الهدف الأسبوعي (عدد المهام في الأسبوع)
class WeeklyGoalNotifier extends Notifier<int> {
  static const _key = 'weekly_goal_v1';

  @override
  int build() => ref.read(sharedPrefsProvider).getInt(_key) ?? 20;

  void set(int v) {
    state = v;
    ref.read(sharedPrefsProvider).setInt(_key, v);
  }
}

final weeklyGoalProvider =
    NotifierProvider<WeeklyGoalNotifier, int>(WeeklyGoalNotifier.new);
