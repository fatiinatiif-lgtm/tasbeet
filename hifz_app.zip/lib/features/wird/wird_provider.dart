// lib/features/wird/wird_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/wird_models.dart';

/// يتم تمريره في main.dart
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('override in main'),
);

/// الألقاب حسب النقاط
const titleLadder = <(int, String)>[
  (0, 'مبتدئ'),
  (100, 'مجتهد'),
  (300, 'مواظب'),
  (700, 'مُرتّل'),
  (1500, 'مُتقن'),
  (3000, 'سابق بالخيرات'),
];

String titleForXp(int xp) {
  var t = titleLadder.first.$2;
  for (final e in titleLadder) {
    if (xp >= e.$1) t = e.$2;
  }
  return t;
}

/// خطة الختمة: توزَّع أجزاء القرآن الثلاثون على عدد من الأيام
class KhatmaPlan {
  final int days; // عدد أيام الختمة
  final int done; // عدد الأيام المنجزة
  final String? lastDone; // تاريخ آخر يوم أُنجز
  const KhatmaPlan(this.days, this.done, this.lastDone);

  bool get doneToday => lastDone == todayString();
  bool get finished => done >= days;

  /// رقم ورد اليوم (يبدأ من 1)
  int get activeIndex => doneToday ? done : done + 1;

  /// هل يوجد ورد للختمة اليوم؟
  bool get hasActive => !(finished && !doneToday);

  /// الأجزاء (من، إلى) في اليوم رقم i
  static (int, int) range(int days, int i) =>
      ((i - 1) * 30 ~/ days + 1, i * 30 ~/ days);

  WirdEntry? get entry {
    if (!hasActive) return null;
    final r = range(days, activeIndex);
    return WirdEntry(Section.reading, UnitType.khatma, r.$1 * 100 + r.$2);
  }

  Map<String, dynamic> toJson() => {'d': days, 'n': done, 'l': lastDone};

  factory KhatmaPlan.fromJson(Map<String, dynamic> j) =>
      KhatmaPlan(j['d'] as int, j['n'] as int, j['l'] as String?);
}

class WirdState {
  final List<WirdEntry> userEntries; // ما اختاره المستخدم
  final List<CompletionLog> logs; // كل مرة اتم فيها إنجاز مهمة
  final KhatmaPlan? khatma;
  const WirdState(this.userEntries, this.logs, [this.khatma]);

  /// الورد اليومي = المختار + ورد ختمتي لهذا اليوم
  List<WirdEntry> get entries {
    final k = khatma?.entry;
    return [...userEntries, if (k != null) k];
  }

  bool isSelected(WirdEntry e) => userEntries.any((x) => x.key == e.key);

  bool isDoneToday(WirdEntry e) {
    final today = todayString();
    return logs.any((l) => l.entry.key == e.key && l.date == today);
  }

  int countIn(Section s) => entries.where((e) => e.section == s).length;

  int get doneToday => entries.where(isDoneToday).length;
  int get totalCompleted => logs.length;
  int get xp => logs.fold(0, (sum, l) => sum + l.entry.section.xp);

  int completedIn(Section s) =>
      logs.where((l) => l.entry.section == s).length;

  int get streak {
    final days = logs.map((l) => l.date).toSet();
    final n = DateTime.now();
    String d(int back) =>
        dayString(DateTime.utc(n.year, n.month, n.day - back));
    final start = days.contains(d(0)) ? 0 : (days.contains(d(1)) ? 1 : -1);
    if (start < 0) return 0;
    var c = 0;
    while (days.contains(d(start + c))) {
      c++;
    }
    return c;
  }

  /// عدد الأجزاء المختلفة التي قُرئت ضمن ختمتي
  int get juzCovered {
    final set = <int>{};
    for (final l in logs) {
      if (l.entry.type != UnitType.khatma) continue;
      final a = l.entry.number ~/ 100, b = l.entry.number % 100;
      for (var j = a; j <= b; j++) {
        set.add(j);
      }
    }
    return set.length;
  }
}

class WirdNotifier extends Notifier<WirdState> {
  static const _key = 'wird_v1';

  @override
  WirdState build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return const WirdState([], []);
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      final k = j['khatma'];
      return WirdState(
        (j['entries'] as List)
            .map((e) => WirdEntry.fromJson(e as Map<String, dynamic>))
            // القراءة اليومية القديمة استُبدلت بـ «ختمتي»
            .where((e) => e.section != Section.reading)
            .toList(),
        (j['logs'] as List)
            .map((e) => CompletionLog.fromJson(e as Map<String, dynamic>))
            .toList(),
        k == null ? null : KhatmaPlan.fromJson(k as Map<String, dynamic>),
      );
    } catch (_) {
      return const WirdState([], []);
    }
  }

  void _save(WirdState s) {
    state = s;
    ref.read(sharedPrefsProvider).setString(
          _key,
          jsonEncode({
            'entries': s.userEntries.map((e) => e.toJson()).toList(),
            'logs': s.logs.map((l) => l.toJson()).toList(),
            'khatma': s.khatma?.toJson(),
          }),
        );
  }

  /// اختيار / إلغاء اختيار عنصر في قسم
  void toggleSelect(WirdEntry e) {
    final list = [...state.userEntries];
    final i = list.indexWhere((x) => x.key == e.key);
    if (i >= 0) {
      list.removeAt(i);
    } else {
      list.add(e);
    }
    _save(WirdState(list, state.logs, state.khatma));
  }

  /// بدء ختمة جديدة بعدد أيام معيّن (30 / 15 / 10 / 6 / 3)
  void startKhatma(int days) =>
      _save(WirdState(state.userEntries, state.logs, KhatmaPlan(days, 0, null)));

  void cancelKhatma() => _save(WirdState(state.userEntries, state.logs, null));

  void clearEntries() => _save(WirdState(const [], state.logs, null));

  void clearLogs() => _save(WirdState(state.userEntries, const [], state.khatma));

  void clearAll() => _save(const WirdState([], [], null));

  /// تسجيل إنجاز مهمة اليوم (أو التراجع عنه)
  void toggleDone(WirdEntry e) {
    final today = todayString();
    final logs = [...state.logs];
    final i = logs.indexWhere((l) => l.entry.key == e.key && l.date == today);
    var k = state.khatma;
    if (i >= 0) {
      logs.removeAt(i);
      if (k != null && e.type == UnitType.khatma && k.doneToday) {
        k = KhatmaPlan(k.days, k.done - 1, null);
      }
    } else {
      logs.add(CompletionLog(e, today));
      if (k != null && e.type == UnitType.khatma && !k.doneToday) {
        k = KhatmaPlan(k.days, k.done + 1, today);
      }
    }
    _save(WirdState(state.userEntries, logs, k));
  }
}

final wirdProvider =
    NotifierProvider<WirdNotifier, WirdState>(WirdNotifier.new);
