// lib/features/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/reminders.dart';
import '../../core/theme.dart';
import '../../core/theme_provider.dart';
import '../../core/tile_style.dart';
import '../../core/widgets.dart';
import '../../data/models/wird_models.dart';
import '../wird/wird_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<void> _confirm(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onYes,
    required String done,
  }) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: Text(title,
              style: const TextStyle(fontWeight: FontWeight.w800)),
          content: Text(message, style: const TextStyle(height: 1.7)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red[700]),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('نعم، تابع'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) {
      onYes();
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: kGreen,
            content: Text(done),
          ));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final n = ref.read(wirdProvider.notifier);

    return Scaffold(
      body: Column(children: [
        const ScreenHeader(
          showBack: false,
          title: 'الإعدادات',
          subtitle: 'تحكّم في بيانات وردك',
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            children: [
              const SectionTitle('شكل الأقسام'),
              const SizedBox(height: 4),
              Text('اختر طريقة عرض الأقسام في الصفحة الرئيسية',
                  style: TextStyle(color: kMuted, height: 1.6)),
              const SizedBox(height: 12),
              const _TileStylePicker(),
              const SizedBox(height: 24),
              const _ColorsSection(),
              const SizedBox(height: 24),
              const _RemindersSection(),
              const SizedBox(height: 24),
              const SectionTitle('إدارة البيانات'),
              const SizedBox(height: 12),
              _Action(
                icon: Icons.playlist_remove_rounded,
                title: 'إفراغ الورد اليومي',
                sub: 'إلغاء اختيار جميع السور والأحزاب والأرباع وإلغاء ختمتك',
                onTap: () => _confirm(
                  context,
                  title: 'إفراغ الورد اليومي',
                  message: 'سيتم إلغاء اختيار جميع عناصر وردك وإلغاء ختمتك الحالية. هل تريد المتابعة؟',
                  onYes: n.clearEntries,
                  done: 'تم إفراغ وردك اليومي',
                ),
              ),
              _Action(
                icon: Icons.history_toggle_off_rounded,
                title: 'مسح سجل الإنجازات',
                sub: 'حذف إنجازاتك ونقاطك وأيام مواظبتك',
                onTap: () => _confirm(
                  context,
                  title: 'مسح سجل الإنجازات',
                  message:
                      'سيُحذف سجل إنجازاتك ونقاطك نهائيًا، ولا يمكن التراجع عن ذلك. هل تريد المتابعة؟',
                  onYes: n.clearLogs,
                  done: 'تم مسح سجل إنجازاتك',
                ),
              ),
              _Action(
                icon: Icons.delete_forever_rounded,
                title: 'حذف جميع البيانات',
                sub: 'إعادة التطبيق إلى حالته الأولى',
                danger: true,
                onTap: () => _confirm(
                  context,
                  title: 'حذف جميع البيانات',
                  message:
                      'سيُحذف وردك وسجل إنجازاتك بالكامل نهائيًا. هل أنت متأكد من رغبتك في المتابعة؟',
                  onYes: n.clearAll,
                  done: 'تم حذف جميع البيانات',
                ),
              ),
              const SizedBox(height: 22),
              const SectionTitle('عن التطبيق'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: cardDeco(radius: 20, border: kGold.withAlpha(120)),
                child: Column(children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: [kGreen, kGreenDark])),
                      child: Icon(Icons.menu_book_rounded,
                          color: kGoldLight, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('المصطفون',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w800)),
                            Text('تطبيق لمتابعة حفظ القرآن الكريم ومراجعته',
                                style: TextStyle(
                                    color: kMuted, height: 1.5)),
                          ]),
                    ),
                  ]),
                  const Divider(height: 26),
                  Text(
                    '«خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ»',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: kGreen,
                        height: 1.7),
                  ),
                  const SizedBox(height: 4),
                  Text('رواه البخاري',
                      style: TextStyle(color: kMuted, fontSize: 12.5)),
                  const SizedBox(height: 12),
                  Text('الإصدار 1.0.0',
                      style: TextStyle(color: kMuted, fontSize: 12.5)),
                ]),
              ),
              const SizedBox(height: 22),
              const _DeveloperSignature(),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final bool danger;
  final VoidCallback onTap;
  const _Action(
      {required this.icon,
      required this.title,
      required this.sub,
      required this.onTap,
      this.danger = false});

  @override
  Widget build(BuildContext context) {
    final c = danger ? Colors.red[700]! : kGreen;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: cardDeco(radius: 18),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: c.withAlpha(24), shape: BoxShape.circle),
              child: Icon(icon, color: c, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title,
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800, color: c)),
                const SizedBox(height: 2),
                Text(sub,
                    style: TextStyle(color: kMuted, fontSize: 13)),
              ]),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
                size: 15, color: kFaint),
          ]),
        ),
      ),
    );
  }
}


class _ThemePicker extends ConsumerWidget {
  const _ThemePicker();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(themeProvider);
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.75,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        for (var i = 0; i < kPalettes.length; i++)
          _ThemeCard(
            palette: kPalettes[i],
            selected: i == selected,
            onTap: () => ref.read(themeProvider.notifier).select(i),
          ),
      ],
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final AppPalette palette;
  final bool selected;
  final VoidCallback onTap;
  const _ThemeCard(
      {required this.palette, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = [
      palette.primary,
      palette.dark,
      palette.accent,
      palette.mix,
      palette.bg
    ];
    const d = 34.0;
    const step = 20.0;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: selected ? palette.primary : kBorder,
              width: selected ? 2.2 : 1),
          boxShadow: softShadow(0.05),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: d + step * 4,
              height: d,
              child: Stack(children: [
                for (var i = 0; i < colors.length; i++)
                  Positioned(
                    right: i * step,
                    child: Container(
                      width: d,
                      height: d,
                      decoration: BoxDecoration(
                        color: colors[i],
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2.5),
                        boxShadow: softShadow(0.15),
                      ),
                    ),
                  ),
              ]),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: Text(palette.name,
                    style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w800,
                        color: selected ? palette.primary : kInk)),
              ),
              if (selected)
                Icon(Icons.check_circle_rounded,
                    color: palette.primary, size: 20),
            ]),
          ],
        ),
      ),
    );
  }
}


class _DarkModeTile extends ConsumerWidget {
  const _DarkModeTile();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dark = ref.watch(darkProvider);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: cardDeco(radius: 18),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration:
              BoxDecoration(color: kGreen.withAlpha(24), shape: BoxShape.circle),
          child: Icon(dark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
              color: kGreen, size: 24),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الوضع الداكن',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text('راحة للعينين في الإضاءة المنخفضة',
                style: TextStyle(color: kMuted, fontSize: 13)),
          ]),
        ),
        Switch(
          value: dark,
          activeColor: kGreen,
          onChanged: (v) => ref.read(darkProvider.notifier).set(v),
        ),
      ]),
    );
  }
}


class _TileStylePicker extends ConsumerWidget {
  const _TileStylePicker();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(tileStyleProvider);
    return GridView.count(
      crossAxisCount: 3,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 0.92,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        for (final st in TileStyle.values)
          _StyleCard(
            style: st,
            selected: st.index == selected,
            onTap: () => ref.read(tileStyleProvider.notifier).select(st.index),
          ),
      ],
    );
  }
}

class _StyleCard extends StatelessWidget {
  final TileStyle style;
  final bool selected;
  final VoidCallback onTap;
  const _StyleCard(
      {required this.style, required this.selected, required this.onTap});

  Widget _box(double w, double h, Color c, {double r = 5, bool outline = false}) =>
      Container(
        width: w,
        height: h,
        decoration: BoxDecoration(
          color: outline ? kCard : c,
          borderRadius: BorderRadius.circular(r),
          border: outline ? Border.all(color: c, width: 1.6) : null,
        ),
      );

  Widget _preview() {
    final a = kGreen, b = kGold, c = kSectionGradients[1][0];
    switch (style) {
      case TileStyle.classic:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(26, 26, a, r: 7), const SizedBox(width: 5), _box(26, 26, b, r: 7)
          ]),
          const SizedBox(height: 5),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(26, 26, c, r: 7), const SizedBox(width: 5), _box(26, 26, a, r: 7)
          ]),
        ]);
      case TileStyle.list:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          _box(58, 14, a, r: 6),
          const SizedBox(height: 4),
          _box(58, 14, b, r: 6),
          const SizedBox(height: 4),
          _box(58, 14, c, r: 6),
        ]);
      case TileStyle.compact:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(17, 17, a, r: 5), const SizedBox(width: 4),
            _box(17, 17, b, r: 5), const SizedBox(width: 4),
            _box(17, 17, c, r: 5),
          ]),
          const SizedBox(height: 4),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(17, 17, c, r: 5), const SizedBox(width: 4),
            _box(17, 17, a, r: 5), const SizedBox(width: 4),
            _box(17, 17, b, r: 5),
          ]),
        ]);
      case TileStyle.cards:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(26, 26, a, r: 7, outline: true),
            const SizedBox(width: 5),
            _box(26, 26, b, r: 7, outline: true)
          ]),
          const SizedBox(height: 5),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(26, 26, c, r: 7, outline: true),
            const SizedBox(width: 5),
            _box(26, 26, a, r: 7, outline: true)
          ]),
        ]);
      case TileStyle.circles:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(17, 17, a, r: 9), const SizedBox(width: 4),
            _box(17, 17, b, r: 9), const SizedBox(width: 4),
            _box(17, 17, c, r: 9),
          ]),
          const SizedBox(height: 4),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(17, 17, c, r: 9), const SizedBox(width: 4),
            _box(17, 17, a, r: 9), const SizedBox(width: 4),
            _box(17, 17, b, r: 9),
          ]),
        ]);
      case TileStyle.featured:
        return Column(mainAxisSize: MainAxisSize.min, children: [
          _box(58, 22, a, r: 7),
          const SizedBox(height: 5),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _box(26, 20, b, r: 7), const SizedBox(width: 5), _box(26, 20, c, r: 7)
          ]),
        ]);
    }
  }

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
                color: selected ? kGreen : kBorder, width: selected ? 2.2 : 1),
            boxShadow: softShadow(0.05),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(child: Center(child: _preview())),
              const SizedBox(height: 6),
              Text(kTileStyleNames[style]!,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: selected ? kGreen : kInk)),
            ],
          ),
        ),
      );
}


/// قسم «الألوان» القابل للطي: الثيمات + الوضع الداكن
class _ColorsSection extends ConsumerStatefulWidget {
  const _ColorsSection();

  @override
  ConsumerState<_ColorsSection> createState() => _ColorsSectionState();
}

class _ColorsSectionState extends ConsumerState<_ColorsSection> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final sel = ref.watch(themeProvider);
    final dark = ref.watch(darkProvider);
    final p = kPalettes[sel];
    return Container(
      decoration: cardDeco(radius: 20),
      clipBehavior: Clip.antiAlias,
      child: Column(children: [
        InkWell(
          onTap: () => setState(() => _open = !_open),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: kGreen.withAlpha(24), shape: BoxShape.circle),
                child: Icon(Icons.palette_rounded, color: kGreen, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('الألوان',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: kInk)),
                      const SizedBox(height: 2),
                      Text('${p.name}${dark ? ' • داكن' : ''}',
                          style: TextStyle(color: kMuted, fontSize: 13)),
                    ]),
              ),
              for (final c in [p.primary, p.accent])
                Container(
                  width: 18,
                  height: 18,
                  margin: const EdgeInsetsDirectional.only(end: 4),
                  decoration: BoxDecoration(color: c, shape: BoxShape.circle),
                ),
              const SizedBox(width: 6),
              AnimatedRotation(
                turns: _open ? 0.5 : 0,
                duration: const Duration(milliseconds: 200),
                child: Icon(Icons.keyboard_arrow_down_rounded, color: kMuted),
              ),
            ]),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeInOut,
          alignment: Alignment.topCenter,
          child: _open
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Divider(color: kBorder, height: 1),
                        const SizedBox(height: 12),
                        Text('اختر الألوان التي تناسبك',
                            style: TextStyle(color: kMuted, height: 1.6)),
                        const SizedBox(height: 12),
                        const _ThemePicker(),
                        const SizedBox(height: 14),
                        const _DarkModeTile(),
                      ]),
                )
              : const SizedBox(width: double.infinity),
        ),
      ]),
    );
  }
}


/// قسم «التذكيرات»: مفتاح عام + وقت التذكير لكل قسم من أقسام الورد
class _RemindersSection extends ConsumerWidget {
  const _RemindersSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cfg = ref.watch(remindersProvider);
    final n = ref.read(remindersProvider.notifier);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('التذكيرات'),
      const SizedBox(height: 4),
      Text('كل عنصر تضيفه لوردك اليومي يصلك له تذكير، ويمكنك تعديل وقته من شاشة الورد',
          style: TextStyle(color: kMuted, height: 1.6)),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: cardDeco(radius: 18),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: kGreen.withAlpha(24), shape: BoxShape.circle),
            child: Icon(Icons.notifications_active_rounded,
                color: kGreen, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('تذكيرات الورد',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(cfg.enabled ? 'مفعّلة' : 'متوقفة',
                  style: TextStyle(color: kMuted, fontSize: 13)),
            ]),
          ),
          Switch(
              value: cfg.enabled, activeColor: kGreen, onChanged: n.setEnabled),
        ]),
      ),
      if (cfg.enabled) ...[
        const SizedBox(height: 10),
        for (final sec in Section.values)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () async {
                final m = cfg.sectionMinutes(sec);
                final t = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay(hour: m ~/ 60, minute: m % 60),
                );
                if (t != null) n.setSection(sec, t.hour * 60 + t.minute);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: cardDeco(radius: 16),
                child: Row(children: [
                  Icon(sec.icon, color: kGreen, size: 22),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(sec.label,
                        style: const TextStyle(
                            fontSize: 15.5, fontWeight: FontWeight.w700)),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                        color: kGreen.withAlpha(24),
                        borderRadius: BorderRadius.circular(12)),
                    child: Text(fmtMinutes(cfg.sectionMinutes(sec)),
                        style: TextStyle(
                            color: kGreen, fontWeight: FontWeight.w800)),
                  ),
                ]),
              ),
            ),
          ),
      ],
    ]);
  }
}

/// توقيع المطوّر أسفل الإعدادات
class _DeveloperSignature extends StatelessWidget {
  const _DeveloperSignature();

  @override
  Widget build(BuildContext context) {
    Widget line() => Expanded(
        child: Container(height: 1, color: kGold.withAlpha(110)));
    return Column(children: [
      Row(children: [
        line(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Icon(Icons.auto_awesome, size: 16, color: kGold),
        ),
        line(),
      ]),
      const SizedBox(height: 14),
      Text('المطوّر: نور النبي',
          style: TextStyle(
              fontSize: 17, fontWeight: FontWeight.w800, color: kGreen)),
      const SizedBox(height: 4),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Text('Developer: Nour El-Nabi',
            style: TextStyle(
                fontSize: 14,
                letterSpacing: 0.4,
                fontWeight: FontWeight.w600,
                color: kMuted)),
      ),
      const SizedBox(height: 8),
    ]);
  }
}
