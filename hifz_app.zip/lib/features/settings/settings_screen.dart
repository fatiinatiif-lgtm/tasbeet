// lib/features/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../wird/wird_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<void> _confirm(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onYes,
    required String done,
  }) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          title: Text(title,
              style: const TextStyle(fontWeight: FontWeight.w800)),
          content: Text(message, style: const TextStyle(height: 1.7)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red[700]),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('نعم، تابع'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) {
      onYes();
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: kGreen,
            content: Text(done),
          ));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final n = ref.read(wirdProvider.notifier);

    return Scaffold(
      body: Column(children: [
        const ScreenHeader(
          showBack: false,
          title: 'الإعدادات',
          subtitle: 'تحكّم في بيانات وردك',
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            children: [
              const SectionTitle('إدارة البيانات'),
              const SizedBox(height: 12),
              _Action(
                icon: Icons.playlist_remove_rounded,
                title: 'إفراغ الورد اليومي',
                sub: 'إلغاء اختيار جميع السور والأحزاب والأرباع',
                onTap: () => _confirm(
                  context,
                  title: 'إفراغ الورد اليومي',
                  message: 'سيتم إلغاء اختيار جميع عناصر وردك. هل تريد المتابعة؟',
                  onYes: n.clearEntries,
                  done: 'تم إفراغ وردك اليومي',
                ),
              ),
              _Action(
                icon: Icons.history_toggle_off_rounded,
                title: 'مسح سجل الإنجازات',
                sub: 'حذف إنجازاتك ونقاطك وأيام مواظبتك',
                onTap: () => _confirm(
                  context,
                  title: 'مسح سجل الإنجازات',
                  message:
                      'سيُحذف سجل إنجازاتك ونقاطك نهائيًا، ولا يمكن التراجع عن ذلك. هل تريد المتابعة؟',
                  onYes: n.clearLogs,
                  done: 'تم مسح سجل إنجازاتك',
                ),
              ),
              _Action(
                icon: Icons.delete_forever_rounded,
                title: 'حذف جميع البيانات',
                sub: 'إعادة التطبيق إلى حالته الأولى',
                danger: true,
                onTap: () => _confirm(
                  context,
                  title: 'حذف جميع البيانات',
                  message:
                      'سيُحذف وردك وسجل إنجازاتك بالكامل نهائيًا. هل أنت متأكد من رغبتك في المتابعة؟',
                  onYes: n.clearAll,
                  done: 'تم حذف جميع البيانات',
                ),
              ),
              const SizedBox(height: 22),
              const SectionTitle('عن التطبيق'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: cardDeco(radius: 20, border: kGold.withAlpha(120)),
                child: Column(children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: [kGreen, kGreenDark])),
                      child: const Icon(Icons.menu_book_rounded,
                          color: kGoldLight, size: 28),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('حفظ',
                                style: TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.w800)),
                            Text('تطبيق لمتابعة حفظ القرآن الكريم ومراجعته',
                                style: TextStyle(
                                    color: Colors.black54, height: 1.5)),
                          ]),
                    ),
                  ]),
                  const Divider(height: 26),
                  const Text(
                    '«خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ»',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: kGreen,
                        height: 1.7),
                  ),
                  const SizedBox(height: 4),
                  const Text('رواه البخاري',
                      style: TextStyle(color: Colors.black45, fontSize: 12.5)),
                  const SizedBox(height: 12),
                  const Text('الإصدار 1.0.0',
                      style: TextStyle(color: Colors.black45, fontSize: 12.5)),
                ]),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final bool danger;
  final VoidCallback onTap;
  const _Action(
      {required this.icon,
      required this.title,
      required this.sub,
      required this.onTap,
      this.danger = false});

  @override
  Widget build(BuildContext context) {
    final c = danger ? Colors.red[700]! : kGreen;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: cardDeco(radius: 18),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: c.withAlpha(24), shape: BoxShape.circle),
              child: Icon(icon, color: c, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title,
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800, color: c)),
                const SizedBox(height: 2),
                Text(sub,
                    style: const TextStyle(color: Colors.black54, fontSize: 13)),
              ]),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                size: 15, color: Colors.black38),
          ]),
        ),
      ),
    );
  }
}
