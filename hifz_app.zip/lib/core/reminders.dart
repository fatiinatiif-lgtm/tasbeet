// lib/core/reminders.dart
import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../data/models/wird_models.dart';
import '../features/wird/wird_provider.dart';

/// أوقات التذكير الافتراضية لكل قسم (بالدقائق من منتصف الليل)
const kDefaultSectionMinutes = <Section, int>{
  Section.hifz: 7 * 60,
  Section.review: 17 * 60,
  Section.sard: 19 * 60,
  Section.reading: 20 * 60,
  Section.qiyam: 3 * 60,
};

/// قيمة تعني «بدون تذكير» لعنصر معيّن
const kReminderOff = -1;

/// 7:05 ص / 5:30 م
String fmtMinutes(int m) {
  final h = m ~/ 60, min = m % 60;
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '$h12:${min.toString().padLeft(2, '0')} ${h < 12 ? 'ص' : 'م'}';
}

class ReminderConfig {
  final bool enabled;
  final Map<String, int> sections; // section.name -> minutes
  final Map<String, int> items; // entry.key -> minutes (أو -1 = بدون)
  const ReminderConfig(
      {this.enabled = true, this.sections = const {}, this.items = const {}});

  int sectionMinutes(Section s) => sections[s.name] ?? kDefaultSectionMinutes[s]!;

  /// وقت تذكير عنصر (قد يكون -1 = معطّل)
  int minutesFor(WirdEntry e) => items[e.key] ?? sectionMinutes(e.section);

  bool hasOverride(WirdEntry e) => items.containsKey(e.key);

  ReminderConfig copy(
          {bool? enabled, Map<String, int>? sections, Map<String, int>? items}) =>
      ReminderConfig(
          enabled: enabled ?? this.enabled,
          sections: sections ?? this.sections,
          items: items ?? this.items);

  Map<String, dynamic> toJson() =>
      {'on': enabled, 'sec': sections, 'items': items};

  factory ReminderConfig.fromJson(Map<String, dynamic> j) => ReminderConfig(
        enabled: j['on'] as bool? ?? true,
        sections: Map<String, int>.from((j['sec'] as Map?) ?? {}),
        items: Map<String, int>.from((j['items'] as Map?) ?? {}),
      );
}

class ReminderNotifier extends Notifier<ReminderConfig> {
  static const _key = 'reminders_v1';

  @override
  ReminderConfig build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return const ReminderConfig();
    try {
      return ReminderConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return const ReminderConfig();
    }
  }

  void _save(ReminderConfig c) {
    state = c;
    ref.read(sharedPrefsProvider).setString(_key, jsonEncode(c.toJson()));
  }

  void setEnabled(bool v) => _save(state.copy(enabled: v));

  void setSection(Section s, int minutes) =>
      _save(state.copy(sections: {...state.sections, s.name: minutes}));

  /// [minutes] = null يعيد العنصر للوقت الافتراضي لقسمه، و -1 يعطّل تذكيره
  void setItem(WirdEntry e, int? minutes) {
    final m = {...state.items};
    if (minutes == null) {
      m.remove(e.key);
    } else {
      m[e.key] = minutes;
    }
    _save(state.copy(items: m));
  }
}

final remindersProvider =
    NotifierProvider<ReminderNotifier, ReminderConfig>(ReminderNotifier.new);

/// خدمة الإشعارات: تجدول تذكيرات الأيام الـ 14 القادمة، وتُعاد جدولتها
/// عند أي تغيير في الورد أو الإعدادات أو عند فتح التطبيق.
class ReminderService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const _days = 14;

  static Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    await _plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ));
    _ready = true;
  }

  /// يطلب إذن الإشعارات (أندرويد 13+) مرة واحدة فقط
  static Future<void> askPermissionOnce(SharedPreferences prefs) async {
    if (prefs.getBool('notif_asked') ?? false) return;
    await prefs.setBool('notif_asked', true);
    final a = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
  }

  static String _body(List<WirdEntry> list) {
    final names = list.take(3).map((e) => e.fullName).join('، ');
    final more = list.length - 3;
    return more > 0 ? 'حان وقت: $names و$more أخرى' : 'حان وقت: $names';
  }

  static Future<void> sync(WirdState s, ReminderConfig c) async {
    await init();
    await _plugin.cancelAll();
    if (!c.enabled) return;

    // تجميع العناصر: نفس القسم + نفس الوقت = إشعار واحد
    final groups = <String, List<WirdEntry>>{};
    for (final e in s.entries) {
      final m = c.minutesFor(e);
      if (m == kReminderOff) continue;
      groups.putIfAbsent('${e.section.index}:$m', () => []).add(e);
    }

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'wird_reminders',
        'تذكيرات الورد',
        channelDescription: 'تذكير يومي بعناصر وردك',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );

    final now = DateTime.now();
    var gi = 0;
    for (final g in groups.entries) {
      final parts = g.key.split(':');
      final section = Section.values[int.parse(parts[0])];
      final m = int.parse(parts[1]);
      for (var d = 0; d < _days; d++) {
        final at = DateTime(now.year, now.month, now.day + d, m ~/ 60, m % 60);
        if (!at.isAfter(now)) continue;
        var list = g.value;
        if (d == 0) {
          // لا تذكّر بما أُنجز اليوم
          list = list.where((e) => !s.isDoneToday(e)).toList();
          if (list.isEmpty) continue;
        }
        await _plugin.zonedSchedule(
          gi * 20 + d,
          'تذكير بوردك • ${section.label}',
          _body(list),
          tz.TZDateTime.from(at, tz.UTC),
          details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
      gi++;
    }
  }
}
