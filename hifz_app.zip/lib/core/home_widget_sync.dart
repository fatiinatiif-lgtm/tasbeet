// lib/core/home_widget_sync.dart
import 'package:home_widget/home_widget.dart';
import '../features/wird/wird_provider.dart';

/// يرسل ملخص ورد اليوم إلى ويدجت الشاشة الرئيسية (أندرويد)
Future<void> syncHomeWidget(WirdState s) async {
  try {
    var next = '';
    for (final e in s.entries) {
      if (!s.isDoneToday(e)) {
        next = e.fullName;
        break;
      }
    }
    final total = s.entries.length;
    final done = s.doneToday;
    if (total == 0) {
      next = 'اختر وردك من التطبيق';
    } else if (next.isEmpty) {
      next = 'أتممتَ وردك اليوم، تقبّل الله منك';
    }
    await HomeWidget.saveWidgetData<String>('w_progress', '$done / $total');
    await HomeWidget.saveWidgetData<String>('w_next', next);
    await HomeWidget.saveWidgetData<String>(
        'w_streak', s.streak > 0 ? '🔥 ${s.streak} يوم متواصل' : 'ابدأ سلسلتك اليوم');
    await HomeWidget.updateWidget(
        name: 'WirdWidgetProvider', androidName: 'WirdWidgetProvider');
  } catch (_) {
    // الويدجت اختياري، فلا نُظهر خطأً للمستخدم
  }
}
