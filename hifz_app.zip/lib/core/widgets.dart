// lib/core/widgets.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

/// نقش هندسي إسلامي (نجوم ثمانية) يُرسم بخطوط خفيفة
class GeoPatternPainter extends CustomPainter {
  final Color color;
  final double cell;
  const GeoPatternPainter({required this.color, this.cell = 46});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    final r = cell * 0.36;
    var row = 0;
    for (double y = 0; y < size.height + cell; y += cell) {
      final shift = row.isOdd ? cell / 2 : 0.0;
      for (double x = -cell; x < size.width + cell; x += cell) {
        _star(canvas, Offset(x + shift, y), r, p);
      }
      row++;
    }
  }

  void _star(Canvas c, Offset o, double r, Paint p) {
    final path = Path();
    for (var i = 0; i < 16; i++) {
      final rad = i.isEven ? r : r * 0.62;
      final a = math.pi * i / 8 - math.pi / 2;
      final pt = Offset(o.dx + rad * math.cos(a), o.dy + rad * math.sin(a));
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    c.drawPath(path, p);
    c.drawCircle(o, r * 0.22, p);
  }

  @override
  bool shouldRepaint(GeoPatternPainter old) =>
      old.color != color || old.cell != cell;
}

/// خلفية النقش تُوضع خلف محتوى
class PatternLayer extends StatelessWidget {
  final double alpha; // 0..255
  final double cell;
  const PatternLayer({super.key, this.alpha = 22, this.cell = 46});

  @override
  Widget build(BuildContext context) => Positioned.fill(
        child: IgnorePointer(
          child: CustomPaint(
            painter: GeoPatternPainter(
              color: Colors.white.withAlpha(alpha.round()),
              cell: cell,
            ),
          ),
        ),
      );
}

/// ترويسة موحّدة للصفحات الداخلية
class ScreenHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool showBack;
  final Widget? bottom;
  final Widget? trailing;
  final List<Color>? colors;

  const ScreenHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.showBack = true,
    this.bottom,
    this.trailing,
    this.colors,
  });

  @override
  Widget build(BuildContext context) {
    const radius = BorderRadius.vertical(bottom: Radius.circular(30));
    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: softShadow(0.18),
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: colors ?? [kGreen, kGreenDark],
            ),
          ),
          child: Stack(children: [
            const PatternLayer(),
            SafeArea(
              bottom: false,
              minimum: const EdgeInsets.only(top: 14),
              child: Padding(
                padding: EdgeInsets.fromLTRB(showBack ? 6 : 20, 8, 20, 18),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    if (showBack)
                      IconButton(
                        onPressed: () => Navigator.of(context).maybePop(),
                        icon: const Icon(Icons.arrow_back_rounded,
                            color: Colors.white),
                      ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w800)),
                            if (subtitle != null) ...[
                              const SizedBox(height: 3),
                              Text(subtitle!,
                                  style: TextStyle(
                                      color: kGoldLight,
                                      fontSize: 13.5,
                                      height: 1.4)),
                            ],
                          ],
                        ),
                      ),
                    ),
                    if (trailing != null) trailing!,
                  ]),
                  if (bottom != null) ...[
                    const SizedBox(height: 10),
                    bottom!,
                  ],
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

/// رقم داخل نجمة ثمانية (مربعان متداخلان)
class NumBadge extends StatelessWidget {
  final String text;
  final bool active;
  final Color? color;
  final double size;
  const NumBadge(
      {super.key,
      required this.text,
      this.active = false,
      this.color,
      this.size = 46});

  Color get _c => color ?? kGreen;

  Widget _square(double angle) => Transform.rotate(
        angle: angle,
        child: Container(
          width: size * 0.7,
          height: size * 0.7,
          decoration: BoxDecoration(
            color: active ? _c : _c.withAlpha(20),
            border: Border.all(
                color: active ? kGold : _c.withAlpha(90), width: 1.3),
            borderRadius: BorderRadius.circular(6),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: Stack(alignment: Alignment.center, children: [
          _square(0),
          _square(math.pi / 4),
          Text(text,
              style: TextStyle(
                  fontSize: size * 0.28,
                  fontWeight: FontWeight.w800,
                  color: active ? Colors.white : _c)),
        ]),
      );
}

/// عنوان قسم بخط ذهبي قصير
class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Row(children: [
        Container(
          width: 5,
          height: 22,
          decoration: BoxDecoration(
              color: kGold, borderRadius: BorderRadius.circular(3)),
        ),
        const SizedBox(width: 10),
        Text(text,
            style: TextStyle(
                fontSize: 19, fontWeight: FontWeight.w800, color: kInk)),
      ]);
}

/// دائرة إنجاز متحركة
class CheckDot extends StatelessWidget {
  final bool on;
  final Color? color;
  final double size;
  const CheckDot({super.key, required this.on, this.color, this.size = 28});

  Color get _c => color ?? kGreen;

  @override
  Widget build(BuildContext context) => AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: on ? _c : Colors.transparent,
          border: Border.all(color: on ? _c : kFaint, width: 2),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: on
              ? Icon(Icons.check_rounded,
                  key: const ValueKey('on'),
                  color: Colors.white,
                  size: size * 0.66)
              : const SizedBox.shrink(key: ValueKey('off')),
        ),
      );
}
