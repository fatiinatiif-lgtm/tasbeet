// lib/core/celebration.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

String _message(int i, String name) {
  switch (i % 4) {
    case 0:
      return 'بارك الله فيك، وهنيئًا لك إتمام $name! تقبّل الله منك. فاشكر الله على توفيقه، وأبشِر بقوله تعالى: «لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ».';
    case 1:
      return 'أحسنتَ يا حامل القرآن! أتممتَ $name بفضل الله وحده، فاحمده على نعمته، واسأله المزيد من التوفيق والثبات، وواصل وردك.';
    case 2:
      return 'ما شاء الله، هنيئًا لك هذا الإنجاز! جزاك الله خيرًا على مواظبتك في $name، فاشكر ربك على ما وفّقك إليه، واطلب منه المزيد من فضله.';
    default:
      return 'تبارك الله! لقد أتممتَ $name، فألف مبروك. اشكر الله على هذه النعمة، فالشكر يستجلب المزيد، ولا تتوقف عن الدعاء والاجتهاد.';
  }
}

/// يعرض قلوبًا كثيرة تتصاعد مع رسالة تهنئة وشكر
void showCelebration(BuildContext context, String name) {
  final overlay = Overlay.of(context);
  var closed = false;
  late OverlayEntry entry;
  entry = OverlayEntry(
    builder: (_) => _Celebration(
      name: name,
      onClose: () {
        if (closed) return;
        closed = true;
        entry.remove();
      },
    ),
  );
  overlay.insert(entry);
}

class _Heart {
  final double x, size, delay, dur, amp, freq, phase;
  final Color color;
  const _Heart(this.x, this.size, this.delay, this.dur, this.amp, this.freq,
      this.phase, this.color);
}

class _Celebration extends StatefulWidget {
  final String name;
  final VoidCallback onClose;
  const _Celebration({required this.name, required this.onClose});

  @override
  State<_Celebration> createState() => _CelebrationState();
}

class _CelebrationState extends State<_Celebration>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 5000),
  );
  late final List<_Heart> _hearts;
  late final int _msgIndex;

  @override
  void initState() {
    super.initState();
    final r = math.Random();
    _msgIndex = r.nextInt(4);
    final colors = <Color>[
      const Color(0xFFE53950),
      const Color(0xFFFF5C7C),
      const Color(0xFFFF8FAB),
      const Color(0xFFE91E63),
      const Color(0xFFFFB3C6),
      kGold,
    ];
    _hearts = List.generate(110, (_) {
      return _Heart(
        r.nextDouble(),
        14 + r.nextDouble() * 34,
        r.nextDouble() * 0.45,
        0.4 + r.nextDouble() * 0.15,
        6 + r.nextDouble() * 26,
        1 + r.nextDouble() * 2,
        r.nextDouble() * math.pi * 2,
        colors[r.nextInt(colors.length)],
      );
    });
    _c.forward();
    Future.delayed(const Duration(seconds: 9), () {
      if (mounted) widget.onClose();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Stack(children: [
        // خلفية معتمة خفيفة، والضغط عليها يُغلق الرسالة
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: AnimatedBuilder(
              animation: _c,
              builder: (_, __) => Container(
                color: Colors.black
                    .withAlpha((90 * math.min(1.0, _c.value * 6)).round()),
              ),
            ),
          ),
        ),
        // القلوب
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _c,
              builder: (_, __) => CustomPaint(
                painter: _HeartsPainter(_hearts, _c.value),
              ),
            ),
          ),
        ),
        // الرسالة
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.0, end: 1.0),
              duration: const Duration(milliseconds: 600),
              curve: Curves.elasticOut,
              builder: (_, v, child) => Transform.scale(
                scale: 0.6 + 0.4 * v,
                child: Opacity(opacity: v.clamp(0.0, 1.0), child: child),
              ),
              child: Container(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 16),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: kGold, width: 1.6),
                  boxShadow: softShadow(0.3),
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.favorite_rounded,
                      color: Color(0xFFE53950), size: 44),
                  const SizedBox(height: 10),
                  Text('تقبّل الله منك',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: kGreen)),
                  const SizedBox(height: 10),
                  Text(_message(_msgIndex, widget.name),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 16, height: 1.8, color: kInk)),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: kGreen,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: widget.onClose,
                      child: const Text('الحمد لله',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700)),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

class _HeartsPainter extends CustomPainter {
  final List<_Heart> hearts;
  final double t;
  _HeartsPainter(this.hearts, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final h in hearts) {
      final local = (t - h.delay) / h.dur;
      if (local <= 0 || local >= 1) continue;
      final fade = local < 0.1
          ? local / 0.1
          : (local > 0.75 ? (1 - local) / 0.25 : 1.0);
      final pop = local < 0.15 ? 0.4 + 0.6 * (local / 0.15) : 1.0;
      final x = h.x * size.width + math.sin(local * math.pi * 2 * h.freq + h.phase) * h.amp;
      final y = size.height * (1.05 - 1.15 * local);
      final s = h.size * pop;
      final paint = Paint()
        ..color = h.color.withAlpha((255 * fade).round())
        ..style = PaintingStyle.fill;
      canvas.drawPath(_heart(Offset(x, y), s), paint);
      // لمعة صغيرة
      canvas.drawCircle(
        Offset(x - s * 0.28, y - s * 0.28),
        s * 0.08,
        Paint()..color = Colors.white.withAlpha((150 * fade).round()),
      );
    }
  }

  Path _heart(Offset c, double s) {
    final p = Path()..moveTo(c.dx, c.dy + s * 0.4);
    p.cubicTo(c.dx - s * 0.95, c.dy - s * 0.1, c.dx - s * 0.5, c.dy - s * 0.8,
        c.dx, c.dy - s * 0.3);
    p.cubicTo(c.dx + s * 0.5, c.dy - s * 0.8, c.dx + s * 0.95, c.dy - s * 0.1,
        c.dx, c.dy + s * 0.4);
    p.close();
    return p;
  }

  @override
  bool shouldRepaint(_HeartsPainter old) => old.t != t;
}
