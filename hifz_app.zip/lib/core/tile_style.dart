// lib/core/tile_style.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/wird/wird_provider.dart';

/// أشكال عرض الأقسام في الصفحة الرئيسية
enum TileStyle { classic, list, compact, cards, circles, featured }

const kTileStyleNames = <TileStyle, String>{
  TileStyle.classic: 'الكلاسيكي',
  TileStyle.list: 'قائمة',
  TileStyle.compact: 'مدمج',
  TileStyle.cards: 'بطاقات',
  TileStyle.circles: 'دوائر',
  TileStyle.featured: 'مميّز',
};

class TileStyleNotifier extends Notifier<int> {
  static const _key = 'tile_style_v1';

  @override
  int build() {
    final v = ref.read(sharedPrefsProvider).getInt(_key) ?? 0;
    return (v >= 0 && v < TileStyle.values.length) ? v : 0;
  }

  void select(int i) {
    if (i < 0 || i >= TileStyle.values.length) return;
    ref.read(sharedPrefsProvider).setInt(_key, i);
    state = i;
  }
}

final tileStyleProvider =
    NotifierProvider<TileStyleNotifier, int>(TileStyleNotifier.new);
