// lib/core/theme_provider.dart
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/wird/wird_provider.dart';
import 'theme.dart';

/// يعيد بناء كل العناصر لتأخذ الألوان الجديدة (حتى الثابتة منها)
void rebuildAllChildren() {
  void rebuild(Element el) {
    el.markNeedsBuild();
    el.visitChildren(rebuild);
  }

  final root = WidgetsBinding.instance.rootElement;
  if (root != null) rebuild(root);
}

class ThemeNotifier extends Notifier<int> {
  static const _key = 'theme_v2';

  @override
  int build() {
    final saved = ref.read(sharedPrefsProvider).getInt(_key) ?? 0;
    final idx = (saved >= 0 && saved < kPalettes.length) ? saved : 0;
    PaletteHolder.current = kPalettes[idx];
    return idx;
  }

  void select(int i) {
    if (i < 0 || i >= kPalettes.length) return;
    PaletteHolder.current = kPalettes[i];
    ref.read(sharedPrefsProvider).setInt(_key, i);
    state = i;
    WidgetsBinding.instance.addPostFrameCallback((_) => rebuildAllChildren());
  }
}

final themeProvider = NotifierProvider<ThemeNotifier, int>(ThemeNotifier.new);

/// الوضع الداكن
class DarkNotifier extends Notifier<bool> {
  static const _key = 'dark_v1';

  @override
  bool build() {
    final v = ref.read(sharedPrefsProvider).getBool(_key) ?? false;
    PaletteHolder.dark = v;
    return v;
  }

  void set(bool v) {
    PaletteHolder.dark = v;
    ref.read(sharedPrefsProvider).setBool(_key, v);
    state = v;
    WidgetsBinding.instance.addPostFrameCallback((_) => rebuildAllChildren());
  }
}

final darkProvider = NotifierProvider<DarkNotifier, bool>(DarkNotifier.new);
