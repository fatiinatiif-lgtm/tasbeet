// lib/core/theme.dart
import 'package:flutter/material.dart';

const kGreen = Color(0xFF0F5C4D);
const kInk = Color(0xFF14211E);
const kBorder = Color(0xFFD9E4E1);
const kBg = Color(0xFFF4F7F6);
const kGold = Color(0xFFC98A12);
