// lib/core/theme.dart
import 'package:flutter/material.dart';

/// ثيم مكوّن من خمسة ألوان متداخلة
class AppPalette {
  final String name;
  final Color primary; // اللون الأساسي
  final Color dark; // اللون الداكن (نهاية التدرّج)
  final Color accent; // لون التمييز
  final Color bg; // لون الخلفية
  final Color mix; // لون ثالث يمتزج مع البقية في الأقسام
  const AppPalette(this.name, this.primary, this.dark, this.accent, this.bg,
      [this.mix = const Color(0xFF7B61C9)]);
}

const kPalettes = <AppPalette>[
  AppPalette('الملكي', Color(0xFF244C94), Color(0xFF11264F), Color(0xFFEC6A9C), Color(0xFFF2F6FD), Color(0xFF7B61C9)),
  AppPalette('الأزرق والوردي', Color(0xFF2D6CDF), Color(0xFF1A3E8C), Color(0xFFFF7EB6), Color(0xFFF3F7FF), Color(0xFF9B6BDF)),
  AppPalette('الزمرّد', Color(0xFF0B5D4B), Color(0xFF063D31), Color(0xFFC9A227), Color(0xFFF8F4EA), Color(0xFF1E8C8C)),
  AppPalette('الياقوت', Color(0xFF1F5F8B), Color(0xFF0F3A5C), Color(0xFFE0A93B), Color(0xFFF2F7FA), Color(0xFF2BA6A0)),
  AppPalette('المحيط', Color(0xFF0B6E99), Color(0xFF073B5A), Color(0xFFFF7F6B), Color(0xFFEFF8FC), Color(0xFF1FB5A8)),
  AppPalette('السماء', Color(0xFF3E8EDB), Color(0xFF1F5A96), Color(0xFFFFB347), Color(0xFFF1F8FF), Color(0xFF7B7FE0)),
  AppPalette('الليل', Color(0xFF1B2A4E), Color(0xFF0A1228), Color(0xFF6FA8FF), Color(0xFFEEF1F8), Color(0xFF8E6BD8)),
  AppPalette('العنبر', Color(0xFF9A5B13), Color(0xFF5E3508), Color(0xFF2E8B76), Color(0xFFFBF4E6), Color(0xFFD08A2C)),
  AppPalette('الأرجوان', Color(0xFF6D3A7C), Color(0xFF41204F), Color(0xFFD4A537), Color(0xFFF7F1F9), Color(0xFFB5508C)),
  AppPalette('الأرجواني الملكي', Color(0xFF4B2A8A), Color(0xFF26134F), Color(0xFFE8C24A), Color(0xFFF5F1FB), Color(0xFF2F6FD0)),
  AppPalette('الغسق', Color(0xFF5B3FA0), Color(0xFF2C1E66), Color(0xFFFF9A52), Color(0xFFF6F2FC), Color(0xFFE0527E)),
  AppPalette('الورد', Color(0xFFB04A6B), Color(0xFF6F2640), Color(0xFFD9A441), Color(0xFFFCF2F4), Color(0xFF8E4A9E)),
  AppPalette('الشفق', Color(0xFFC2477A), Color(0xFF6A1F4B), Color(0xFF5DA9E9), Color(0xFFFDF2F7), Color(0xFFF08A5D)),
  AppPalette('التوت', Color(0xFF8E2C6B), Color(0xFF521040), Color(0xFFF2B34F), Color(0xFFFBF0F6), Color(0xFF5B3FA0)),
  AppPalette('الكرز', Color(0xFFB3213F), Color(0xFF6A0F25), Color(0xFFF0B35A), Color(0xFFFDF1F3), Color(0xFF7A2E8A)),
  AppPalette('العقيق', Color(0xFFA23B2A), Color(0xFF66210F), Color(0xFFD9B24C), Color(0xFFFBF1EC), Color(0xFFC2603A)),
  AppPalette('الخوخ', Color(0xFFE0766A), Color(0xFF9A3D36), Color(0xFF6FB7A8), Color(0xFFFFF4F1), Color(0xFFF2A65A)),
  AppPalette('الغروب', Color(0xFFD2691E), Color(0xFF8A3A0B), Color(0xFF3F5E9E), Color(0xFFFDF3E8), Color(0xFFC23B5E)),
  AppPalette('الرمل', Color(0xFF8C6D46), Color(0xFF5A4326), Color(0xFF2F7D6B), Color(0xFFF8F3EA), Color(0xFFB5894F)),
  AppPalette('النيلي', Color(0xFF3949AB), Color(0xFF1F2A6B), Color(0xFFF2B94B), Color(0xFFF1F2FA), Color(0xFF6A3FA0)),
  AppPalette('اللافندر', Color(0xFF7B6BB5), Color(0xFF4A3F7E), Color(0xFFE5B84B), Color(0xFFF4F2FA), Color(0xFFB06AB3)),
  AppPalette('الفيروز', Color(0xFF0E7C86), Color(0xFF075055), Color(0xFFE3B04B), Color(0xFFEFF8F8), Color(0xFF2D6CC0)),
  AppPalette('النعناع', Color(0xFF2E9E7E), Color(0xFF17604C), Color(0xFFF08CA6), Color(0xFFF0FAF6), Color(0xFF4AB3C8)),
  AppPalette('الليمون والبحر', Color(0xFF1C8A8A), Color(0xFF0E4F55), Color(0xFFB6D63A), Color(0xFFF1FAF6), Color(0xFF3C7DD9)),
  AppPalette('الصنوبر', Color(0xFF2F6B3A), Color(0xFF173D1F), Color(0xFFE0B040), Color(0xFFF1F7EE), Color(0xFF1F7A6E)),
  AppPalette('الأخضر الذهبي', Color(0xFF3F7D3A), Color(0xFF1F4A1E), Color(0xFFF2A93B), Color(0xFFF2F8EE), Color(0xFF2A8F8F)),
  AppPalette('الزيتون', Color(0xFF5B6B1F), Color(0xFF36410F), Color(0xFFC98A2B), Color(0xFFF6F5E6), Color(0xFF2F7D5B)),
  AppPalette('الفحم', Color(0xFF37474F), Color(0xFF1C2A30), Color(0xFFC9A227), Color(0xFFF3F5F6), Color(0xFF5C7A99)),
];

/// يحمل الثيم الحالي (يتغيّر عند اختيار ثيم جديد)
class PaletteHolder {
  static AppPalette current = kPalettes[0];
  static bool dark = false; // الوضع الداكن
}

bool get _dk => PaletteHolder.dark;

Color get kGreen => _dk
    ? Color.lerp(PaletteHolder.current.primary, Colors.white, 0.28)!
    : PaletteHolder.current.primary;
Color get kGreenDark => PaletteHolder.current.dark;
Color get kGold => PaletteHolder.current.accent;
Color get kBg => _dk
    ? Color.lerp(PaletteHolder.current.dark, Colors.black, 0.78)!
    : PaletteHolder.current.bg;

/// لون البطاقات
Color get kCard => _dk
    ? Color.lerp(PaletteHolder.current.dark, Colors.black, 0.6)!
    : Colors.white;

/// لون النص الأساسي
Color get kInk => _dk ? const Color(0xFFEDEFEA) : const Color(0xFF14211E);

/// لون النص الثانوي
Color get kMuted => _dk ? const Color(0xFFAEB8B4) : Colors.black54;

/// لون العناصر الباهتة (الدوائر الفارغة)
Color get kFaint => _dk ? Colors.white30 : Colors.black26;

/// لون الحدود
Color get kBorder =>
    _dk ? Color.lerp(kCard, Colors.white, 0.14)! : const Color(0xFFE4DCC6);

/// لون نص ذهبي مقروء على الخلفية الحالية
Color get kGoldText => _dk ? kGoldLight : kGoldDark;
Color get kGoldLight => Color.lerp(PaletteHolder.current.accent, Colors.white, 0.5)!;
Color get kGoldDark => Color.lerp(PaletteHolder.current.accent, Colors.black, 0.35)!;

/// تدرّج لوني لكل قسم، مشتق من ألوان الثيم الحالي ويمتزج بها.
/// 0-4 بنفس ترتيب Section، ثم 5 خطة الحفظ، 6 النوافل، 7 ألقابي، 8 الإحصائيات
List<List<Color>> get kSectionGradients {
  final p = PaletteHolder.current;
  Color on(Color c) => _dk ? Color.lerp(c, Colors.white, 0.16)! : c;
  Color deep(Color c, [double a = 0.4]) => Color.lerp(c, Colors.black, a)!;
  List<Color> g(Color c, [double a = 0.4]) => [on(c), deep(c, a)];
  final mix = p.mix;
  return [
    [kGreen, kGreenDark], // الحفظ الجديد (لون الثيم)
    g(mix), // المراجعة اليومية
    [kGold, kGoldDark], // السرد غيبًا
    g(Color.lerp(p.primary, mix, 0.55)!), // ختمتي
    [Color.lerp(p.dark, mix, 0.3)!, deep(p.dark, 0.5)], // ختمة القيام
    g(Color.lerp(p.primary, p.accent, 0.4)!), // خطة الحفظ
    g(Color.lerp(p.accent, mix, 0.45)!), // النوافل
    g(Color.lerp(mix, p.accent, 0.4)!, 0.45), // ألقابي
    g(Color.lerp(p.primary, const Color(0xFF6B7A8F), 0.5)!), // الإحصائيات
  ];
}

/// ظل ناعم للبطاقات
List<BoxShadow> softShadow([double opacity = 0.08]) => [
      BoxShadow(
        color: Color.fromRGBO(20, 33, 30, opacity),
        blurRadius: 16,
        offset: const Offset(0, 6),
      ),
    ];

BoxDecoration cardDeco({Color? color, Color? border, double radius = 20}) =>
    BoxDecoration(
      color: color ?? kCard,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border ?? kBorder),
      boxShadow: softShadow(),
    );
