// lib/core/theme.dart
import 'package:flutter/material.dart';

const kGreen = Color(0xFF0B5D4B);
const kGreenDark = Color(0xFF063D31);
const kInk = Color(0xFF14211E);
const kBorder = Color(0xFFE4DCC6);
const kBg = Color(0xFFF8F4EA);
const kGold = Color(0xFFC9A227);
const kGoldLight = Color(0xFFF0DC9A);

/// تدرّج لوني لكل قسم (بنفس ترتيب Section)
const kSectionGradients = <List<Color>>[
  [Color(0xFF0F6B57), Color(0xFF084636)], // الحفظ الجديد
  [Color(0xFF1F7A99), Color(0xFF124B63)], // المراجعة اليومية
  [Color(0xFFB07F1A), Color(0xFF73500F)], // السرد غيبًا
  [Color(0xFF4A5FB0), Color(0xFF2B387A)], // القراءة اليومية
];

/// ظل ناعم للبطاقات
List<BoxShadow> softShadow([double opacity = 0.08]) => [
      BoxShadow(
        color: Color.fromRGBO(20, 33, 30, opacity),
        blurRadius: 16,
        offset: const Offset(0, 6),
      ),
    ];

BoxDecoration cardDeco({Color? color, Color? border, double radius = 20}) =>
    BoxDecoration(
      color: color ?? Colors.white,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border ?? kBorder),
      boxShadow: softShadow(),
    );
