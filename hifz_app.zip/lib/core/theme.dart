// lib/core/theme.dart
import 'package:flutter/material.dart';

/// ثيم مكوّن من أربعة ألوان متداخلة
class AppPalette {
  final String name;
  final Color primary; // اللون الأساسي
  final Color dark; // اللون الداكن (نهاية التدرّج)
  final Color accent; // لون التمييز (الذهبي سابقًا)
  final Color bg; // لون الخلفية
  const AppPalette(this.name, this.primary, this.dark, this.accent, this.bg);
}

const kPalettes = <AppPalette>[
  AppPalette('الملكي', Color(0xFF244C94), Color(0xFF11264F), Color(0xFFEC6A9C), Color(0xFFF2F6FD)),
  AppPalette('الزمرّد', Color(0xFF0B5D4B), Color(0xFF063D31), Color(0xFFC9A227), Color(0xFFF8F4EA)),
  AppPalette('الياقوت', Color(0xFF1F5F8B), Color(0xFF0F3A5C), Color(0xFFE0A93B), Color(0xFFF2F7FA)),
  AppPalette('العنبر', Color(0xFF9A5B13), Color(0xFF5E3508), Color(0xFF2E8B76), Color(0xFFFBF4E6)),
  AppPalette('الأرجوان', Color(0xFF6D3A7C), Color(0xFF41204F), Color(0xFFD4A537), Color(0xFFF7F1F9)),
  AppPalette('الورد', Color(0xFFB04A6B), Color(0xFF6F2640), Color(0xFFD9A441), Color(0xFFFCF2F4)),
  AppPalette('النيلي', Color(0xFF3949AB), Color(0xFF1F2A6B), Color(0xFFF2B94B), Color(0xFFF1F2FA)),
  AppPalette('الزيتون', Color(0xFF5B6B1F), Color(0xFF36410F), Color(0xFFC98A2B), Color(0xFFF6F5E6)),
  AppPalette('الفيروز', Color(0xFF0E7C86), Color(0xFF075055), Color(0xFFE3B04B), Color(0xFFEFF8F8)),
  AppPalette('الفحم', Color(0xFF37474F), Color(0xFF1C2A30), Color(0xFFC9A227), Color(0xFFF3F5F6)),
  AppPalette('العقيق', Color(0xFFA23B2A), Color(0xFF66210F), Color(0xFFD9B24C), Color(0xFFFBF1EC)),
  AppPalette('الرمل', Color(0xFF8C6D46), Color(0xFF5A4326), Color(0xFF2F7D6B), Color(0xFFF8F3EA)),
  AppPalette('الغروب', Color(0xFFD2691E), Color(0xFF8A3A0B), Color(0xFF3F5E9E), Color(0xFFFDF3E8)),
  AppPalette('الصنوبر', Color(0xFF2F6B3A), Color(0xFF173D1F), Color(0xFFE0B040), Color(0xFFF1F7EE)),
  AppPalette('اللافندر', Color(0xFF7B6BB5), Color(0xFF4A3F7E), Color(0xFFE5B84B), Color(0xFFF4F2FA)),
];

/// يحمل الثيم الحالي (يتغيّر عند اختيار ثيم جديد)
class PaletteHolder {
  static AppPalette current = kPalettes[0];
  static bool dark = false; // الوضع الداكن
}

bool get _dk => PaletteHolder.dark;

Color get kGreen => _dk
    ? Color.lerp(PaletteHolder.current.primary, Colors.white, 0.28)!
    : PaletteHolder.current.primary;
Color get kGreenDark => PaletteHolder.current.dark;
Color get kGold => PaletteHolder.current.accent;
Color get kBg => _dk
    ? Color.lerp(PaletteHolder.current.dark, Colors.black, 0.78)!
    : PaletteHolder.current.bg;

/// لون البطاقات
Color get kCard => _dk
    ? Color.lerp(PaletteHolder.current.dark, Colors.black, 0.6)!
    : Colors.white;

/// لون النص الأساسي
Color get kInk => _dk ? const Color(0xFFEDEFEA) : const Color(0xFF14211E);

/// لون النص الثانوي
Color get kMuted => _dk ? const Color(0xFFAEB8B4) : Colors.black54;

/// لون العناصر الباهتة (الدوائر الفارغة)
Color get kFaint => _dk ? Colors.white30 : Colors.black26;

/// لون الحدود
Color get kBorder =>
    _dk ? Color.lerp(kCard, Colors.white, 0.14)! : const Color(0xFFE4DCC6);

/// لون نص ذهبي مقروء على الخلفية الحالية
Color get kGoldText => _dk ? kGoldLight : kGoldDark;
Color get kGoldLight => Color.lerp(PaletteHolder.current.accent, Colors.white, 0.5)!;
Color get kGoldDark => Color.lerp(PaletteHolder.current.accent, Colors.black, 0.35)!;

/// تدرّج لوني لكل قسم (بنفس ترتيب Section)
List<List<Color>> get kSectionGradients => [
      [kGreen, kGreenDark], // الحفظ الجديد (لون الثيم)
      const [Color(0xFF2E7DB8), Color(0xFF174B78)], // المراجعة اليومية
      [kGold, kGoldDark], // السرد غيبًا
      const [Color(0xFF4A5FB0), Color(0xFF2B387A)], // ختمتي
      const [Color(0xFF2E3A73), Color(0xFF131A44)], // ختمة القيام
    ];

/// ظل ناعم للبطاقات
List<BoxShadow> softShadow([double opacity = 0.08]) => [
      BoxShadow(
        color: Color.fromRGBO(20, 33, 30, opacity),
        blurRadius: 16,
        offset: const Offset(0, 6),
      ),
    ];

BoxDecoration cardDeco({Color? color, Color? border, double radius = 20}) =>
    BoxDecoration(
      color: color ?? kCard,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border ?? kBorder),
      boxShadow: softShadow(),
    );
