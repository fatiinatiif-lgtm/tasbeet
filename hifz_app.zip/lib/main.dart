// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme.dart';
import 'features/splash/splash_screen.dart';
import 'features/wird/wird_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
    child: const HifzApp(),
  ));
}

class HifzApp extends StatelessWidget {
  const HifzApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'حفظ',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: kGreen,
          scaffoldBackgroundColor: kBg,
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: Colors.white,
            elevation: 8,
            height: 68,
            indicatorColor: kGreen.withAlpha(30),
            labelTextStyle: MaterialStateProperty.resolveWith(
              (states) => TextStyle(
                fontSize: 13,
                fontWeight: states.contains(MaterialState.selected)
                    ? FontWeight.w800
                    : FontWeight.w500,
                color: states.contains(MaterialState.selected)
                    ? kGreen
                    : Colors.black54,
              ),
            ),
            iconTheme: MaterialStateProperty.resolveWith(
              (states) => IconThemeData(
                color: states.contains(MaterialState.selected)
                    ? kGreen
                    : Colors.black54,
              ),
            ),
          ),
        ),
        builder: (context, child) =>
            Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const SplashScreen(),
      );
}
