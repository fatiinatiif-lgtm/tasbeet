// lib/main.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme.dart';
import 'core/theme_provider.dart';
import 'features/splash/splash_screen.dart';
import 'features/wird/wird_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
    child: const HifzApp(),
  ));
}

class HifzApp extends ConsumerWidget {
  const HifzApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(themeProvider); // يعيد بناء التطبيق عند تغيير الثيم
    final dark = ref.watch(darkProvider);
    return MaterialApp(
        title: 'المصطفون',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: dark ? Brightness.dark : Brightness.light,
          colorSchemeSeed: kGreen,
          scaffoldBackgroundColor: kBg,
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: kCard,
            elevation: 8,
            height: 68,
            indicatorColor: kGreen.withAlpha(30),
            labelTextStyle: MaterialStateProperty.resolveWith(
              (states) => TextStyle(
                fontSize: 13,
                fontWeight: states.contains(MaterialState.selected)
                    ? FontWeight.w800
                    : FontWeight.w500,
                color: states.contains(MaterialState.selected)
                    ? kGreen
                    : kMuted,
              ),
            ),
            iconTheme: MaterialStateProperty.resolveWith(
              (states) => IconThemeData(
                color: states.contains(MaterialState.selected)
                    ? kGreen
                    : kMuted,
              ),
            ),
          ),
        ),
        builder: (context, child) => _Immersive(
            child: Directionality(
                textDirection: TextDirection.rtl, child: child!)),
        home: const SplashScreen(),
      );
  }
}


/// يبقي التطبيق في وضع الشاشة الكاملة (إخفاء شريط الحالة وأزرار النظام)
/// ويعيد تفعيله بعد العودة للتطبيق أو إغلاق لوحة المفاتيح.
class _Immersive extends StatefulWidget {
  final Widget child;
  const _Immersive({required this.child});

  @override
  State<_Immersive> createState() => _ImmersiveState();
}

class _ImmersiveState extends State<_Immersive> with WidgetsBindingObserver {
  Timer? _t;

  void _apply() => SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _apply();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _apply();
  }

  @override
  void didChangeMetrics() {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 400), _apply);
  }

  @override
  void dispose() {
    _t?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
