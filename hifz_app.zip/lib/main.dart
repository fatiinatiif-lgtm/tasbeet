// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme.dart';
import 'features/home/home_screen.dart';
import 'features/wird/wird_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
    child: const HifzApp(),
  ));
}

class HifzApp extends StatelessWidget {
  const HifzApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'حفظ',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: kGreen,
          scaffoldBackgroundColor: kBg,
        ),
        builder: (context, child) =>
            Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const HomeScreen(),
      );
}
