// lib/data/local/storage.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../quran/surah_data.dart';

/// يتم تجاهله (override) في main.dart بعد تحميل SharedPreferences
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('override in main'),
);

abstract class MemorizationRepository {
  Future<List<MemorizationItem>> getAll();
  Future<void> save(MemorizationItem item);
  Future<void> add(MemorizationItem item);
}

class PrefsMemorizationRepository implements MemorizationRepository {
  static const _key = 'memorization_items';
  final SharedPreferences prefs;
  late final List<MemorizationItem> _items;

  PrefsMemorizationRepository(this.prefs) {
    final raw = prefs.getString(_key);
    _items = raw == null
        ? []
        : (jsonDecode(raw) as List)
            .map((e) => MemorizationItem.fromJson(e as Map<String, dynamic>))
            .toList();
  }

  Future<void> _persist() => prefs.setString(
      _key, jsonEncode(_items.map((e) => e.toJson()).toList()));

  @override
  Future<List<MemorizationItem>> getAll() async => List.of(_items);

  @override
  Future<void> add(MemorizationItem item) async {
    _items.add(item);
    await _persist();
  }

  @override
  Future<void> save(MemorizationItem item) async {
    final i = _items.indexWhere((e) => e.id == item.id);
    if (i >= 0) _items[i] = item;
    await _persist();
  }
}

final memorizationRepoProvider = Provider<MemorizationRepository>(
  (ref) => PrefsMemorizationRepository(ref.read(sharedPrefsProvider)),
);

/// الآيات المحفوظة فعلياً لكل سورة (دمج النطاقات المتداخلة)
Map<int, Set<int>> memorizedCoverage(List<MemorizationItem> items) {
  final map = <int, Set<int>>{};
  for (final it in items) {
    final set = map.putIfAbsent(it.surah, () => <int>{});
    for (var a = it.fromAyah; a <= it.toAyah; a++) {
      set.add(a);
    }
  }
  return map;
}

int memorizedAyahCount(List<MemorizationItem> items) =>
    memorizedCoverage(items).values.fold(0, (sum, s) => sum + s.length);

int completedSurahCount(List<MemorizationItem> items) {
  final cov = memorizedCoverage(items);
  return cov.entries
      .where((e) => e.value.length >= surahOf(e.key).ayahCount)
      .length;
}
