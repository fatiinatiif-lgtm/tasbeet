// lib/data/models/models.dart

enum ReviewRating { forgot, hesitant, excellent }

/// وحدة حفظ: مجموعة آيات من سورة واحدة
class MemorizationItem {
  final String id;
  final int surah;
  final int fromAyah;
  final int toAyah;
  final DateTime memorizedAt;

  int repetitions;       // عدد المراجعات الناجحة المتتالية
  double easeFactor;     // معامل السهولة (يبدأ 2.5)
  int intervalDays;      // الفاصل الحالي بالأيام
  DateTime nextReview;

  MemorizationItem({
    required this.id,
    required this.surah,
    required this.fromAyah,
    required this.toAyah,
    required this.memorizedAt,
    this.repetitions = 0,
    this.easeFactor = 2.5,
    this.intervalDays = 1,
    DateTime? nextReview,
  }) : nextReview = nextReview ?? memorizedAt.add(const Duration(days: 1));

  Map<String, dynamic> toJson() => {
        'id': id,
        'surah': surah,
        'fromAyah': fromAyah,
        'toAyah': toAyah,
        'memorizedAt': memorizedAt.toIso8601String(),
        'repetitions': repetitions,
        'easeFactor': easeFactor,
        'intervalDays': intervalDays,
        'nextReview': nextReview.toIso8601String(),
      };

  factory MemorizationItem.fromJson(Map<String, dynamic> j) =>
      MemorizationItem(
        id: j['id'] as String,
        surah: j['surah'] as int,
        fromAyah: j['fromAyah'] as int,
        toAyah: j['toAyah'] as int,
        memorizedAt: DateTime.parse(j['memorizedAt'] as String),
        repetitions: j['repetitions'] as int,
        easeFactor: (j['easeFactor'] as num).toDouble(),
        intervalDays: j['intervalDays'] as int,
        nextReview: DateTime.parse(j['nextReview'] as String),
      );

  /// قوة الحفظ للخريطة: 0 ضعيف .. 1 ثابت
  double get strength => (intervalDays / 30).clamp(0.0, 1.0);

  /// تطبيق التقييم وتحديث موعد المراجعة (مبني على SM-2 مبسّط)
  void applyReview(ReviewRating rating, {DateTime? now}) {
    final today = now ?? DateTime.now();
    switch (rating) {
      case ReviewRating.forgot:
        repetitions = 0;
        intervalDays = 1;
        easeFactor = (easeFactor - 0.2).clamp(1.3, 3.0);
        break;
      case ReviewRating.hesitant:
        repetitions += 1;
        intervalDays = (intervalDays * 1.2).ceil();
        easeFactor = (easeFactor - 0.05).clamp(1.3, 3.0);
        break;
      case ReviewRating.excellent:
        repetitions += 1;
        intervalDays = repetitions == 1
            ? 3
            : (intervalDays * easeFactor).ceil();
        easeFactor = (easeFactor + 0.1).clamp(1.3, 3.0);
        break;
    }
    nextReview = today.add(Duration(days: intervalDays));
  }

  bool isDue([DateTime? now]) =>
      !(now ?? DateTime.now()).isBefore(nextReview);
}

/// سجل قراءة
class ReadingLog {
  final String id;
  final DateTime date;
  final int fromPage;
  final int toPage;
  ReadingLog(this.id, this.date, this.fromPage, this.toPage);

  int get pages => toPage - fromPage + 1;
}

/// إنجاز / وسام
class Achievement {
  final String id;
  final String title;
  final String description;
  final int xpReward;
  DateTime? unlockedAt;
  Achievement(this.id, this.title, this.description, this.xpReward,
      {this.unlockedAt});

  bool get isUnlocked => unlockedAt != null;
}

/// تحدي (يومي / أسبوعي / شهري)
enum ChallengeType { daily, weekly, monthly }

class Challenge {
  final String id;
  final String title;
  final ChallengeType type;
  final int target;   // مثلاً 3 أوجه
  int progress;
  final DateTime endsAt;
  Challenge(this.id, this.title, this.type, this.target, this.endsAt,
      {this.progress = 0});

  bool get isDone => progress >= target;
}

/// ملف المستخدم: نقاط وألقاب وسلسلة أيام
class UserProfile {
  final String id;
  String name;
  int xp;
  int streakDays;
  int totalPagesMemorized;
  int totalAyahs;
  int totalReviews;
  DateTime? lastActive; // تاريخ بدون وقت (UTC)
  bool showOnLeaderboard;

  UserProfile({
    required this.id,
    required this.name,
    this.xp = 0,
    this.streakDays = 0,
    this.totalPagesMemorized = 0,
    this.totalAyahs = 0,
    this.totalReviews = 0,
    this.lastActive,
    this.showOnLeaderboard = true,
  });

  /// السلسلة الحالية (تتصفّر لو فات أكتر من يوم)
  int get currentStreak {
    if (lastActive == null) return 0;
    final n = DateTime.now();
    final today = DateTime.utc(n.year, n.month, n.day);
    return today.difference(lastActive!).inDays > 1 ? 0 : streakDays;
  }

  /// اللقب حسب عدد الأوجه المحفوظة (الجزء ≈ 20 وجه)
  String get title {
    final juz = totalPagesMemorized / 20;
    if (juz >= 30) return 'مُتقن';
    if (juz >= 15) return 'حافظ نصف';
    if (juz >= 5) return 'حافظ خمسة أجزاء';
    if (juz >= 1) return 'حافظ جزء';
    if (totalPagesMemorized >= 1) return 'مُرتّل';
    return 'مبتدئ';
  }

  UserProfile copy() => UserProfile(
        id: id,
        name: name,
        xp: xp,
        streakDays: streakDays,
        totalPagesMemorized: totalPagesMemorized,
        totalAyahs: totalAyahs,
        totalReviews: totalReviews,
        lastActive: lastActive,
        showOnLeaderboard: showOnLeaderboard,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'xp': xp,
        'streakDays': streakDays,
        'totalPagesMemorized': totalPagesMemorized,
        'totalAyahs': totalAyahs,
        'totalReviews': totalReviews,
        'lastActive': lastActive?.toIso8601String(),
        'showOnLeaderboard': showOnLeaderboard,
      };

  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
        id: j['id'] as String,
        name: j['name'] as String,
        xp: j['xp'] as int? ?? 0,
        streakDays: j['streakDays'] as int? ?? 0,
        totalPagesMemorized: j['totalPagesMemorized'] as int? ?? 0,
        totalAyahs: j['totalAyahs'] as int? ?? 0,
        totalReviews: j['totalReviews'] as int? ?? 0,
        lastActive: j['lastActive'] == null
            ? null
            : DateTime.parse(j['lastActive'] as String),
        showOnLeaderboard: j['showOnLeaderboard'] as bool? ?? true,
      );
}

/// نقاط XP لكل نشاط
class XpRules {
  static const newMemorization = 20;
  static const review = 10;
  static const readingPage = 2;
  static const dailyStreakBonus = 5;
}
