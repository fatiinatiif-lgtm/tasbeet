// lib/data/models/wird_models.dart
import 'package:flutter/material.dart';
import '../quran/surah_data.dart';

enum Section { hifz, review, sard, reading, qiyam }

extension SectionX on Section {
  String get label {
    switch (this) {
      case Section.hifz:
        return 'الحفظ الجديد';
      case Section.review:
        return 'المراجعة اليومية';
      case Section.sard:
        return 'السرد غيبًا';
      case Section.reading:
        return 'ختمتي';
      case Section.qiyam:
        return 'ختمة القيام';
    }
  }

  /// نقاط كل مهمة تنتهي
  int get xp {
    switch (this) {
      case Section.hifz:
        return 20;
      case Section.review:
        return 10;
      case Section.sard:
        return 15;
      case Section.reading:
        return 10;
      case Section.qiyam:
        return 15;
    }
  }

  IconData get icon {
    switch (this) {
      case Section.hifz:
        return Icons.menu_book;
      case Section.review:
        return Icons.autorenew;
      case Section.sard:
        return Icons.record_voice_over;
      case Section.reading:
        return Icons.auto_stories;
      case Section.qiyam:
        return Icons.nightlight_round;
    }
  }
}

enum UnitType { surah, hizb, rub, khatma, juz, plan }

/// الاسم القصير (في خانات الاختيار)
String unitTitle(UnitType t, int n) {
  switch (t) {
    case UnitType.surah:
      return surahName(n);
    case UnitType.hizb:
      return 'الحزب $n';
    case UnitType.rub:
      return 'الربع $n';
    case UnitType.khatma:
      return khatmaName(n);
    case UnitType.juz:
      return 'الجزء $n';
    case UnitType.plan:
      return surahName(n);
  }
}

/// سطر توضيحي صغير تحت الاسم
String unitSub(UnitType t, int n) {
  switch (t) {
    case UnitType.surah:
      return '${surahOf(n).ayahCount} آية';
    case UnitType.hizb:
      return 'الجزء ${(n + 1) ~/ 2}';
    case UnitType.rub:
      return 'من الحزب ${(n - 1) ~/ 4 + 1}';
    case UnitType.khatma:
      return 'من ختمتي';
    case UnitType.juz:
      return 'ختمة القيام';
    case UnitType.plan:
      return 'من خطة الحفظ';
  }
}

/// الاسم الكامل (في الورد اليومي والإحصائيات)
String unitFull(UnitType t, int n) {
  switch (t) {
    case UnitType.surah:
      return 'سورة ${surahName(n)}';
    case UnitType.hizb:
      return 'الحزب $n (الجزء ${(n + 1) ~/ 2})';
    case UnitType.rub:
      return 'الربع $n (من الحزب ${(n - 1) ~/ 4 + 1})';
    case UnitType.khatma:
      return khatmaName(n);
    case UnitType.juz:
      return 'الجزء $n (قيام الليل)';
    case UnitType.plan:
      return 'خطة الحفظ: سورة ${surahName(n)}';
  }
}

/// رقم الختمة = بداية*100 + نهاية (مثال 406 = الأجزاء من 4 إلى 6)
String khatmaName(int n) {
  final a = n ~/ 100, b = n % 100;
  return a == b ? 'الجزء $a' : 'الأجزاء من $a إلى $b';
}

String khatmaBadge(int n) {
  final a = n ~/ 100, b = n % 100;
  return a == b ? '$a' : '$a-$b';
}

String dayString(DateTime t) =>
    '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';

String todayString() => dayString(DateTime.now());

/// عنصر مختار في قسم معين
class WirdEntry {
  final Section section;
  final UnitType type;
  final int number;
  const WirdEntry(this.section, this.type, this.number);

  String get key => '${section.name}:${type.name}:$number';
  String get fullName => unitFull(type, number);
  String get badgeText =>
      type == UnitType.khatma ? khatmaBadge(number) : '$number';

  Map<String, dynamic> toJson() =>
      {'s': section.name, 't': type.name, 'n': number};

  factory WirdEntry.fromJson(Map<String, dynamic> j) => WirdEntry(
        Section.values.byName(j['s'] as String),
        UnitType.values.byName(j['t'] as String),
        j['n'] as int,
      );
}

/// سجل إنجاز مهمة في يوم معين
class CompletionLog {
  final WirdEntry entry;
  final String date; // yyyy-MM-dd
  const CompletionLog(this.entry, this.date);

  Map<String, dynamic> toJson() => {'e': entry.toJson(), 'd': date};

  factory CompletionLog.fromJson(Map<String, dynamic> j) => CompletionLog(
        WirdEntry.fromJson(j['e'] as Map<String, dynamic>),
        j['d'] as String,
      );
}
