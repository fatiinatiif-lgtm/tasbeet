package __PKG__

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetProvider

class WirdWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.wird_widget)
            views.setTextViewText(
                R.id.w_progress, widgetData.getString("w_progress", "0 / 0") ?: "0 / 0")
            views.setTextViewText(
                R.id.w_next, widgetData.getString("w_next", "افتح التطبيق لاختيار وردك") ?: "")
            views.setTextViewText(
                R.id.w_streak, widgetData.getString("w_streak", "") ?: "")
            if (launch != null) {
                val pi = PendingIntent.getActivity(
                    context, 0, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w_root, pi)
            }
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}
