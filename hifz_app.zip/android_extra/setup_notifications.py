import glob
import re

# 1) permissions + receivers in AndroidManifest
p = 'app/android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
perms = (
    '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
    '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>\n'
    '    <uses-permission android:name="android.permission.VIBRATE"/>\n'
)
recv = (
    '    <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>\n'
    '    <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">\n'
    '        <intent-filter>\n'
    '            <action android:name="android.intent.action.BOOT_COMPLETED"/>\n'
    '            <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>\n'
    '            <action android:name="android.intent.action.QUICKBOOT_POWERON"/>\n'
    '            <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>\n'
    '        </intent-filter>\n'
    '    </receiver>\n'
)
assert '<application' in s and '</application>' in s
s = s.replace('<application', perms + '    <application', 1)
s = s.replace('</application>', recv + '    </application>', 1)
open(p, 'w', encoding='utf-8').write(s)

# 2) core library desugaring in build.gradle (Groovy or Kotlin DSL)
f = glob.glob('app/android/app/build.gradle*')[0]
g = open(f, encoding='utf-8').read()
kts = f.endswith('.kts')
flag = 'isCoreLibraryDesugaringEnabled = true' if kts else 'coreLibraryDesugaringEnabled true'
dep = ('coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")' if kts
       else "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'")
assert 'compileOptions {' in g
g = g.replace('compileOptions {', 'compileOptions {\n        ' + flag, 1)
if re.search(r'^dependencies\s*\{', g, re.M):
    g = re.sub(r'^(dependencies\s*\{)', lambda m: m.group(1) + '\n    ' + dep,
               g, count=1, flags=re.M)
else:
    g += '\ndependencies {\n    ' + dep + '\n}\n'
open(f, 'w', encoding='utf-8').write(g)
print(g)
