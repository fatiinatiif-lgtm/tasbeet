// lib/core/reminder_service.dart  (نسخة تجريبية بدون إشعارات)
import 'package:shared_preferences/shared_preferences.dart';
import '../features/wird/wird_provider.dart';
import 'reminders.dart';

class ReminderService {
  static Future<void> init() async {}
  static Future<void> askPermissionOnce(SharedPreferences prefs) async {}
  static Future<void> sync(WirdState s, ReminderConfig c) async {}
}
