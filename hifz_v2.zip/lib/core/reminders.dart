// lib/core/reminders.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/wird_models.dart';
import '../features/wird/wird_provider.dart';

export 'reminder_service.dart';

/// أوقات التذكير الافتراضية لكل قسم (بالدقائق من منتصف الليل)
const kDefaultSectionMinutes = <Section, int>{
  Section.hifz: 7 * 60,
  Section.review: 17 * 60,
  Section.sard: 19 * 60,
  Section.reading: 20 * 60,
  Section.qiyam: 3 * 60,
};

/// قيمة تعني «بدون تذكير» لعنصر معيّن
const kReminderOff = -1;

/// 7:05 ص / 5:30 م
String fmtMinutes(int m) {
  final h = m ~/ 60, min = m % 60;
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '$h12:${min.toString().padLeft(2, '0')} ${h < 12 ? 'ص' : 'م'}';
}

class ReminderConfig {
  final bool enabled;
  final Map<String, int> sections; // section.name -> minutes
  final Map<String, int> items; // entry.key -> minutes (أو -1 = بدون)
  const ReminderConfig(
      {this.enabled = true, this.sections = const {}, this.items = const {}});

  int sectionMinutes(Section s) => sections[s.name] ?? kDefaultSectionMinutes[s]!;

  /// وقت تذكير عنصر (قد يكون -1 = معطّل)
  int minutesFor(WirdEntry e) => items[e.key] ?? sectionMinutes(e.section);

  bool hasOverride(WirdEntry e) => items.containsKey(e.key);

  ReminderConfig copy(
          {bool? enabled, Map<String, int>? sections, Map<String, int>? items}) =>
      ReminderConfig(
          enabled: enabled ?? this.enabled,
          sections: sections ?? this.sections,
          items: items ?? this.items);

  Map<String, dynamic> toJson() =>
      {'on': enabled, 'sec': sections, 'items': items};

  factory ReminderConfig.fromJson(Map<String, dynamic> j) => ReminderConfig(
        enabled: j['on'] as bool? ?? true,
        sections: Map<String, int>.from((j['sec'] as Map?) ?? {}),
        items: Map<String, int>.from((j['items'] as Map?) ?? {}),
      );
}

class ReminderNotifier extends Notifier<ReminderConfig> {
  static const _key = 'reminders_v1';

  @override
  ReminderConfig build() {
    final raw = ref.read(sharedPrefsProvider).getString(_key);
    if (raw == null) return const ReminderConfig();
    try {
      return ReminderConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return const ReminderConfig();
    }
  }

  void _save(ReminderConfig c) {
    state = c;
    ref.read(sharedPrefsProvider).setString(_key, jsonEncode(c.toJson()));
  }

  void setEnabled(bool v) => _save(state.copy(enabled: v));

  void setSection(Section s, int minutes) =>
      _save(state.copy(sections: {...state.sections, s.name: minutes}));

  /// [minutes] = null يعيد العنصر للوقت الافتراضي لقسمه، و -1 يعطّل تذكيره
  void setItem(WirdEntry e, int? minutes) {
    final m = {...state.items};
    if (minutes == null) {
      m.remove(e.key);
    } else {
      m[e.key] = minutes;
    }
    _save(state.copy(items: m));
  }
}

final remindersProvider =
    NotifierProvider<ReminderNotifier, ReminderConfig>(ReminderNotifier.new);

